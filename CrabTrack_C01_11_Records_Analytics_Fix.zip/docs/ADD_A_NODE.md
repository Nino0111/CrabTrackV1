# How to add a new node

Before, nodes were hardcoded as `node1`, `node2`, `node3` in three places
(the database schema, the server, and the dashboard). Adding a fourth meant
editing all three. Now the node list is data, not code — so adding one is a
two-minute job.

---

## The short version

1. Copy `firmware/crabtrack_node.ino`.
2. Change `NODE_ID` to something unique — `"node4"`.
3. Fill in `buildPayload()` with what this node measures.
4. Flash the ESP32.

It shows up on `nodes.html` within one reporting cycle. Nothing else to edit.

---

## Why that works

The Pi auto-registers unknown nodes. When a payload arrives with a `node_id`
that isn't in the `nodes` table, the server creates the row and guesses the
node's capabilities from which sensor keys the payload contains:

| Key in payload | Capability recorded |
|---|---|
| `ph` | pH |
| `salinity` / `ec` | Salinity / EC |
| `temperature` | Temperature |
| `weights` (array) | Weights |
| anything else | stored as raw JSON in `node_readings` |

Every message is also kept per-node in `node_readings`, so nothing is thrown
away even if the dashboard doesn't display it yet.

---

## Naming it before it exists

If you want the node named nicely before you flash it, open **nodes.html →
Add a Node**, fill in the ID, name, location and what it measures, and save.
The form also prints the exact firmware lines for that node — expand
*"Show the exact firmware snippet"* and paste them in.

The same thing over the API:

```bash
curl -X POST http://<pi-ip>:3000/api/nodes \
  -H "Content-Type: application/json" \
  -d '{"nodeId":"node4","label":"pH Node — Tank B","location":"Tank B","capabilities":["ph"]}'
```

---

## Sending data

**HTTP** (simplest — no broker to install):

```bash
curl -X POST http://<pi-ip>:3000/api/ingest \
  -H "Content-Type: application/json" \
  -d '{"node_id":"node4","ph":7.82}'
```

**MQTT** (better if you have many nodes or want lower power use):
publish JSON to `crabtrack/node4`. The bridge subscribes to `crabtrack/+`,
so any new topic under that prefix is picked up with no config change.

---

## Weight nodes covering different compartments

If a weight node only handles C06–C10, tell the Pi where its readings start:

```json
{ "node_id": "node5", "weight_offset": 5, "weights": [118.2, 121.0, 99.4, 130.1, 112.7] }
```

`weight_offset` is 0-based, so `5` means the first value is C06. Without it,
every weight node would overwrite C01 onwards.

---

## Removing or renaming

On `nodes.html`, each node row has **RENAME** and **REMOVE**.

Removing deletes the node's stored readings. If the physical device is still
powered on and posting, it will re-register itself on its next message — so
power the node down first, or set `enabled` to false instead.

---

## Node offline detection

Each node has an `offlineAfter` threshold in seconds (default 120). If it goes
quiet for longer than that, the dot turns red and the Pi sends one message per
hour to your configured channel:

```
📡 Node offline — pH Node — Tank B (node4) last reported 14 min ago.
```

Set it to a bit more than twice the node's reporting interval. A node sending
every 30s wants roughly 90–120s; a battery node sending every 10 minutes wants
about 1500s, or it will look permanently offline.

---

## API reference

| Method | Path | Purpose |
|---|---|---|
| `GET` | `/api/nodes` | List all nodes with live status |
| `GET` | `/api/nodes/:id` | One node |
| `POST` | `/api/nodes` | Create or update |
| `PATCH` | `/api/nodes/:id` | Edit label / location / capabilities |
| `DELETE` | `/api/nodes/:id` | Remove node and its readings |
| `GET` | `/api/nodes/:id/history?hours=24` | Raw payload history |

`GET /api/data` still returns `node1_ok`, `node2_ok` and `node3_ok` exactly as
before, so the existing dashboard code keeps working — but it now also returns
a `nodes` array with every registered node, however many there are.
