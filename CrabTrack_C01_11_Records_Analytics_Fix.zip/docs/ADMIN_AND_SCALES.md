# Admin login, tare/calibrate from the website, pump-off schedules, salinity "stop at optimal"

New in this version. Nothing here changes the feeding schedule, node
auto-registration, or the existing drain/weigh cycle.

## 1. Admin account - created on the admin page (nothing to edit on the Pi)

Open `admin.html` the first time and you get a **Create admin account** screen:
choose a username and a password (8+ characters) and press **Create account**.
That's it - no `.env`, no Firebase console user.

- The same username/password is created **online** (Firebase) and **on the Pi**,
  so you can sign in with internet *or* on the local network with no internet.
- Afterwards the page shows a normal **Sign in** screen. **Change password** is
  in the page header.
- The Pi stores only a salted hash of the password, never the password.
- Create the account **right after you publish the site, before sharing the
  address** - the first person to open the page claims the admin account.
- The login is enforced by the Pi (and by Firebase rules online), not just by
  hiding the page. Changing schedules, valve rules, the pump, the drain cycle
  and the scales all need to be signed in. 5 wrong passwords lock a device out
  for 5 minutes.
- The ESP32 boards do **not** log in; they use the open device routes
  (`/api/ingest`, `/api/actuators/state`, `/api/scale/pending`, `/api/scale/result`).
- `nodes.html` (feeding schedule, node list) and read-only data are **not**
  behind this login yet.
- On plain HTTP the password isn't encrypted on the Wi-Fi - fine for a closed
  farm network; use HTTPS if you expose the Pi to the internet.

## 2. Tare and calibrate each compartment from the website

`admin.html → SCALES`:

1. Pick the compartment (C01…C10).
2. **Tare:** scale completely empty → press **TARE**.
3. **Calibrate (only when needed):** after taring, put an object of known weight
   on the scale, type its weight in grams → **CALIBRATE**.

The weight node (`crabtrack_node4_weight.ino`) asks the Pi every 3 s whether
there is a request for its compartments, does it, and reports back; the result
appears in *Recent requests* (done / failed + reason).

- **Re-flash node4 once** with the new `.ino` (Arduino IDE needed this one
  time only). After that, no Arduino IDE for taring/calibrating.
- Tare offset and calibration factor are saved in flash **per load cell** and
  survive reboot (the old sketch re-zeroed at every power-up, whatever was on
  the scale). On the very first boot with the new sketch, the scale must be empty.
- A request the node doesn't pick up within 2 minutes is cancelled, so a late
  tare can't zero a scale that now has crabs on it.
- Several load cells on one ESP32: set `SCALE_COUNT` and the `HX_DOUT`/`HX_SCK`
  pin lists in the sketch. Cell 0 = compartment `WEIGHT_OFFSET+1`, and so on.
  Each compartment then has its own tare/calibration.
- Needs **HX711_ADC 1.2.x or newer** (for `getTareOffset`/`setTareOffset`).

## 3. Valves 1 + 2 at a set time, pump off

`admin.html → SOLENOID AUTOMATION → TIME SCHEDULES`

| Field | Meaning |
|---|---|
| Start time | e.g. 06:00 (Pi's clock), daily |
| Valves | e.g. `1,2` |
| Valves open (min) | e.g. 5 |
| Pump off (min) | e.g. 5 — `0` leaves the pump alone |

At 06:00 valves 1 and 2 open and the pump is switched off for 5 minutes, then
everything returns to normal. Press **Edit** on any schedule to change time,
valves or minutes. The pump board gets this through the same
`GET /api/actuators/state` it already polls, so no pump firmware change.
A manual "Force pump ON" still wins over a schedule.

## 4. Valve 3 (saltwater) and valve 4 (freshwater) with a stop level

`admin.html → SOLENOID AUTOMATION → SALINITY / SENSOR RULES`

| Field | Valve 3 example | Valve 4 example |
|---|---|---|
| Valve | 3 | 4 |
| Open when salinity | BELOW | ABOVE |
| Start level | 25 | 35 |
| **Stop at (optimal)** | 30 | 32 |
| Safety cap (min) | 10 | 10 |

The valve opens when salinity crosses the start level and **stays open until
it reaches the stop level** (not just until it's back over the start level).
Use your real numbers — the ones above are placeholders.

Safety nets: the valve also closes at the safety cap, and closes immediately
if the salinity sensor node (`node2`) has gone offline, so a dead sensor can't
keep adding water. Salinity takes time to mix; if it overshoots the stop level,
raise the "wait between runs" (cooldown) or lower the stop level slightly.
Leaving "Stop at" empty keeps the old behaviour.

### Use different valves for different jobs
The drain/weigh cycle defaults to **valve 4**. If valve 4 is your freshwater
valve, choose another valve (or another plan) for draining — one valve
shouldn't be driven by both a rule and a drain cycle.

## API additions

| Method | Path | Login | Purpose |
|---|---|---|---|
| `POST` | `/api/admin/setup` | – (first run only) | create the admin account |
| `POST` | `/api/admin/login` | – | `{username,password}` → `{token}` |
| `POST` | `/api/admin/password` | token | change password |
| `POST` | `/api/admin/logout` | token | end the session |
| `GET` | `/api/admin/session` | – | is my token still valid |
| `POST` | `/api/scale/command` | **yes** | `{compId:"C04",action:"tare"}` or `{…,action:"calibrate",knownWeight:200}` |
| `GET` | `/api/scale/commands` | – | recent requests + results |
| `GET` | `/api/scale/state` | – | calibration factor, last tare/calibration |
| `GET` | `/api/scale/pending` | – | **node** asks what to do |
| `POST` | `/api/scale/result` | – | **node** reports the outcome |
| schedule `POST/PATCH` | `/api/actuators/schedule` | **yes** | new field `pumpOffMinutes` |
| rule `POST/PATCH` | `/api/actuators/rules` | **yes** | new field `stopThreshold` (`null` clears it) |

Existing control routes (`/api/actuators/*` writes, `/api/drain-cycle/*` writes,
`POST /api/pump`) now need the login token. If you called them with `curl`,
log in first and send `-H "Authorization: Bearer <token>"`.
