# Tare / calibrate ONLINE (Firebase) - Raspberry Pi only as backup

```
 admin.html ──(Firebase, internet)──►  /crab_scale/cmd/C07  ──►  C07's ESP32
 admin.html ◄──(Firebase)───────────  /crab_scale/res/C07  ◄──  "done / failed"

 No internet?  admin.html ──(Pi, local Wi-Fi)──► Pi ──► ESP32   (backup route)
```

The Pi is not involved while Firebase works. A board only asks the Pi if it
cannot reach Firebase.

## One-time setup

### 1. Turn on Email/Password sign-in (Firebase console, 30 seconds)
**Authentication → Sign-in method → Email/Password → Enable.**
Keep **Anonymous** enabled (your boards and dashboard use it).
You do **not** create any user here - the admin account is created from the
admin page (below). The page turns your username into a private internal
login, so you only ever type a username + password.

### 2. Database rules - ADD this block (Realtime Database → Rules)

```json
"crab_scale": {
  ".read": "auth != null",
  "admin": {
    ".read": true,
    ".write": "auth != null && !data.exists() && newData.child('uid').val() === auth.uid"
  },
  "cmd":  { ".write": "auth != null && auth.uid === root.child('crab_scale/admin/uid').val()" },
  "res":  { ".write": "auth != null" },
  "info": { ".write": "auth != null" }
}
```

Put it inside `"rules": { ... }` next to your existing paths. What it does:
- `admin` can be written **once** (the first account created) and never replaced.
- only that admin account can write `cmd` (the tare/calibrate requests).
- boards (anonymous sign-in) can read requests and write results.

⚠ **Check your root rules.** If you still have the test-mode rule
`".write": true` (or `"auth != null"`) directly under `"rules"`, it grants
write access to every path below it, and the protection above does nothing -
anyone could trigger a tare. Replace the root-level write with rules for the
specific paths your boards and dashboard write to (`/crab_monitor/...`,
`/crab_track/...`) and then add the block above. Test-mode rules also expire
after 30 days.

### 3. Create the admin account
Open `admin.html` → **Create admin account** → username + password. Do this
right after publishing, before you share the address (the first person to do it
becomes the admin).

### 4. Re-flash each compartment ESP32
`firmware/crabtrack_weight_compartment.ino` - change only `#define COMP_NUM`.

## Safety built in
- A request already sitting in Firebase when a board boots is **not** run.
- A request older than 2 minutes is ignored (board was offline / wifi blip).
- One pending request per compartment at a time.
- Tare/calibration are saved in the board's flash and survive reboots.

## What still needs the Pi
Valve schedules, salinity rules, the pump and the drain cycle are computed on
the Pi (the valve/pump boards poll it). Tare/calibrate and the weight readings
do not need it.
