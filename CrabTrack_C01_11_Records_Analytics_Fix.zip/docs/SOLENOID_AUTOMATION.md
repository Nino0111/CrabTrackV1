# Solenoid automation (channels 1-4)

Added on top of the existing node/schedule system. Nothing here breaks
the feeding schedule, node auto-registration, or anything else —
it's a new, separate set of tables and API routes.

> **Update:** schedules can now also switch the pump off, rules can have a
> separate stop level, and all changes need the admin login. See
> `ADMIN_AND_SCALES.md`. The curl examples below need
> `-H "Authorization: Bearer <token>"` now.

## How it works

The solenoid ESP32 (`firmware/crabtrack_node5_solenoids.ino`) does **not**
decide anything itself. Every `POLL_MS` (default 5s) it asks the Pi:

```
GET /api/actuators/state
```

and gets back which of channels 1-4 should be open right now, e.g.:

```json
{
  "channels": { "1": false, "2": false, "3": true, "4": false },
  "salinity": 23.4,
  "reasons": { "3": "rule:2" }
}
```

The Pi computes that from two things you configure on `admin.html`:

### 1. Time schedules
"Channels 1,2 open at 06:00 for 5 minutes, daily."

```bash
curl -X POST http://<pi-ip>:3000/api/actuators/schedule \
  -H "Content-Type: application/json" \
  -d '{"label":"Morning flush","time":"06:00","channels":[1,2],"durationMinutes":5}'
```

### 2. Salinity (or pH / temperature) rules
"Channel 3 opens to add saltwater below the low threshold and closes at the stop/target threshold."
"Channel 4 opens to add freshwater above the high threshold and closes at the stop/target threshold."

```bash
curl -X POST http://<pi-ip>:3000/api/actuators/rules \
  -H "Content-Type: application/json" \
  -d '{"label":"Low salinity","channel":3,"source":"salinity","condition":"below","threshold":25,"durationMinutes":2,"cooldownMinutes":10}'

curl -X POST http://<pi-ip>:3000/api/actuators/rules \
  -H "Content-Type: application/json" \
  -d '{"label":"High salinity","channel":4,"source":"salinity","condition":"above","threshold":35,"durationMinutes":2,"cooldownMinutes":10}'
```

`durationMinutes` on a rule is a **safety cap** — the channel closes after
that long even if the condition is still true, so a stuck sensor can't
hold a solenoid open indefinitely. `cooldownMinutes` is the minimum gap
before the same rule can fire again.

The default low/high rules are deliberately seeded disabled until the operator confirms the sensor units. Both are also editable from **admin.html → SOLENOID AUTOMATION** — no
curl needed day to day.

## Safety

If the solenoid node can't reach the Pi for 30 seconds (`FAILSAFE_MS` in
the firmware), it forces every channel OFF and keeps retrying. A dead
WiFi connection should never leave a solenoid stuck open.

## API reference

| Method | Path | Purpose |
|---|---|---|
| `GET` | `/api/actuators/state` | What should be open right now (polled by the node) |
| `GET` | `/api/actuators/schedule` | List time schedules |
| `POST` | `/api/actuators/schedule` | Add one |
| `PATCH` | `/api/actuators/schedule/:id` | Edit / enable / disable |
| `DELETE` | `/api/actuators/schedule/:id` | Remove |
| `GET` | `/api/actuators/rules` | List sensor rules |
| `POST` | `/api/actuators/rules` | Add one |
| `PATCH` | `/api/actuators/rules/:id` | Edit / enable / disable |
| `DELETE` | `/api/actuators/rules/:id` | Remove |
| `GET` | `/api/actuators/history?channel=3` | Recent on/off log for a channel |


**Unit warning:** the API's `salinity` field may be populated from EC in mS/cm. Do not enable salinity control thresholds in ppt until you have confirmed the field's unit and calibrated any EC-to-salinity conversion.
