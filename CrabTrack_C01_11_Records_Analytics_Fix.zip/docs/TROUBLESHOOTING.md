# Why a node showed ONLINE while unplugged

Two separate bugs caused this, both now fixed in `admin.js`.

## Bug 1 — "online" defaulted to true

```js
updateNodeStatus('node1', data.node1.online ?? true, ...)   // old
```

`??` only falls through when the left side is `null`/`undefined`. If your
ESP32 never writes an `online` field — and most sketches don't — the
expression evaluates to `true`. So the mere *existence* of a `node1` record in
Firebase marked it ONLINE. It could never report anything else.

(The `node1` line also had `data.node1.online ?? data.node1.online ?? true`,
the same term twice — a typo, harmless but a sign of the same confusion.)

## Bug 2 — nothing ever checked how old the data was

This is the answer to "why does it show the later values".

Firebase Realtime Database **keeps the last written value forever**. Unplug a
node and its last reading stays at that path indefinitely. Worse, the
`.on('value')` listener only fires when data *changes* — a dead node changes
nothing, so the listener never fires again and the last known state sits there
looking healthy.

On top of that, `lastSeen: Date.now()` recorded when *the browser received the
data*, not when the node produced it. That's always "now", so "last seen just
now" was true even for a reading from three hours ago.

## The fix

A node is ONLINE only if it wrote a **recent wall-clock timestamp**:

| Situation | Now shows |
|---|---|
| Timestamp under 120s old | `ONLINE` |
| Timestamp older than 120s | `STALE — NO DATA (32m ago)` |
| Node explicitly sends `online:false` | `OFFLINE` |
| No timestamp at all | `NO HEARTBEAT` |

`NO HEARTBEAT` is deliberate. If a node doesn't send a timestamp, nobody can
tell whether it's alive — so the page says so instead of guessing, which is
what caused the problem in the first place.

A 10-second timer re-evaluates staleness locally, because a dead node won't
push anything to trigger a re-render.

## What you must do on the node side

Your ESP32 has to send a timestamp. `firmware/crabtrack_node.ino` now syncs
NTP at boot and includes it automatically:

```cpp
doc["ts"]     = epochNow();   // unix seconds
doc["online"] = true;
```

Accepted keys: `ts`, `timestamp`, `last_seen`, `lastSeen`, `updated_at`,
`time`. Either unix seconds, milliseconds, or an ISO date string.

**`millis()` is deliberately ignored.** It's time since the ESP32 booted, not a
date, so it can't tell anyone how old a reading is.

If you write to Firebase directly from the node, you can use the server clock
instead of NTP — that's more reliable:

```json
{ "ts": { ".sv": "timestamp" } }
```

To change the 120-second threshold, run this in the browser console:

```js
localStorage.setItem('crabtrack_stale_seconds', '300');   // 5 minutes
```

Set it to a bit more than twice the node's reporting interval, or a slow
battery node will look permanently stale.

## This never affected the Pi path

`GET /api/data` from the Pi was already correct: `db.js` stamps arrival time
server-side and compares it against each node's `offlineAfter`, so a silent
node goes red on its own. The bug was only in the Firebase path, where the
timestamp has to come from the node because nothing else is watching.

That's a decent argument for treating the Pi as the source of truth and the
Firebase mirror as a read-only copy — see `ONLINE_ACCESS.md`.
