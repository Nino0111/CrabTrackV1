# CrabTrack Firebase Pump Controller

See `FIREBASE_SOLENOID_SETUP.md` for merged Firebase rules and setup. Configure a separate Firebase device account, Wi-Fi credentials, and upload `firmware/CrabTrack_Firebase_Pump_Controller.ino`. Website tab: Admin → Pump.
