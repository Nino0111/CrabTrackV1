# Offline vs online: what to actually use

## The one rule worth committing to

**The Raspberry Pi and its SQLite file are the source of truth. Everything
else is a copy.**

Crab compartments don't stop needing monitoring when the internet does, and in
the Philippines a farm or campus link going down for a few hours is normal, not
exceptional. If the cloud is in the critical path, a dropped connection means
lost readings. If the cloud is a mirror, a dropped connection means a stale web
page and nothing more — the nodes keep reporting, SQLite keeps recording, the
feeding cron keeps running, and messages queue up for later delivery.

That's how the code in this package is now arranged. Nothing on the Pi waits
for the internet.

---

## What you're choosing between

You've already got a Firebase project wired into `admin.js`, so the real
question is what job the cloud does. Three honest options:

### Option A — Tailscale *(recommended for you)*

A free private network. Install it on the Pi and on your phone/laptop, and the
Pi gets a permanent address reachable from anywhere, as if you were on the farm
Wi-Fi. No port forwarding, no public exposure, encrypted end to end.

```bash
curl -fsSL https://tailscale.com/install.sh | sh
sudo tailscale up
# then point the dashboard's API URL at the 100.x.x.x address it prints
```

- **Good:** ten minutes to set up, nothing exposed publicly, full read *and*
  write (you can log feedings remotely), one system instead of two.
- **Bad:** everyone who needs access must install Tailscale and be invited.
  Not suitable for a public link.

### Option B — Cloudflare Tunnel

Gives the Pi a real public HTTPS URL without opening any router ports.

- **Good:** free, anyone with the link can open it, works for a thesis defence
  where you hand a URL to a panel.
- **Bad:** your Pi is now on the public internet. `server.js` has **no
  authentication**, so you must put Cloudflare Access (free, email-code login)
  in front of it, or anyone who finds the URL can POST fake readings.

### Option C — Firebase mirror *(already implemented — `cloud-sync.js`)*

The Pi pushes a snapshot to Realtime Database every 30 seconds. Set it up in
`pi-server/.env`:

```env
FIREBASE_DB_URL=https://crabtrack-1e256-default-rtdb.asia-southeast1.firebasedatabase.app
FIREBASE_SECRET=<your database secret>
CLOUD_SYNC_SECONDS=30
```

- **Good:** the data stays readable even when the Pi is switched off entirely,
  which is genuinely useful for a demo. You already have the project. Your
  ESP32s could also write to Firebase directly as a backup path.
- **Bad:** it's a second copy of your data that can drift and confuse you when
  debugging. It's **read-only** from outside — you can't log a feeding from the
  mirror, because writes would need to flow back to the Pi and that's where
  sync conflicts start. And Firebase's free tier has a daily download cap that
  a chatty dashboard can hit.

### What about Supabase / MongoDB Atlas / your own VPS?

Supabase is the better database of the two if you were starting fresh — real
SQL, so your SQLite schema ports over nearly unchanged, and row-level security
that's easier to reason about than Firebase rules. But you already have
Firebase working. Switching now costs you time and buys you very little.
**Don't migrate.** Use what's set up.

---

## My recommendation

**Tailscale for you and your groupmates, plus Telegram for alerts, plus the
Firebase mirror only if you need a link that works when the Pi is off.**

Reasoning: alerts are the thing that actually has to reach you at 2am, and
Telegram handles that on its own without the dashboard being reachable at all.
Once alerts are covered, remote *viewing* is a convenience, and Tailscale gives
you that with no second database to keep honest. Add the Firebase mirror as a
third layer if your defence requires a URL you can hand to someone.

If you only implement one thing from this document, make it Telegram.

---

## ⚠️ Your Firebase rules

Your web API key is visible in `admin.js`. That's normal and expected for
Firebase — the key identifies the project, it doesn't authorise anything. What
*does* matter is your Realtime Database rules.

If they currently look like this, anyone on the internet can read and
**overwrite** your thesis data:

```json
{ "rules": { ".read": true, ".write": true } }
```

Minimum fix — public read, Pi-only write (the Pi authenticates with
`FIREBASE_SECRET`, which bypasses rules):

```json
{
  "rules": {
    "crab_track": { ".read": true, ".write": false },
    "crab_monitor": { ".read": true, ".write": false }
  }
}
```

Check this in the Firebase console under Realtime Database → Rules before
anything goes live. "Test mode" rules also expire after 30 days, which is a
memorable way to have your dashboard die the week of your defence.

---

## Making sure it survives a reboot

```ini
# /etc/systemd/system/crabtrack.service
[Unit]
Description=CrabTrack Pi server
After=network-online.target
Wants=network-online.target

[Service]
WorkingDirectory=/home/pi/CrabTrack_Website/pi-server
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=5
User=pi
EnvironmentFile=/home/pi/CrabTrack_Website/pi-server/.env

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable --now crabtrack
sudo journalctl -u crabtrack -f      # watch the logs
```

Two more things worth doing on a Pi that runs unattended:

- **Give it a static IP**, or a DHCP reservation on the router. Otherwise the
  Pi's address changes after a power cut and every node loses it.
- **Back up the database.** It's one file:
  `cp pi-server/crabtrack.db /media/usb/crabtrack-$(date +%F).db` in a weekly
  cron job. SD cards fail, and they tend to fail at the worst time.
