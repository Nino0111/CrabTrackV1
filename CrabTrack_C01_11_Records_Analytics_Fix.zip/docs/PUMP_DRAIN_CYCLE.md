# Pump + drain-solenoid auto weigh-cycle

Added on top of the existing solenoid automation and weight node.
Nothing here breaks the feeding schedule, salinity rules, node
auto-registration, or anything else — it's a new, separate set of
tables and API routes, plus one new (optional) ESP32 board for the
pump.

## The sequence

```
SCHEDULE → PUMP OFF → DRAIN SOLENOID ON → DRAIN SOLENOID OFF → WEIGHT TAKEN → PUMP ON
```

1. **Scheduled time reached.** The Pi starts the cycle.
2. **Pump OFF.** Stop water circulation before draining.
3. **Drain solenoid ON** for the configured duration, then **OFF**.
4. **Weight taken.** The Pi reads the weight node's latest reading
   (it's already streaming in every few seconds) and logs it.
5. **Pump ON.** Only after the weight has actually been captured.

## Why this doesn't need MQTT

The pump and the drain solenoid normally live on **two separate ESP32
boards** — `firmware/crabtrack_node6_pump.ino` and
`firmware/crabtrack_node5_solenoids.ino`. Neither board decides
anything itself. Both just poll the Pi every few seconds:

```
GET /api/actuators/state
```

```json
{
  "channels": { "1": false, "2": false, "3": false, "4": true },
  "reasons": { "4": "drain-cycle" },
  "pump": false,
  "pumpMode": "auto",
  "activeCycles": [
    { "type": "schedule", "id": 1, "label": "Morning drain", "phase": "draining", "channel": 4 }
  ]
}
```

The solenoid node only cares about `channels`; the pump node only
cares about `pump`. Since the **Pi** is the one place that runs the
whole sequence and knows exactly where in it the system currently is,
two independent boards stay in sync without ever talking to each
other — the pump board simply never sees `"pump": true` again until
the weight step has actually run. (The project already ships an
optional `pi-server/mqtt-bridge.js` if you'd rather have nodes publish
over MQTT instead of plain HTTP `POST /api/ingest` — that's orthogonal
to this feature and not required for it.)

## Configuring a cycle

All of this is done from **admin.html → PUMP + AUTO DRAIN/WEIGH
CYCLE** — no curl needed day to day, though the API works the same
way the solenoid schedule/rules API does:

```bash
curl -X POST http://<pi-ip>:3000/api/drain-cycle/schedule \
  -H "Content-Type: application/json" \
  -d '{"label":"Morning drain","time":"06:00","drainChannel":4,"pumpLeadSeconds":5,"drainMinutes":3,"settleSeconds":20,"compId":"C04"}'
```

- `drainChannels` — one or more solenoid channels (1-4), such as `[1,2]`. Legacy `drainChannel` remains supported.
  Don't also assign a salinity/pH rule to this same channel.
- `pumpLeadSeconds` — small gap between "pump off" and "drain valve
  opens", so the two genuinely happen in order rather than at the
  exact same instant (default 5s).
- `drainMinutes` — how long the drain valve stays open.
- `settleSeconds` — how long to wait after closing the valve before
  trusting the scale reading (let sloshing/draining settle).
- `compId` — which compartment to log (e.g. `C04`), or `ALL` to snapshot available readings for C01–C10 after the drain/settle step.

A schedule runs once per day (dedup'd by date), and is safe to poll
as often as you like — a step only gets logged into the cycle history
the first time the system notices it should have happened.

### Run a cycle immediately

```bash
curl -X POST http://<pi-ip>:3000/api/drain-cycle/run-now \
  -H "Content-Type: application/json" \
  -d '{"drainChannel":4,"drainMinutes":3,"settleSeconds":20,"compId":"C04"}'
```

Same "Run Cycle Now" button exists on admin.html.

### Manual pump override

For maintenance (e.g. working on the plumbing), you can force the
pump on or off regardless of any cycle:

```bash
curl -X POST http://<pi-ip>:3000/api/pump -H "Content-Type: application/json" -d '{"mode":"forced_off"}'
curl -X POST http://<pi-ip>:3000/api/pump -H "Content-Type: application/json" -d '{"mode":"forced_on"}'
curl -X POST http://<pi-ip>:3000/api/pump -H "Content-Type: application/json" -d '{"mode":"auto"}'
```

A forced mode wins over an in-progress cycle, so remember to set it
back to `auto` afterwards.

## Safety

- The pump board defaults to **ON** at boot and whenever it can't
  reach the Pi for `FAILSAFE_MS` (30s) — a lost WiFi connection
  should never leave the pump stuck off and the water stagnant.
- The solenoid board already defaults every channel **OFF** in the
  same failsafe situation — a lost WiFi connection should never leave
  the drain valve stuck open either.
- If the weight node's reading isn't available when the settle window
  ends, the cycle still logs a `weight_taken` step (noting that no
  reading was available) and still turns the pump back on — a missing
  sensor reading should never leave the pump off indefinitely.

## API reference

| Method | Path | Purpose |
|---|---|---|
| `GET` | `/api/actuators/state` | Now also carries `pump`, `pumpMode`, `activeCycles` alongside the existing solenoid `channels` |
| `GET` | `/api/drain-cycle/schedule` | List cycle schedules |
| `POST` | `/api/drain-cycle/schedule` | Add one |
| `PATCH` | `/api/drain-cycle/schedule/:id` | Edit / enable / disable |
| `DELETE` | `/api/drain-cycle/schedule/:id` | Remove |
| `POST` | `/api/drain-cycle/run-now` | Queue one immediate cycle |
| `GET` | `/api/drain-cycle/log?limit=50` | Recent step-by-step history |
| `GET` | `/api/pump` | Current pump state + mode |
| `POST` | `/api/pump` | `{ mode: "auto" \| "forced_on" \| "forced_off" }` |
| `GET` | `/api/pump/history` | Recent pump on/off transitions |


### Default 06:00 cycle

A fresh database seeds `Daily 06:00 drain — solenoids 1+2`: pump OFF, channels 1 and 2 open for 2 minutes, both close, wait 20 seconds, snapshot available weights for all ten compartments, then pump returns to automatic ON. Because the ESP32s poll independently, verify the sequence with water safely diverted before relying on it.
