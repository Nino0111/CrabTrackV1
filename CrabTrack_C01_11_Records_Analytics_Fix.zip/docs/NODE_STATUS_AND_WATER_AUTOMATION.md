# Node status and water automation update

## Node status
`crabtrack/node-status.html` shows Node 1 (pH), Node 2 (EC/temperature), Node 3 (TFT), weight nodes C01–C10, Node 5 (solenoids), and Node 6 (pump). It refreshes every five seconds and gives troubleshooting checks for missing nodes. It understands both the older Flask-style API response and this Node backend's `/api/nodes` response.

## Default daily drain/weigh sequence
A new database gets one schedule at 06:00 local Raspberry Pi time:
1. Pump command OFF and solenoids 1+2 command OPEN.
2. Keep both drain valves open for 2 minutes.
3. Close both valves.
4. Wait 20 seconds for the water/scale to settle.
5. Record the latest available weights for C01–C10.
6. Return pump control to automatic ON.

The schedule seed is idempotent and does not overwrite an existing schedule with the same label. Both ESP32 controllers poll independently, so confirm their timing and relay polarity during a supervised dry/water-safe test.

## Salinity rules
Two draft rules are added as disabled: channel 3 starts below 15 and stops at 18; channel 4 starts above 25 and stops at 22. These numbers are not automatically enabled because the existing EC sensor may be reporting mS/cm, not ppt. Confirm the API units and appropriate mud-crab target values before enabling. Each rule has a 5-minute safety cap, a 2-minute cooldown, and closes if its sensor goes offline.

## Existing backend compatibility
This ZIP implements actuator routes in `pi-server/server.js`. The user's current installation has a Python Flask server on port 3000. Do not run the Node and Flask servers on the same port. For the Node backend to preserve MQTT data, set `MQTT_BROKER=mqtt://localhost:1883` in `pi-server/.env`; the updated bridge subscribes to `crabtrack/#` and normalizes `crabtrack/node2/data` and `crabtrack/weight1`…`weight10`. The current Python backend must be backed up and migrated or have equivalent actuator routes integrated before the hardware uses this automation.
