# CrabTrack Firebase Solenoid Controls — setup

This adds the solenoid controls as a tab in the existing `crabtrack/admin.html` page. It uses the existing Firebase project and the path `/solenoid_control`; it does not need a Raspberry Pi.

## 1. Firebase Authentication
1. Firebase Console → Authentication → Sign-in method → enable **Email/Password**.
2. Create a dedicated device user, for example `crabtrack-esp32@your-domain.example`, with a strong password. Do not reuse your admin password.
3. Put that email/password in `firmware/CrabTrack_Firebase_Solenoid_Controller.ino` as `DEVICE_EMAIL` and `DEVICE_PASSWORD`. Also fill in Wi-Fi credentials.
4. The website admin must sign in with the existing Firebase admin account. The solenoid page only sends commands when `fbUser` is a Firebase-authenticated user.

## 2. Realtime Database rules
Merge these rules into your existing rules. Do not replace your complete rules file blindly because other CrabTrack features use other paths. Replace `PUT_ADMIN_UID_HERE` and `PUT_DEVICE_UID_HERE` with UIDs from Firebase Authentication. The admin UID should be the same one already registered at `/crab_scale/admin/uid` if that is how your project identifies its admin.

```json
{
  "rules": {
    "solenoid_control": {
      ".read": "auth != null && (auth.uid === 'PUT_ADMIN_UID_HERE' || auth.uid === 'PUT_DEVICE_UID_HERE')",
      "command": {
        ".write": "auth != null && auth.uid === 'PUT_ADMIN_UID_HERE'"
      },
      "schedule": {
        ".write": "auth != null && auth.uid === 'PUT_ADMIN_UID_HERE'"
      },
      "status": {
        ".write": "auth != null && auth.uid === 'PUT_DEVICE_UID_HERE'"
      }
    }
  }
}
```

Important: Firebase rules are not additive across separate deployments; preserve every existing rule and add this `solenoid_control` child under your current root `rules`. If your current rules use a different admin identity path, adapt the admin UID check to your existing trusted admin scheme. Never set `.write` to `true`.

## 3. Upload and deploy
1. Open the `.ino` from `firmware/` in Arduino IDE. Install **ArduinoJson** and select your ESP32 board.
2. Set Wi-Fi and device account credentials, then upload. Open Serial Monitor at 115200.
3. Deploy the website folder according to your existing Firebase Hosting setup. The tab is in the existing admin page: **Admin → Solenoids**.
4. Sign in, open Solenoids, and wait for ESP32 status to show ONLINE. Test with water isolated first.

## Paths used
- `/solenoid_control/command`: authenticated admin command (`valve` or `all_off`).
- `/solenoid_control/schedule`: authenticated admin schedule config.
- `/solenoid_control/status`: ESP32 state, last-seen heartbeat, EC reading, and command result.
- Existing sensor read remains `/crab_monitor.json`, checking `node2.ec` then `node2.EC`.

## Safety / limitations
- Manual ON timeout remains 120 seconds. S3 and S4 cannot be open simultaneously. Automatic salinity dosing remains disabled. The firmware does not implement a pump interlock.
- HTTPS currently uses `setInsecure()` in the prototype. That encrypts traffic but does not verify the server certificate; add root CA validation before production deployment.
- ESP32 command polling occurs every 2.5 seconds; status heartbeat is about every 10 seconds.


## Pump controller (separate ESP32)
The website now includes an **Admin → Pump** tab. Use a separate Firebase Email/Password device account for the pump ESP32 (do not reuse the solenoid device account). Set `DEVICE_EMAIL`, `DEVICE_PASSWORD`, and the Wi-Fi router credentials in `firmware/CrabTrack_Firebase_Pump_Controller.ino`, then upload it to the pump ESP32. This version uses Wi-Fi station mode so it can reach Firebase; the original standalone `CrabTrack-Pump` hotspot-only sketch cannot receive remote Firebase commands while it is disconnected from the internet.

Add these rules under your existing root `rules`, merging them with all existing rules. Replace the UIDs with the admin and pump-device UIDs from Firebase Authentication:

```json
"pump_control": {
  ".read": "auth != null && (auth.uid === 'PUT_ADMIN_UID_HERE' || auth.uid === 'PUT_PUMP_DEVICE_UID_HERE')",
  "command": { ".write": "auth != null && auth.uid === 'PUT_ADMIN_UID_HERE'" },
  "schedule": { ".write": "auth != null && auth.uid === 'PUT_ADMIN_UID_HERE'" },
  "status": { ".write": "auth != null && auth.uid === 'PUT_PUMP_DEVICE_UID_HERE'" }
}
```

Pump paths: `/pump_control/command`, `/pump_control/schedule`, `/pump_control/status`. Pump schedule time is Philippine time (UTC+8); the ESP32 obtains time using NTP. Pump GPIO is 17, active HIGH by default, matching the code supplied by the user. This pump firmware starts the pump OFF at boot. Manual ON/OFF cancels a timed OFF period; at the scheduled time the pump turns OFF for the configured duration and then resumes ON. It does not implement a pump/solenoid interlock.

Security note: the prototype currently uses `WiFiClientSecure::setInsecure()` for HTTPS. This encrypts the connection but skips certificate validation; add root CA verification before production use. Test with the pump disconnected from water/loads before operating it.
