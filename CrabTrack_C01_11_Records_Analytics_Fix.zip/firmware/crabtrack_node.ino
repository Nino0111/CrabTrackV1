/* ══════════════════════════════════════════════════════════
   crabtrack_node.ino — universal CrabTrack ESP32 node
   ══════════════════════════════════════════════════════════
   ONE sketch for EVERY node. To add a new node to the system:

     1. Copy this file.
     2. Change NODE_ID (line ~20) to something unique: "node4".
     3. Fill in buildPayload() with whatever that node measures.
     4. Flash it.

   That's it. The Pi auto-registers the node the first time it posts,
   and it appears on nodes.html with a live status dot. No server code
   to edit, no database migration, no dashboard change.

   Libraries needed (Arduino IDE → Library Manager):
     • ArduinoJson    by Benoit Blanchon
     • PubSubClient   by Nick O'Leary   (only if USE_MQTT is 1)
   ══════════════════════════════════════════════════════════ */

// ─────────── 1. IDENTITY — change this per node ───────────
#define NODE_ID       "node4"
#define NODE_LABEL    "pH Node - Tank B"
#define NODE_LOCATION "Tank B"

// ─────────── 2. NETWORK ───────────
#define WIFI_SSID     "YourWiFiName"
#define WIFI_PASS     "YourWiFiPassword"

#define PI_HOST       "10.193.219.111"   // Raspberry Pi's LAN IP (hostname -I)
#define PI_PORT       3000

#define USE_MQTT      0      // 0 = plain HTTP POST (simplest). 1 = MQTT.
#define MQTT_PORT     1883
#define MQTT_TOPIC    "crabtrack/" NODE_ID

#define SEND_EVERY_MS 30000  // how often to report, in milliseconds

#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#if USE_MQTT
  #include <PubSubClient.h>
  WiFiClient   mqttNet;
  PubSubClient mqtt(mqttNet);
#endif

// ═══════════════════════════════════════════════════════════
// 3. WHAT THIS NODE MEASURES — the only other part you edit
// ═══════════════════════════════════════════════════════════
// Include ONLY the keys this node actually reads. The Pi figures out
// the node's capabilities from the first payload it receives.
//
//   pH node       → doc["ph"]
//   EC/temp node  → doc["salinity"], doc["temperature"]
//   weight node   → doc["weights"] array (one entry per compartment)
//   anything else → just add the key; it's stored in node_readings
//                   as raw JSON, so you lose nothing.

void buildPayload(JsonDocument& doc) {
  doc["node_id"]  = NODE_ID;
  doc["label"]    = NODE_LABEL;      // only used on first registration
  doc["location"] = NODE_LOCATION;

  // ── HEARTBEAT — do not remove ──
  // Without a real wall-clock timestamp, nothing downstream can tell a
  // live reading from one frozen in place hours ago. Firebase in
  // particular keeps the last value forever, so a dead node looks
  // perfectly healthy. "ts" is what makes staleness detectable.
  // (The Pi's /api/ingest stamps arrival time itself, so this matters
  //  most if you also write straight to Firebase.)
  doc["ts"]     = epochNow();        // unix seconds, 0 until NTP syncs
  doc["online"] = true;

  // ── pH node example ──
  doc["ph"] = readPH();

  // ── EC + temperature node example ──
  // doc["salinity"]    = readEC();
  // doc["temperature"] = readTemp();

  // ── Weight node example ──
  // JsonArray w = doc["weights"].to<JsonArray>();
  // for (int i = 0; i < 10; i++) w.add(readScale(i));
  //
  // If a weight node only covers compartments C06-C10, tell the Pi where
  // its readings start so they land in the right slots:
  // doc["weight_offset"] = 5;    // 0-based: 5 == C06
}

// ─────────── your sensor reads go here ───────────
float readPH() {
  int raw = analogRead(34);                 // ← your pH probe's analog pin
  float volts = raw * (3.3f / 4095.0f);
  return 7.0f + ((2.5f - volts) / 0.18f);   // ← replace with YOUR calibration
}

// float readEC()   { return 18.2f; }
// float readTemp() { return 27.1f; }
// float readScale(int i) { return 0.0f; }

// ═══════════════════════════════════════════════════════════
// 4. PLUMBING — you shouldn't need to touch anything below
// ═══════════════════════════════════════════════════════════

// ── NTP clock, so readings carry a real date ───────────────
void syncClock() {
  configTime(8 * 3600, 0, "pool.ntp.org", "time.nist.gov");   // UTC+8, Philippines
  Serial.print("[ntp] syncing");
  for (int i = 0; i < 20 && time(nullptr) < 100000; i++) { delay(500); Serial.print("."); }
  time_t t = time(nullptr);
  Serial.println(t > 100000 ? "\n[ntp] clock set" : "\n[ntp] FAILED - ts will be 0");
}

unsigned long epochNow() {
  time_t t = time(nullptr);
  return (t > 100000) ? (unsigned long)t : 0UL;
}

void connectWiFi() {
  if (WiFi.status() == WL_CONNECTED) return;
  Serial.printf("[wifi] connecting to %s", WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 20000) {
    delay(400);
    Serial.print(".");
  }
  Serial.println(WiFi.status() == WL_CONNECTED
    ? "\n[wifi] connected, IP " + WiFi.localIP().toString()
    : "\n[wifi] FAILED - will retry next cycle");
}

bool sendHTTP(const String& json) {
  HTTPClient http;
  String url = String("http://") + PI_HOST + ":" + PI_PORT + "/api/ingest";
  http.begin(url);
  http.setTimeout(8000);
  http.addHeader("Content-Type", "application/json");
  int code = http.POST(json);
  bool ok = (code >= 200 && code < 300);
  Serial.printf("[http] POST %s -> %d %s\n", url.c_str(), code, ok ? "OK" : http.errorToString(code).c_str());
  http.end();
  return ok;
}

#if USE_MQTT
bool sendMQTT(const String& json) {
  if (!mqtt.connected()) {
    mqtt.setServer(PI_HOST, MQTT_PORT);
    Serial.print("[mqtt] connecting... ");
    if (!mqtt.connect(NODE_ID)) {
      Serial.printf("failed, rc=%d\n", mqtt.state());
      return false;
    }
    Serial.println("connected");
  }
  bool ok = mqtt.publish(MQTT_TOPIC, json.c_str());
  Serial.printf("[mqtt] %s -> %s\n", MQTT_TOPIC, ok ? "OK" : "FAILED");
  return ok;
}
#endif

void setup() {
  Serial.begin(115200);
  delay(400);
  Serial.printf("\n=== CrabTrack node \"%s\" (%s) ===\n", NODE_ID, NODE_LABEL);
  connectWiFi();
  if (WiFi.status() == WL_CONNECTED) syncClock();
}

void loop() {
  connectWiFi();

  if (WiFi.status() == WL_CONNECTED) {
    JsonDocument doc;
    buildPayload(doc);
    String json;
    serializeJson(doc, json);
    Serial.println("[payload] " + json);

#if USE_MQTT
    sendMQTT(json);
    mqtt.loop();
#else
    sendHTTP(json);
#endif
  }

  delay(SEND_EVERY_MS);
}
