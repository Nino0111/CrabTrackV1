/*
  CrabTrack Firebase Pump Controller
  ===================================
  Separate pump ESP32. This version connects to the same Wi-Fi router as
  your Firebase-enabled solenoid ESP32; it does NOT create the old
  CrabTrack-Pump hotspot because a hotspot-only ESP32 cannot reach Firebase.

  Pump relay: GPIO 17, active HIGH by default (as in the supplied sketch).
  Firebase paths:
    /pump_control/command
    /pump_control/schedule
    /pump_control/status

  Install ArduinoJson by Benoit Blanchon.
  Set Wi-Fi and dedicated Firebase Email/Password device credentials below.
  Test with the pump hydraulically isolated before use.
*/
#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <ArduinoJson.h>
#include <Preferences.h>
#include <time.h>

const char* WIFI_SSID = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const int PUMP_RELAY_PIN = 17;
const bool RELAY_ACTIVE_LOW = false;

const char* FIREBASE_BASE = "https://crabtrack-1e256-default-rtdb.asia-southeast1.firebasedatabase.app";
const char* FIREBASE_API_KEY = "AIzaSyBBwmx81dJMxA8EBFDAGCiAwRbKJpebp5w";
const char* DEVICE_EMAIL = "YOUR_PUMP_ESP32_DEVICE_EMAIL";
const char* DEVICE_PASSWORD = "YOUR_PUMP_ESP32_DEVICE_PASSWORD";
const char* PUMP_ROOT = "/pump_control";

const unsigned long COMMAND_POLL_MS = 2000;
const unsigned long SCHEDULE_POLL_MS = 10000;
const unsigned long STATUS_WRITE_MS = 10000;
const unsigned long TOKEN_LIFETIME_MS = 3000000UL;

Preferences prefs;
bool pumpIsOn = false;
bool scheduleEnabled = true;
bool timedOff = false;
bool clockReady = false;
int offHour = 22, offMinute = 0;
unsigned long offDurationMin = 120;
int lastTriggeredYear = -1, lastTriggeredYday = -1;
time_t offUntil = 0;
String idToken, lastCommandId, lastCommandResult = "Waiting for command";
bool lastCommandOk = true;
unsigned long tokenIssuedAt = 0, lastCommandPoll = 0, lastSchedulePoll = 0, lastStatusWrite = 0;

void setPump(bool turnOn) {
  pumpIsOn = turnOn;
  digitalWrite(PUMP_RELAY_PIN, RELAY_ACTIVE_LOW ? (turnOn ? LOW : HIGH) : (turnOn ? HIGH : LOW));
  Serial.printf("[PUMP] %s\n", turnOn ? "ON" : "OFF");
}
String formatTime(int h,int m){ char b[8]; snprintf(b,sizeof(b),"%02d:%02d",h,m); return String(b); }
String remainingTime(){
  if(!timedOff) return "Not in timed OFF period";
  long r=(long)(offUntil-time(nullptr)); if(r<=0) return "Resuming";
  char b[48]; snprintf(b,sizeof(b),"%ld hr %ld min",r/3600,(r%3600)/60); return String(b);
}
void loadSettings(){
  prefs.begin("pumpctrl",false);
  offHour=prefs.getInt("offHour",22); offMinute=prefs.getInt("offMinute",0);
  offDurationMin=prefs.getULong("duration",120); scheduleEnabled=prefs.getBool("enabled",true);
  lastTriggeredYear=prefs.getInt("lastYear",-1); lastTriggeredYday=prefs.getInt("lastDay",-1);
  offUntil=(time_t)prefs.getLong("offUntil",0); timedOff=prefs.getBool("timedOff",false);
}
void saveSettings(){
  prefs.putInt("offHour",offHour); prefs.putInt("offMinute",offMinute);
  prefs.putULong("duration",offDurationMin); prefs.putBool("enabled",scheduleEnabled);
  prefs.putInt("lastYear",lastTriggeredYear); prefs.putInt("lastDay",lastTriggeredYday);
  prefs.putLong("offUntil",(long)offUntil); prefs.putBool("timedOff",timedOff);
}

bool firebaseSignIn(){
  if(WiFi.status()!=WL_CONNECTED) return false;
  WiFiClientSecure client; client.setInsecure(); // Prototype; use CA validation for production.
  HTTPClient http; String url=String("https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=")+FIREBASE_API_KEY;
  if(!http.begin(client,url)) return false;
  http.addHeader("Content-Type","application/json"); DynamicJsonDocument req(512);
  req["email"]=DEVICE_EMAIL; req["password"]=DEVICE_PASSWORD; req["returnSecureToken"]=true;
  String body; serializeJson(req,body); int code=http.POST(body); String payload=http.getString(); http.end();
  if(code!=200){Serial.printf("[Firebase] sign-in HTTP %d\n",code);return false;}
  DynamicJsonDocument d(2048); if(deserializeJson(d,payload)) return false;
  idToken=d["idToken"].as<String>(); tokenIssuedAt=millis(); return idToken.length()>0;
}
bool ensureAuth(){ if(idToken.length() && millis()-tokenIssuedAt<TOKEN_LIFETIME_MS) return true; idToken=""; return firebaseSignIn(); }
bool getFirebase(const String& path, DynamicJsonDocument& d){
  if(!ensureAuth()) return false; WiFiClientSecure client; client.setInsecure(); HTTPClient http;
  if(!http.begin(client,String(FIREBASE_BASE)+path+".json?auth="+idToken)) return false;
  http.setTimeout(6000); int code=http.GET(); String body=http.getString(); http.end();
  if(code!=200){ if(code==401||code==403) idToken=""; return false; }
  return !deserializeJson(d,body);
}
bool putFirebase(const String& path, JsonDocument& d){
  if(!ensureAuth()) return false; WiFiClientSecure client; client.setInsecure(); HTTPClient http;
  if(!http.begin(client,String(FIREBASE_BASE)+path+".json?auth="+idToken)) return false;
  http.addHeader("Content-Type","application/json"); String body; serializeJson(d,body);
  int code=http.PUT(body); http.end(); if(code==401||code==403) idToken=""; return code>=200&&code<300;
}
void pollSchedule(){
  DynamicJsonDocument d(1024); if(!getFirebase(String(PUMP_ROOT)+"/schedule",d)) return;
  if(d.isNull()) return;
  int h=d["offHour"] | 22, m=d["offMinute"] | 0;
  long dur=d["durationMinutes"] | 120; bool en=d["enabled"] | true;
  if(h<0||h>23||m<0||m>59||dur<1||dur>1440) return;
  if(h!=offHour||m!=offMinute||dur!=(long)offDurationMin||en!=scheduleEnabled){
    offHour=h;offMinute=m;offDurationMin=(unsigned long)dur;scheduleEnabled=en;saveSettings();
    Serial.printf("[Schedule] %s at %s for %lu minutes\n",en?"Enabled":"Disabled",formatTime(h,m).c_str(),offDurationMin);
  }
}
void processCommand(){
  DynamicJsonDocument d(1024); if(!getFirebase(String(PUMP_ROOT)+"/command",d)) return;
  String id=d["id"] | ""; if(!id.length()||id==lastCommandId) return;
  uint64_t issued=d["issuedAt"].as<uint64_t>();
  unsigned long long nowMs=(unsigned long long)time(nullptr)*1000ULL;
  if(issued && nowMs>issued && nowMs-issued>120000ULL){ lastCommandId=id; lastCommandOk=false; lastCommandResult="Ignored expired command"; return; }
  String action=d["action"] | ""; bool state=d["state"] | false;
  if(action!="pump") { lastCommandId=id;lastCommandOk=false;lastCommandResult="Unknown command";return; }
  if(state){ timedOff=false;offUntil=0;setPump(true); }
  else { timedOff=false;offUntil=0;setPump(false); }
  lastCommandId=id;lastCommandOk=true;lastCommandResult=String("Pump ")+(state?"ON":"OFF")+" command applied";saveSettings();
}
void checkSchedule(){
  struct tm ti; if(!getLocalTime(&ti,10)){clockReady=false;return;} clockReady=true;
  time_t now=time(nullptr);
  if(timedOff && offUntil>0 && now>=offUntil){timedOff=false;offUntil=0;setPump(true);saveSettings();Serial.println("[Schedule] timed OFF finished; pump resumed");}
  if(!scheduleEnabled||timedOff) return;
  bool due=ti.tm_hour==offHour&&ti.tm_min==offMinute;
  bool triggered=lastTriggeredYear==ti.tm_year&&lastTriggeredYday==ti.tm_yday;
  if(due&&!triggered){setPump(false);timedOff=true;offUntil=now+(time_t)offDurationMin*60;
    lastTriggeredYear=ti.tm_year;lastTriggeredYday=ti.tm_yday;saveSettings();Serial.println("[Schedule] pump OFF period started");}
}
void writeStatus(){
  DynamicJsonDocument d(1536); d["pump"]=pumpIsOn; d["enabled"]=scheduleEnabled; d["clockReady"]=clockReady;
  d["offTime"]=formatTime(offHour,offMinute);d["offHour"]=offHour;d["offMinute"]=offMinute;
  d["durationMinutes"]=offDurationMin;d["remaining"]=remainingTime();d["timedOff"]=timedOff;
  d["lastSeen"]= (unsigned long long)time(nullptr)*1000ULL;d["lastCommandId"]=lastCommandId;
  d["lastCommandResult"]=lastCommandResult;d["lastCommandOk"]=lastCommandOk;
  putFirebase(String(PUMP_ROOT)+"/status",d);
}
void setup(){
  Serial.begin(115200);delay(300);pinMode(PUMP_RELAY_PIN,OUTPUT);
  digitalWrite(PUMP_RELAY_PIN,RELAY_ACTIVE_LOW?HIGH:LOW);loadSettings();setPump(false);
  setenv("TZ","PST-8",1);tzset();
  WiFi.mode(WIFI_STA);WiFi.begin(WIFI_SSID,WIFI_PASSWORD);
  Serial.printf("Connecting to Wi-Fi %s",WIFI_SSID);
  unsigned long started=millis(); while(WiFi.status()!=WL_CONNECTED&&millis()-started<20000){delay(500);Serial.print(".");}
  Serial.println();
  if(WiFi.status()==WL_CONNECTED){Serial.print("Wi-Fi IP: ");Serial.println(WiFi.localIP());configTime(0,0,"pool.ntp.org","time.google.com");}
  else Serial.println("Wi-Fi not connected; pump remains OFF until connection is restored.");
}
void loop(){
  if(WiFi.status()!=WL_CONNECTED){WiFi.reconnect();delay(200);return;}
  if(!clockReady){configTime(0,0,"pool.ntp.org","time.google.com");struct tm t;if(getLocalTime(&t,10)){setenv("TZ","PST-8",1);tzset();clockReady=true;}}
  unsigned long now=millis();
  if(now-lastCommandPoll>=COMMAND_POLL_MS){lastCommandPoll=now;processCommand();}
  if(now-lastSchedulePoll>=SCHEDULE_POLL_MS){lastSchedulePoll=now;pollSchedule();}
  checkSchedule();
  if(now-lastStatusWrite>=STATUS_WRITE_MS){lastStatusWrite=now;writeStatus();}
  delay(20);
}
