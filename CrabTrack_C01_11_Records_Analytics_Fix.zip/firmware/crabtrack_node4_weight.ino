/* ══════════════════════════════════════════════════════════
   crabtrack_node4_weight.ino — CrabTrack weight node (HX711)  v3
   ══════════════════════════════════════════════════════════
   NEW IN v3 — tare + calibrate from the WEBSITE, no Arduino IDE:

     admin.html → SCALES (TARE / CALIBRATE) → pick a compartment →
     [TARE] or [CALIBRATE with known weight].

   How it works: this node asks the Pi every COMMAND_POLL_MS
   "is there a tare/calibrate request for my compartments?"
   (GET /api/scale/pending). If so it does it on the HX711, saves the
   result, and reports back (POST /api/scale/result) so the admin page
   shows done/failed.

   • The TARE offset and CALIBRATION factor are saved in flash
     (Preferences), per load cell, so they SURVIVE A REBOOT. The old
     sketch re-tared on every boot, which zeroed whatever happened to be
     on the scale at power-up.
   • First boot ever (nothing saved yet) still tares once, so make sure
     the scales are EMPTY the first time you power this node.
   • Several load cells on one ESP32 are supported: set SCALE_COUNT and
     fill in the pin lists below. Cell 0 = compartment WEIGHT_OFFSET+1,
     cell 1 = the next compartment, and so on.
   • Serial still works as a backup:  t = tare cell 0,  t2 = tare cell 2 …

   Libraries (Arduino IDE → Library Manager):
     • HX711_ADC    by Olav Kallhovd   (version 1.2.x or newer — needs
                                        getTareOffset/setTareOffset)
     • ArduinoJson  by Benoit Blanchon (version 7)
     • PubSubClient by Nick O'Leary    (only if USE_MQTT is 1)
   ══════════════════════════════════════════════════════════ */

// ─────────── 1. IDENTITY — change this per node ───────────
#define NODE_ID       "node4"
#define NODE_LABEL    "Weight Node - Compartment C04"
#define NODE_LOCATION "Holding Tank"

// ─────────── 2. NETWORK ───────────
#define WIFI_SSID     "YourWiFiName"        // ← your real WiFi, NOT the old ESP32 hotspot
#define WIFI_PASS     "YourWiFiPassword"

#define PI_HOST       "10.193.219.111"      // Raspberry Pi's LAN IP (run `hostname -I` on the Pi)
#define PI_PORT       3000

#define USE_MQTT      0        // 0 = plain HTTP POST (simplest). 1 = MQTT.
#define MQTT_PORT     1883
#define MQTT_TOPIC    "crabtrack/" NODE_ID

#define SEND_EVERY_MS 5000     // weight changes faster than pH/EC, so report every 5s
#define COMMAND_POLL_MS 3000   // how often to ask the Pi for a tare/calibrate request

// Which compartment slot (0-based) this node's reading lands in.
// 0=C01, 1=C02, 2=C03, 3=C04 ... See docs/ADD_A_NODE.md "Weight nodes
// covering different compartments" for the full explanation.
#define WEIGHT_OFFSET 3

// How many load cells (HX711 boards) are wired to THIS ESP32, and their pins.
// One list entry per cell, same order as the compartments.
// Example for 3 cells:  SCALE_COUNT 3
//                       HX_DOUT {4, 16, 18}      HX_SCK {5, 17, 19}
#define SCALE_COUNT 1
const uint8_t HX_DOUT[SCALE_COUNT] = {4};
const uint8_t HX_SCK [SCALE_COUNT] = {5};

#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <HX711_ADC.h>
#include <Preferences.h>
#include <math.h>
#if USE_MQTT
  #include <PubSubClient.h>
  WiFiClient   mqttNet;
  PubSubClient mqtt(mqttNet);
#endif

// ─────────── HX711 objects (one per load cell) ───────────
HX711_ADC* cell[SCALE_COUNT];
Preferences preferences;
bool  scaleOk[SCALE_COUNT];
float calFactor[SCALE_COUNT];
const float DEFAULT_CAL = 87.17;      // used until you calibrate from the website

// ─────────── median filter, one per cell (same idea as before) ───────────
const int FILTER_SIZE = 20;
const float ZERO_THRESHOLD = 1.0;
struct Filter {
  float buf[FILTER_SIZE];
  int idx;
  int count;
  float value;
};
Filter flt[SCALE_COUNT];

void sortArray(float array[], int size) {
  for (int i = 0; i < size - 1; i++)
    for (int j = i + 1; j < size; j++)
      if (array[j] < array[i]) { float t = array[i]; array[i] = array[j]; array[j] = t; }
}

float getMedian(float values[], int size) {
  float temp[FILTER_SIZE];
  for (int i = 0; i < size; i++) temp[i] = values[i];
  sortArray(temp, size);
  if (size % 2 == 0) return (temp[size / 2 - 1] + temp[size / 2]) / 2.0;
  return temp[size / 2];
}

void addFilterSample(Filter& f, float value) {
  f.buf[f.idx] = value;
  f.idx = (f.idx + 1) % FILTER_SIZE;
  if (f.count < FILTER_SIZE) f.count++;
  f.value = getMedian(f.buf, f.count);
  if (fabs(f.value) < ZERO_THRESHOLD) f.value = 0.0;
}

void clearFilter(Filter& f) {
  f.idx = 0; f.count = 0; f.value = 0.0;
  for (int i = 0; i < FILTER_SIZE; i++) f.buf[i] = 0.0;
}

// ─────────── tare + calibration (run from the website, or serial "t") ───────────
String prefKey(const char* base, int i) { return String(base) + String(i); }

// Zero the scale. Everything must be OFF the load cell.
bool doTare(int i, String& msg) {
  if (!scaleOk[i]) { msg = "HX711 not responding - check wiring"; return false; }
  cell[i]->tare();                                   // blocks until done (or times out)
  if (cell[i]->getTareTimeoutFlag()) { msg = "HX711 timed out while taring - check wiring"; return false; }
  preferences.putLong(prefKey("tare", i).c_str(), cell[i]->getTareOffset());
  clearFilter(flt[i]);
  msg = "Tare complete - scale is now zero";
  Serial.printf("[scale %d] %s\n", i, msg.c_str());
  return true;
}

// Calibrate against a known weight (grams) that is ON the scale right now.
// Tare with the scale empty FIRST (the website tells you to).
bool doCalibrate(int i, float knownGrams, float& outFactor, String& msg) {
  if (!scaleOk[i]) { msg = "HX711 not responding - check wiring"; return false; }
  if (!(knownGrams > 0)) { msg = "Known weight must be greater than 0"; return false; }

  cell[i]->refreshDataSet();                         // flush old samples, read fresh ones
  float measured = cell[i]->getData();
  Serial.printf("[scale %d] calibrate: reading %.3f g for known %.3f g\n", i, measured, knownGrams);

  if (fabs(measured) < 0.5) {
    msg = "Reading is ~0. Is the known weight actually on the scale (and was it tared empty first)?";
    return false;
  }
  float newCal = calFactor[i] * (measured / knownGrams);
  if (!isfinite(newCal) || fabs(newCal) < 0.001) {
    msg = "Calculated factor is not usable - check the load cell and try again";
    return false;
  }

  calFactor[i] = newCal;
  cell[i]->setCalFactor(newCal);
  preferences.putFloat(prefKey("cal", i).c_str(), newCal);
  clearFilter(flt[i]);
  outFactor = newCal;
  msg = "Calibrated: factor " + String(newCal, 4) + " (was reading " + String(measured, 1) + " g for " + String(knownGrams, 1) + " g)";
  Serial.printf("[scale %d] %s\n", i, msg.c_str());
  return true;
}

// Serial backup:  t  → tare cell 0     t2 → tare cell 2
void checkSerialCommands() {
  if (Serial.available() == 0) return;
  String input = Serial.readStringUntil('\n');
  input.trim();
  if (input.length() >= 1 && (input[0] == 't' || input[0] == 'T')) {
    int i = (input.length() > 1) ? input.substring(1).toInt() : 0;
    if (i < 0 || i >= SCALE_COUNT) { Serial.println("No such cell."); return; }
    String msg; doTare(i, msg);
    return;
  }
  Serial.println("Serial commands: t = tare cell 0, t<n> = tare cell n. Calibrate from the website.");
}

// ═══════════════════════════════════════════════════════════
// WHAT THIS NODE MEASURES — this is the part the Pi cares about
// ═══════════════════════════════════════════════════════════
void buildPayload(JsonDocument& doc) {
  doc["node_id"]  = NODE_ID;
  doc["label"]    = NODE_LABEL;      // only used on first registration
  doc["location"] = NODE_LOCATION;
  doc["ts"]       = epochNow();
  doc["online"]   = true;

  // One entry per load cell, in compartment order, starting at WEIGHT_OFFSET.
  // A cell whose HX711 isn't answering sends null (the Pi skips it) rather than a fake 0.
  JsonArray w  = doc["weights"].to<JsonArray>();
  JsonArray cf = doc["cal_factors"].to<JsonArray>();
  for (int i = 0; i < SCALE_COUNT; i++) {
    if (scaleOk[i]) w.add(flt[i].value); else w.add(nullptr);
    cf.add(calFactor[i]);
  }
  doc["weight_offset"] = WEIGHT_OFFSET;
}

// ═══════════════════════════════════════════════════════════
// COMMANDS FROM THE WEBSITE — tare / calibrate
// ═══════════════════════════════════════════════════════════
struct ScaleCmd { long id; int slot; bool calibrate; float knownWeight; };

void reportResult(long id, bool ok, const String& msg, float calFactorValue, bool hasFactor) {
  JsonDocument doc;
  doc["id"] = id;
  doc["ok"] = ok;
  doc["message"] = msg;
  if (hasFactor) doc["calFactor"] = calFactorValue;
  String body; serializeJson(doc, body);

  HTTPClient http;
  http.begin(String("http://") + PI_HOST + ":" + PI_PORT + "/api/scale/result");
  http.setTimeout(8000);
  http.addHeader("Content-Type", "application/json");
  int code = http.POST(body);
  Serial.printf("[cmd] result for #%ld -> HTTP %d\n", id, code);
  http.end();
}

void pollCommands() {
  if (WiFi.status() != WL_CONNECTED) return;

  // 1) Ask the Pi (and finish the HTTP call BEFORE doing anything slow).
  ScaleCmd cmds[SCALE_COUNT];
  int n = 0;
  {
    HTTPClient http;
    String url = String("http://") + PI_HOST + ":" + PI_PORT + "/api/scale/pending?node_id=" + NODE_ID +
                 "&offset=" + WEIGHT_OFFSET + "&count=" + SCALE_COUNT;
    http.begin(url);
    http.setTimeout(5000);
    int code = http.GET();
    if (code == 200) {
      JsonDocument doc;
      if (!deserializeJson(doc, http.getString())) {
        for (JsonObject c : doc["commands"].as<JsonArray>()) {
          if (n >= SCALE_COUNT) break;
          int slot = c["slot"] | -1;
          if (slot < 0 || slot >= SCALE_COUNT) continue;
          cmds[n].id = c["id"] | 0L;
          cmds[n].slot = slot;
          cmds[n].calibrate = (String((const char*)(c["action"] | "")) == "calibrate");
          cmds[n].knownWeight = c["knownWeight"] | 0.0f;
          n++;
        }
      }
    }
    http.end();
  }

  // 2) Do them, then report each result.
  for (int k = 0; k < n; k++) {
    String msg; bool ok; float f = 0; bool hasF = false;
    Serial.printf("[cmd] #%ld %s cell %d\n", cmds[k].id, cmds[k].calibrate ? "CALIBRATE" : "TARE", cmds[k].slot);
    if (cmds[k].calibrate) { ok = doCalibrate(cmds[k].slot, cmds[k].knownWeight, f, msg); hasF = ok; }
    else                   { ok = doTare(cmds[k].slot, msg); }
    reportResult(cmds[k].id, ok, msg, f, hasF);
  }
}

// ═══════════════════════════════════════════════════════════
// PLUMBING — WiFi / clock / HTTP / MQTT (unchanged from the
// crabtrack_node.ino template — you shouldn't need to touch this)
// ═══════════════════════════════════════════════════════════

void syncClock() {
  configTime(8 * 3600, 0, "pool.ntp.org", "time.nist.gov");   // UTC+8, Philippines
  Serial.print("[ntp] syncing");
  for (int i = 0; i < 20 && time(nullptr) < 100000; i++) { delay(500); Serial.print("."); }
  time_t t = time(nullptr);
  Serial.println(t > 100000 ? "\n[ntp] clock set" : "\n[ntp] FAILED - ts will be 0");
}

unsigned long epochNow() {
  time_t t = time(nullptr);
  return (t > 100000) ? (unsigned long)t : 0UL;
}

void connectWiFi() {
  if (WiFi.status() == WL_CONNECTED) return;
  Serial.printf("[wifi] connecting to %s", WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 20000) {
    delay(400);
    Serial.print(".");
  }
  Serial.println(WiFi.status() == WL_CONNECTED
    ? "\n[wifi] connected, IP " + WiFi.localIP().toString()
    : "\n[wifi] FAILED - will retry next cycle");
}

bool sendHTTP(const String& json) {
  HTTPClient http;
  String url = String("http://") + PI_HOST + ":" + PI_PORT + "/api/ingest";
  http.begin(url);
  http.setTimeout(8000);
  http.addHeader("Content-Type", "application/json");
  int code = http.POST(json);
  bool ok = (code >= 200 && code < 300);
  Serial.printf("[http] POST %s -> %d %s\n", url.c_str(), code, ok ? "OK" : http.errorToString(code).c_str());
  http.end();
  return ok;
}

#if USE_MQTT
bool sendMQTT(const String& json) {
  if (!mqtt.connected()) {
    mqtt.setServer(PI_HOST, MQTT_PORT);
    Serial.print("[mqtt] connecting... ");
    if (!mqtt.connect(NODE_ID)) {
      Serial.printf("failed, rc=%d\n", mqtt.state());
      return false;
    }
    Serial.println("connected");
  }
  bool ok = mqtt.publish(MQTT_TOPIC, json.c_str());
  Serial.printf("[mqtt] %s -> %s\n", MQTT_TOPIC, ok ? "OK" : "FAILED");
  return ok;
}
#endif

// ─────────── timers ───────────
unsigned long lastSensorUpdate = 0;
const unsigned long SENSOR_INTERVAL = 100;   // read the HX711s every 100ms
unsigned long lastSend = 0;
unsigned long lastCmdPoll = 0;

void setup() {
  Serial.begin(115200);
  delay(400);
  Serial.printf("\n=== CrabTrack node \"%s\" (%s) ===\n", NODE_ID, NODE_LABEL);

  preferences.begin("loadcell", false);

  for (int i = 0; i < SCALE_COUNT; i++) {
    clearFilter(flt[i]);

    // Saved calibration. Cell 0 also accepts the old single-scale key "calFactor".
    calFactor[i] = preferences.getFloat(prefKey("cal", i).c_str(), -999.0f);
    if (calFactor[i] == -999.0f && i == 0 && preferences.isKey("calFactor")) calFactor[i] = preferences.getFloat("calFactor", DEFAULT_CAL);
    if (calFactor[i] == -999.0f) calFactor[i] = DEFAULT_CAL;
    Serial.printf("[scale %d] calibration factor %.6f\n", i, calFactor[i]);

    cell[i] = new HX711_ADC(HX_DOUT[i], HX_SCK[i]);
    cell[i]->begin();
    bool haveTare = preferences.isKey(prefKey("tare", i).c_str());

    // First ever boot: tare once. Afterwards: restore the saved tare, don't re-zero.
    cell[i]->start(2000, !haveTare);
    scaleOk[i] = !(cell[i]->getTareTimeoutFlag());
    if (!scaleOk[i]) {
      Serial.printf("[scale %d] HX711 TIMEOUT - check wiring (this cell will report null)\n", i);
      continue;
    }
    cell[i]->setCalFactor(calFactor[i]);
    if (haveTare) {
      cell[i]->setTareOffset(preferences.getLong(prefKey("tare", i).c_str(), 0));
      Serial.printf("[scale %d] restored saved tare\n", i);
    } else {
      preferences.putLong(prefKey("tare", i).c_str(), cell[i]->getTareOffset());
      Serial.printf("[scale %d] first boot: tared and saved\n", i);
    }
  }

  connectWiFi();
  if (WiFi.status() == WL_CONNECTED) syncClock();

  Serial.println("\nTare / calibrate from the website: admin.html -> SCALES.\n");
}

void loop() {
  // Keep every HX711 driver serviced each pass - no blocking delay() here.
  for (int i = 0; i < SCALE_COUNT; i++) if (scaleOk[i]) cell[i]->update();

  if (millis() - lastSensorUpdate >= SENSOR_INTERVAL) {
    lastSensorUpdate = millis();
    for (int i = 0; i < SCALE_COUNT; i++) if (scaleOk[i]) addFilterSample(flt[i], cell[i]->getData());
  }

  checkSerialCommands();
  connectWiFi();

  // Tare / calibrate requests from the website.
  if (millis() - lastCmdPoll >= COMMAND_POLL_MS) {
    lastCmdPoll = millis();
    pollCommands();
  }

  // Report weights to the Pi.
  if (millis() - lastSend >= SEND_EVERY_MS) {
    lastSend = millis();
    if (WiFi.status() == WL_CONNECTED) {
      JsonDocument doc;
      buildPayload(doc);
      String json;
      serializeJson(doc, json);
      Serial.println("[payload] " + json);
#if USE_MQTT
      sendMQTT(json);
#else
      sendHTTP(json);
#endif
    }
  }

#if USE_MQTT
  if (mqtt.connected()) mqtt.loop();
#endif
}
