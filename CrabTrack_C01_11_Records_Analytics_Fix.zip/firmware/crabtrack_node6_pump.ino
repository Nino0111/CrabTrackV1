/* ══════════════════════════════════════════════════════════
   crabtrack_node6_pump.ino — CrabTrack PUMP controller
   ══════════════════════════════════════════════════════════
   This is a SEPARATE ESP32 board from the solenoid node
   (crabtrack_node5_solenoids.ino) — on purpose. The pump and the
   drain solenoid run on independent boards, and the Pi is the one
   place that knows the full sequence, so the two boards never need
   to talk to each other directly (no MQTT needed between them):

     SCHEDULE → PUMP OFF → DRAIN SOLENOID ON → DRAIN SOLENOID OFF
     → WEIGHT TAKEN → PUMP ON

   This board does NOT decide anything itself. Every POLL_MS it asks
   the Pi the exact same question the solenoid node asks:

     GET /api/actuators/state

   ...and that response now also carries a top-level "pump" field:

     { "channels": {...}, "pump": true, "pumpMode": "auto", ... }

   The Pi computes "pump" from (see pi-server/db.js, computePumpAndDrainState):
     • any drain/weigh cycle currently in progress (admin.html →
       PUMP + AUTO DRAIN/WEIGH CYCLE) — forces the pump OFF until
       the weight-node's latest reading has actually been captured
       and logged, THEN turns it back on
     • a manual override from the dashboard (Auto / Force ON / Force OFF)

   So this firmware just:
     1. Joins WiFi.
     2. Polls GET /api/actuators/state every POLL_MS.
     3. Drives the pump relay to match "pump" in that response.
     4. Posts a heartbeat to /api/ingest so it shows up on nodes.html.
     5. SAFETY: if it can't reach the Pi for FAILSAFE_MS, it forces
        the pump back ON (the normal running state) and keeps
        retrying — a lost WiFi connection should never leave the
        pump stuck off and the water stagnant.

   Libraries needed (Arduino IDE → Library Manager):
     • ArduinoJson    by Benoit Blanchon
   ══════════════════════════════════════════════════════════ */

// ─────────── 1. IDENTITY ───────────
#define NODE_ID       "node6"
#define NODE_LABEL    "Pump Node"
#define NODE_LOCATION "Water Control"

// ─────────── 2. NETWORK — your real WiFi, same as every other node ───────────
#define WIFI_SSID     "YourWiFiName"
#define WIFI_PASS     "YourWiFiPassword"

#define PI_HOST       "crabtrackpi.local" // Resolve the Pi hostname; avoids editing firmware after DHCP IP changes
#define PI_PORT       3000

#define POLL_MS       5000     // how often to ask the Pi whether the pump should be on
#define HEARTBEAT_MS  15000    // how often to tell the Pi this node is alive
#define FAILSAFE_MS   30000    // if the Pi is unreachable this long, force the pump back ON

#include <WiFi.h>
#include <ESPmDNS.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

// ─────────── Pump relay pin ───────────
#define PUMP_PIN 4

// Relay is usually ACTIVE LOW — flip these two if yours is active-high.
#define RELAY_ON  LOW
#define RELAY_OFF HIGH

bool pumpOn = false;   // current relay state

// ─────────── apply the desired pump state, only touching the pin if it changed ───────────
void applyPump(bool wantOn) {
  if (pumpOn == wantOn) return;
  digitalWrite(PUMP_PIN, wantOn ? RELAY_ON : RELAY_OFF);
  pumpOn = wantOn;
  Serial.printf("[pump] -> %s\n", wantOn ? "ON" : "off");
}

// ─────────── WiFi + Raspberry Pi hostname resolution ───────────
bool mdnsStarted = false;

void connectWiFi() {
  if (WiFi.status() == WL_CONNECTED) return;
  Serial.printf("[wifi] connecting to %s", WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 20000) {
    delay(400);
    Serial.print(".");
  }
  Serial.println(WiFi.status() == WL_CONNECTED
    ? "\n[wifi] connected, IP " + WiFi.localIP().toString()
    : "\n[wifi] FAILED - will retry next cycle");
  if (WiFi.status() == WL_CONNECTED && !mdnsStarted) {
    mdnsStarted = MDNS.begin(NODE_ID);
    Serial.printf("[mdns] responder %s\n", mdnsStarted ? "started" : "could not start");
  }
}

bool makePiUrl(const char* path, String &url) {
  if (WiFi.status() != WL_CONNECTED) return false;
  IPAddress piIP;
  if (String(PI_HOST).endsWith(".local")) {
    piIP = MDNS.queryHost("crabtrackpi", 2000);
    if (piIP == IPAddress(0, 0, 0, 0)) {
      Serial.println("[dns] could not resolve crabtrackpi.local; check same Wi-Fi and Avahi on the Pi");
      return false;
    }
  } else if (WiFi.hostByName(PI_HOST, piIP) != 1) {
    Serial.printf("[dns] could not resolve %s\n", PI_HOST);
    return false;
  }
  url = String("http://") + piIP.toString() + ":" + PI_PORT + path;
  return true;
}

// ─────────── ask the Pi whether the pump should be on right now ───────────
// GET /api/actuators/state -> { ..., "pump": bool, "pumpMode": "auto"|"forced_on"|"forced_off" }
bool pollDesiredState() {
  if (WiFi.status() != WL_CONNECTED) return false;

  String url;
  if (!makePiUrl("/api/actuators/state", url)) return false;
  HTTPClient http;
  http.begin(url);
  http.setTimeout(6000);
  int code = http.GET();

  if (code != 200) {
    Serial.printf("[state] GET %s -> %d\n", url.c_str(), code);
    http.end();
    return false;
  }

  String body = http.getString();
  http.end();

  JsonDocument doc;
  DeserializationError err = deserializeJson(doc, body);
  if (err) {
    Serial.printf("[state] JSON parse failed: %s\n", err.c_str());
    return false;
  }

  bool wantOn = doc["pump"] | true;   // default ON if the field is somehow missing
  applyPump(wantOn);

  const char* mode = doc["pumpMode"] | "auto";
  Serial.printf("[state] pump=%s mode=%s\n", pumpOn ? "ON" : "off", mode);

  return true;
}

// ─────────── heartbeat, so this node shows ONLINE on nodes.html ───────────
void sendHeartbeat() {
  if (WiFi.status() != WL_CONNECTED) return;

  JsonDocument doc;
  doc["node_id"]  = NODE_ID;
  doc["label"]    = NODE_LABEL;
  doc["location"] = NODE_LOCATION;
  doc["online"]   = true;
  doc["pump"]     = pumpOn;

  String json;
  serializeJson(doc, json);

  String url;
  if (!makePiUrl("/api/ingest", url)) return;
  HTTPClient http;
  http.begin(url);
  http.setTimeout(6000);
  http.addHeader("Content-Type", "application/json");
  int code = http.POST(json);
  Serial.printf("[heartbeat] -> %d\n", code);
  http.end();
}

// ─────────── timers ───────────
unsigned long lastPoll = 0;
unsigned long lastHeartbeat = 0;
unsigned long lastSuccessfulPoll = 0;

void setup() {
  Serial.begin(115200);
  delay(400);
  Serial.printf("\n=== CrabTrack node \"%s\" (%s) ===\n", NODE_ID, NODE_LABEL);

  pinMode(PUMP_PIN, OUTPUT);

  // Safety: pump ON at boot, before WiFi is even up — the normal running
  // state. It only ever goes off once the Pi actively says so.
  digitalWrite(PUMP_PIN, RELAY_ON);
  pumpOn = true;
  Serial.println("[pump] ON at boot (default running state)");

  connectWiFi();
  lastSuccessfulPoll = millis();   // don't trip the failsafe immediately on boot
}

void loop() {
  connectWiFi();

  if (millis() - lastPoll >= POLL_MS) {
    lastPoll = millis();
    if (pollDesiredState()) {
      lastSuccessfulPoll = millis();
    }
  }

  if (millis() - lastHeartbeat >= HEARTBEAT_MS) {
    lastHeartbeat = millis();
    sendHeartbeat();
  }

  // ── SAFETY NET ──
  // Can't reach the Pi (WiFi down, Pi rebooting, etc.) for too long?
  // Force the pump back ON rather than risk it staying off — and the
  // water stagnant — for an unbounded amount of time.
  if (millis() - lastSuccessfulPoll > FAILSAFE_MS) {
    if (!pumpOn) {
      Serial.println("[failsafe] Pi unreachable too long — forcing pump back ON");
      applyPump(true);
    }
  }
}
