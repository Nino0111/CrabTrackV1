/* ==========================================================
   CrabTrack weight node - ONE sketch for EVERY compartment (v3)
   ==========================================================
   For each compartment's ESP32, change ONLY the line:

       #define COMP_NUM 7  // Set to 1..10 for C01..C10; flash this same sketch to each ESP32        // 1 = C01, 2 = C02 ... 7 = C07

   Everything else (node id "weight7", offset, Firebase path
   /crab_monitor/weights/C07, MQTT topic) is built from that number.

   NEW in v3
   - TARE / CALIBRATE from the website (admin.html -> SCALES),
     ONLINE through Firebase - the Raspberry Pi is NOT needed.
     Every 3 s the board checks /crab_scale/cmd/Cxx in Firebase.
     BACKUP: if Firebase can't be reached (no internet), it asks the
     Pi instead (offline / local-network mode).
   - Tare offset + calibration are saved in flash and survive a
     reboot. (Old sketch re-zeroed at every power-up, even with
     weight on the scale.) First boot ever: scale must be EMPTY.
   - Your existing saved calibration ("calFactor") is kept.
   - MQTT now publishes to crabtrack/weightN (the Pi listens on
     crabtrack/+) and includes a "weights" array (what the Pi reads).
   - Serial still works:  t  = tare      c 185 = calibrate with 185 g
     (tare first, with the scale empty, then put the weight on)

   Libraries: HX711_ADC 1.2.x or newer, ArduinoJson 7, PubSubClient,
              Firebase ESP Client (Mobizt)
   ========================================================== */

#include <WiFi.h>
#include <HTTPClient.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <Firebase_ESP_Client.h>
#include <HX711_ADC.h>
#include <Preferences.h>
#include <math.h>
#include <time.h>

// ==========================================================
// >>> THE ONLY LINE TO CHANGE PER COMPARTMENT <<<
// ==========================================================
#define COMP_NUM 7  // Set to 1..10 for C01..C10; flash this same sketch to each ESP32

#define NODE_LOCATION "Holding Tank"

// ---------- WiFi ----------
const char* WIFI_SSID     = "CrabTrack";
const char* WIFI_PASSWORD = "Crabs123";

// ---------- Raspberry Pi (MQTT broker + web server on the same Pi) ----------
const char* PI_HOST     = "10.193.219.111";
const int   PI_PORT     = 3000;      // website/API port (for tare/calibrate requests)
const char* MQTT_SERVER = "10.193.219.111";
const int   MQTT_PORT   = 1883;

// ---------- Firebase ----------
#define FIREBASE_API_KEY      "AIzaSyBBwmx81dJMxA8EBFDAGCiAwRbKjpebp5w"
#define FIREBASE_DATABASE_URL "https://crabtrack-1e256-default-rtdb.asia-southeast1.firebasedatabase.app"

// ---------- HX711 pins ----------
#define HX711_DOUT 4
#define HX711_SCK  5

// ---------- derived from COMP_NUM (built in buildNames) ----------
const int WEIGHT_OFFSET = COMP_NUM - 1;
char COMP_ID[4];
char NODE_ID[16];
char NODE_LABEL[48];
char MQTT_TOPIC[40];
char FIREBASE_PATH[48];

HX711_ADC LoadCell(HX711_DOUT, HX711_SCK);

WiFiClient espClient;
PubSubClient mqttClient(espClient);
FirebaseData fbdo;
FirebaseAuth fbAuth;
FirebaseConfig fbConfig;
Preferences preferences;

float calibrationValue = 87.17;

// ---------- median filter ----------
const int FILTER_SIZE = 20;
float filterBuffer[FILTER_SIZE];
int filterIndex = 0;
int filterCount = 0;
float filteredWeight = 0.0;
const float ZERO_THRESHOLD = 1.0;

bool firebaseInitialized = false;

// ---------- timers ----------
unsigned long lastSensorUpdate = 0;
unsigned long lastSend = 0;
unsigned long lastCmdPoll = 0;
unsigned long lastMQTTReconnect = 0;
unsigned long lastFirebaseReconnect = 0;

const unsigned long SENSOR_INTERVAL = 100;
const unsigned long SEND_INTERVAL = 5000;
const unsigned long COMMAND_POLL_MS = 3000;
const unsigned long MQTT_RECONNECT_INTERVAL = 5000;
const unsigned long FIREBASE_RECONNECT_INTERVAL = 5000;

void buildNames() {
  snprintf(COMP_ID, sizeof(COMP_ID), "C%02d", COMP_NUM);
  snprintf(NODE_ID, sizeof(NODE_ID), "weight%d", COMP_NUM);
  snprintf(NODE_LABEL, sizeof(NODE_LABEL), "Weight Node - Compartment %s", COMP_ID);
  snprintf(MQTT_TOPIC, sizeof(MQTT_TOPIC), "crabtrack/%s", NODE_ID);
  snprintf(FIREBASE_PATH, sizeof(FIREBASE_PATH), "/crab_monitor/weights/%s", COMP_ID);
}

// ==========================================================
// FILTER
// ==========================================================
void sortArray(float array[], int size) {
  for (int i = 0; i < size - 1; i++)
    for (int j = i + 1; j < size; j++)
      if (array[j] < array[i]) { float t = array[i]; array[i] = array[j]; array[j] = t; }
}

float getMedian(float values[], int size) {
  float temp[FILTER_SIZE];
  for (int i = 0; i < size; i++) temp[i] = values[i];
  sortArray(temp, size);
  if (size % 2 == 0) return (temp[size / 2 - 1] + temp[size / 2]) / 2.0;
  return temp[size / 2];
}

void addFilterSample(float value) {
  filterBuffer[filterIndex] = value;
  filterIndex++;
  if (filterIndex >= FILTER_SIZE) filterIndex = 0;
  if (filterCount < FILTER_SIZE) filterCount++;
  filteredWeight = getMedian(filterBuffer, filterCount);
  if (fabs(filteredWeight) < ZERO_THRESHOLD) filteredWeight = 0.0;
}

void clearFilter() {
  filterIndex = 0;
  filterCount = 0;
  filteredWeight = 0.0;
  for (int i = 0; i < FILTER_SIZE; i++) filterBuffer[i] = 0.0;
}

// ==========================================================
// WIFI
// ==========================================================
void connectWiFi() {
  if (WiFi.status() == WL_CONNECTED) return;

  Serial.print("\n[WiFi] Connecting to ");
  Serial.println(WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 30) {
    delay(500);
    Serial.print(".");
    attempts++;
  }
  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.print("[WiFi] CONNECTED  IP: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("[WiFi] FAILED");
  }
}

// ==========================================================
// MQTT
// ==========================================================
void mqttCallback(char* topic, byte* payload, unsigned int length) {
  // No incoming commands needed.
}

bool connectMQTT() {
  if (mqttClient.connected()) return true;
  if (WiFi.status() != WL_CONNECTED) return false;

  Serial.print("[MQTT] Connecting... ");
  String clientID = "CrabTrack_Weight";
  clientID += String(COMP_NUM);
  clientID += "_";
  clientID += String((uint32_t)ESP.getEfuseMac(), HEX);

  if (mqttClient.connect(clientID.c_str())) {
    Serial.println("CONNECTED");
    return true;
  }
  Serial.print("FAILED, rc=");
  Serial.println(mqttClient.state());
  return false;
}

String buildMQTTJSON() {
  JsonDocument doc;
  doc["node_id"] = NODE_ID;
  doc["label"] = NODE_LABEL;
  doc["location"] = NODE_LOCATION;
  doc["compartment"] = COMP_ID;
  doc["weight"] = filteredWeight;
  // Absolute UTC epoch lets the dashboard reject stale persisted values.
  time_t weightEpoch = time(nullptr);
  if (weightEpoch > 1700000000) doc["updated_at"] = (long)weightEpoch;
  doc["weights"].to<JsonArray>().add(filteredWeight);      // what the Pi reads
  doc["cal_factors"].to<JsonArray>().add(calibrationValue); // shown on the admin page
  doc["weight_offset"] = WEIGHT_OFFSET;
  doc["online"] = true;
  doc["uptime"] = millis();

  String output;
  serializeJson(doc, output);
  return output;
}

bool publishMQTT() {
  if (WiFi.status() != WL_CONNECTED) return false;
  if (!mqttClient.connected() && !connectMQTT()) return false;

  String json = buildMQTTJSON();
  if (mqttClient.publish(MQTT_TOPIC, json.c_str())) {
    Serial.print("[MQTT] Published ");
    Serial.print(COMP_ID);
    Serial.print(": ");
    Serial.println(json);
    return true;
  }
  Serial.println("[MQTT] Publish FAILED");
  return false;
}

// ==========================================================
// FIREBASE
// ==========================================================
bool initializeFirebase() {
  if (WiFi.status() != WL_CONNECTED) return false;

  Serial.println("\n[Firebase] Initializing...");
  fbConfig.api_key = FIREBASE_API_KEY;
  fbConfig.database_url = FIREBASE_DATABASE_URL;

  if (Firebase.signUp(&fbConfig, &fbAuth, "", "")) {
    Serial.println("[Firebase] Anonymous authentication OK");
  } else {
    Serial.print("[Firebase] Authentication FAILED: ");
    Serial.println(fbConfig.signer.signupError.message.c_str());
    firebaseInitialized = false;
    return false;
  }

  Firebase.begin(&fbConfig, &fbAuth);
  Firebase.reconnectWiFi(true);
  firebaseInitialized = true;
  Serial.println("[Firebase] READY");
  return true;
}

void buildFirebaseJSON(FirebaseJson& json) {
  json.clear();
  json.set("node_id", NODE_ID);
  json.set("label", NODE_LABEL);
  json.set("location", NODE_LOCATION);
  json.set("compartment", COMP_ID);
  json.set("weight", filteredWeight);
  // Additive heartbeat timestamp; existing Firebase paths and MQTT topics stay unchanged.
  time_t weightEpoch = time(nullptr);
  if (weightEpoch > 1700000000) json.set("updated_at", (long)weightEpoch);
  json.set("weight_offset", WEIGHT_OFFSET);
  json.set("cal_factor", calibrationValue);
  json.set("online", true);
  json.set("uptime", (int)millis());
}

bool publishFirebase() {
  if (!firebaseInitialized) return false;
  if (WiFi.status() != WL_CONNECTED) return false;
  if (!Firebase.ready()) return false;

  FirebaseJson json;
  buildFirebaseJSON(json);

  if (Firebase.RTDB.setJSON(&fbdo, FIREBASE_PATH, &json)) {
    Serial.print("[Firebase] ");
    Serial.print(COMP_ID);
    Serial.print(" = ");
    Serial.print(filteredWeight, 2);
    Serial.println(" g  -> OK");
    return true;
  }
  Serial.print("[Firebase] FAILED: ");
  Serial.println(fbdo.errorReason());
  return false;
}

// FIREBASE = primary, MQTT = fallback (same as before)
void sendData() {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("[DATA] WiFi offline - cannot send");
    return;
  }
  if (publishFirebase()) {
    Serial.println("[DATA] Firebase SUCCESS");
    return;
  }
  Serial.println("[DATA] Firebase unavailable - switching to MQTT...");
  if (publishMQTT()) Serial.println("[DATA] MQTT FALLBACK SUCCESS");
  else Serial.println("[DATA] Firebase + MQTT FAILED");
}

// ==========================================================
// TARE + CALIBRATE  (used by the website AND the Serial Monitor)
// ==========================================================
bool doTare(String& msg) {
  LoadCell.tare();                                  // blocks until done or timeout
  if (LoadCell.getTareTimeoutFlag()) {
    msg = "HX711 timed out while taring - check wiring";
    return false;
  }
  preferences.putLong("tareOff", LoadCell.getTareOffset());   // survives reboot
  clearFilter();
  msg = "Tare complete - scale is now zero";
  Serial.print("[TARE] ");
  Serial.println(msg);
  return true;
}

bool doCalibrate(float knownGrams, float& outFactor, String& msg) {
  if (!(knownGrams > 0)) { msg = "Known weight must be greater than 0"; return false; }

  LoadCell.refreshDataSet();                        // fresh samples
  float measured = LoadCell.getData();
  Serial.print("[CAL] reading ");
  Serial.print(measured, 3);
  Serial.print(" g for known ");
  Serial.print(knownGrams, 3);
  Serial.println(" g");

  if (fabs(measured) < 0.5) {
    msg = "Reading is ~0. Is the known weight on the scale (and was it tared empty first)?";
    return false;
  }
  float newCal = calibrationValue * (measured / knownGrams);
  if (!isfinite(newCal) || fabs(newCal) < 0.001) {
    msg = "Calculated factor is not usable - check the load cell and try again";
    return false;
  }

  calibrationValue = newCal;
  LoadCell.setCalFactor(newCal);
  preferences.putFloat("calFactor", newCal);
  clearFilter();
  outFactor = newCal;
  msg = "Calibrated: factor " + String(newCal, 4);
  Serial.print("[CAL] ");
  Serial.println(msg);
  return true;
}

void checkSerialCommands() {
  if (Serial.available() == 0) return;
  String input = Serial.readStringUntil('\n');
  input.trim();

  if (input.equalsIgnoreCase("t")) {
    String msg;
    doTare(msg);
    return;
  }
  if (input.length() > 1 && (input[0] == 'c' || input[0] == 'C')) {
    String msg;
    float f = 0;
    if (!doCalibrate(input.substring(1).toFloat(), f, msg)) Serial.println("[CAL] FAILED: " + msg);
    return;
  }
  Serial.println("\nCommands:  t = tare   |   c 185 = calibrate with a 185 g weight");
}

// ==========================================================
// REQUESTS FROM THE WEBSITE
//   1) ONLINE  : Firebase  /crab_scale/cmd/Cxx   (primary)
//   2) BACKUP  : the Pi    /api/scale/pending    (only if Firebase is unreachable)
// ==========================================================
String lastHandledId = "";
bool   cmdSynced = false;      // first Firebase read after boot only records the current command

// Run a request on the HX711.
bool runCommand(bool isCal, float known, String& msg, float& factor) {
  Serial.printf("[CMD] %s\n", isCal ? "CALIBRATE" : "TARE");
  if (isCal) return doCalibrate(known, factor, msg);
  return doTare(msg);
}

// ---------- 1) Firebase ----------
// returns 0 = Firebase unreachable, 1 = reachable but nothing to do, 2 = a new request is in id/isCal/known
int fbPollCommand(String& id, bool& isCal, float& known) {
  if (!firebaseInitialized || !Firebase.ready()) return 0;

  String path = String("/crab_scale/cmd/") + COMP_ID;
  if (!Firebase.RTDB.getJSON(&fbdo, path.c_str())) return 0;
  if (fbdo.dataType() != "json") { cmdSynced = true; return 1; }      // nothing there yet

  FirebaseJson &j = fbdo.jsonObject();
  FirebaseJsonData d;
  j.get(d, "id");
  if (!d.success) { cmdSynced = true; return 1; }
  String cid = d.to<String>();

  // SAFETY: whatever is already waiting when the board boots is NOT executed.
  if (!cmdSynced) { lastHandledId = cid; cmdSynced = true; return 1; }
  if (cid == lastHandledId) return 1;

  String action = "";
  j.get(d, "action");        if (d.success) action = d.to<String>();
  float kw = 0;
  j.get(d, "knownWeight");   if (d.success) kw = d.to<float>();
  double tsSec = 0;
  j.get(d, "tsSec");         if (d.success) tsSec = d.to<double>();

  lastHandledId = cid;

  // SAFETY: ignore a request older than 2 minutes (e.g. the board was offline when it was sent).
  time_t now = time(nullptr);
  if (now > 1700000000 && tsSec > 0 && (double)now - tsSec > 120) {
    Serial.println("[CMD] stale request ignored");
    return 1;
  }

  id = cid;
  isCal = (action == "calibrate");
  known = kw;
  if (action != "calibrate" && action != "tare") return 1;
  return 2;
}

void fbReportResult(const String& id, bool isCal, bool ok, const String& msg, float factor, bool hasFactor) {
  String base = String("/crab_scale/res/") + COMP_ID;
  FirebaseJson r;
  r.set("id", id);
  r.set("action", isCal ? "calibrate" : "tare");
  r.set("ok", ok);
  r.set("message", msg);
  if (hasFactor) r.set("calFactor", factor);
  r.set("ts/.sv", "timestamp");
  if (!Firebase.RTDB.setJSON(&fbdo, base.c_str(), &r)) {
    Serial.print("[CMD] result write failed: ");
    Serial.println(fbdo.errorReason());
  }

  if (ok) {                                           // keep "last tared / last calibrated" for the admin page
    FirebaseJson info;
    info.set(isCal ? "last_cal/.sv" : "last_tare/.sv", "timestamp");
    if (hasFactor) info.set("cal_factor", factor);
    Firebase.RTDB.updateNode(&fbdo, (String("/crab_scale/info/") + COMP_ID).c_str(), &info);
  }
}

// ---------- 2) Pi backup ----------
void piReportResult(long id, bool ok, const String& msg, float factor, bool hasFactor) {
  JsonDocument doc;
  doc["id"] = id;
  doc["ok"] = ok;
  doc["message"] = msg;
  if (hasFactor) doc["calFactor"] = factor;
  String body;
  serializeJson(doc, body);

  HTTPClient http;
  http.begin(String("http://") + PI_HOST + ":" + PI_PORT + "/api/scale/result");
  http.setTimeout(8000);
  http.addHeader("Content-Type", "application/json");
  int code = http.POST(body);
  Serial.printf("[CMD] Pi result for #%ld -> HTTP %d\n", id, code);
  http.end();
}

void piPollCommand() {
  long cmdId = 0;
  bool isCal = false;
  float known = 0;
  bool have = false;

  {
    HTTPClient http;
    String url = String("http://") + PI_HOST + ":" + PI_PORT +
                 "/api/scale/pending?node_id=" + NODE_ID +
                 "&offset=" + WEIGHT_OFFSET + "&count=1";
    http.begin(url);
    http.setTimeout(4000);
    int code = http.GET();
    if (code == 200) {
      JsonDocument doc;
      if (!deserializeJson(doc, http.getString())) {
        JsonArray arr = doc["commands"].as<JsonArray>();
        if (arr.size() > 0) {
          JsonObject c = arr[0];
          cmdId = c["id"] | 0L;
          isCal = (String((const char*)(c["action"] | "")) == "calibrate");
          known = c["knownWeight"] | 0.0f;
          have = cmdId > 0;
        }
      }
    }
    http.end();
  }
  if (!have) return;

  String msg;
  float f = 0;
  bool ok = runCommand(isCal, known, msg, f);
  piReportResult(cmdId, ok, msg, f, isCal && ok);
}

void pollCommands() {
  if (WiFi.status() != WL_CONNECTED) return;

  String id; bool isCal = false; float known = 0;
  int r = fbPollCommand(id, isCal, known);

  if (r == 2) {                                        // online request
    String msg; float f = 0;
    bool ok = runCommand(isCal, known, msg, f);
    fbReportResult(id, isCal, ok, msg, f, isCal && ok);
    return;
  }
  if (r == 1) return;                                  // Firebase works, nothing to do - Pi not needed

  piPollCommand();                                     // Firebase unreachable -> Pi backup
}

// ==========================================================
// SETUP
// ==========================================================
void setup() {
  Serial.begin(115200);
  delay(1000);
  buildNames();

  Serial.println("\n==========================================");
  Serial.print("   CRABTRACK WEIGHT NODE  ");
  Serial.println(COMP_ID);
  Serial.println("==========================================");
  Serial.print("Node ID: ");        Serial.println(NODE_ID);
  Serial.print("Firebase path: ");  Serial.println(FIREBASE_PATH);
  Serial.print("MQTT topic: ");     Serial.println(MQTT_TOPIC);

  preferences.begin("loadcell", false);

  // keeps the calibration you already saved with the old sketch
  if (preferences.isKey("calFactor")) calibrationValue = preferences.getFloat("calFactor", 87.17);
  Serial.print("[CAL] factor: ");
  Serial.println(calibrationValue, 6);

  // HX711: first boot ever = tare once; after that restore the saved tare.
  LoadCell.begin();
  bool haveTare = preferences.isKey("tareOff");
  LoadCell.start(2000, !haveTare);

  if (!haveTare && LoadCell.getTareTimeoutFlag()) {
    Serial.println("[HX711] TIMEOUT! Check HX711 wiring.");
    while (true) delay(1000);
  }

  LoadCell.setCalFactor(calibrationValue);

  if (haveTare) {
    LoadCell.setTareOffset(preferences.getLong("tareOff", 0));
    Serial.println("[HX711] restored saved tare");
  } else {
    preferences.putLong("tareOff", LoadCell.getTareOffset());
    Serial.println("[HX711] first boot: tared and saved");
  }
  Serial.println("[HX711] READY");

  mqttClient.setServer(MQTT_SERVER, MQTT_PORT);
  mqttClient.setCallback(mqttCallback);

  connectWiFi();
  if (WiFi.status() == WL_CONNECTED) {
    configTime(0, 0, "pool.ntp.org", "time.google.com");   // clock, used to ignore stale requests
    initializeFirebase();
    connectMQTT();
  }

  Serial.println("\n==========================================");
  Serial.print("   ");
  Serial.print(COMP_ID);
  Serial.println(" WEIGHT NODE READY");
  Serial.println("==========================================");
}

// ==========================================================
// LOOP
// ==========================================================
void loop() {
  LoadCell.update();   // must run continuously

  if (millis() - lastSensorUpdate >= SENSOR_INTERVAL) {
    lastSensorUpdate = millis();
    float weight = LoadCell.getData();
    if (!isnan(weight) && !isinf(weight)) addFilterSample(weight);
  }

  checkSerialCommands();

  if (WiFi.status() != WL_CONNECTED) {
    firebaseInitialized = false;
    connectWiFi();
  }

  if (WiFi.status() == WL_CONNECTED) {
    // MQTT upkeep
    if (!mqttClient.connected()) {
      if (millis() - lastMQTTReconnect >= MQTT_RECONNECT_INTERVAL) {
        lastMQTTReconnect = millis();
        connectMQTT();
      }
    } else {
      mqttClient.loop();
    }

    // Firebase upkeep
    if (!firebaseInitialized || !Firebase.ready()) {
      if (millis() - lastFirebaseReconnect >= FIREBASE_RECONNECT_INTERVAL) {
        lastFirebaseReconnect = millis();
        initializeFirebase();
      }
    }

    // tare / calibrate requests from the website (Firebase first, Pi as backup)
    if (millis() - lastCmdPoll >= COMMAND_POLL_MS) {
      lastCmdPoll = millis();
      pollCommands();
    }
  }

  if (millis() - lastSend >= SEND_INTERVAL) {
    lastSend = millis();
    Serial.print("\n[DATA] Sending ");
    Serial.print(COMP_ID);
    Serial.print("  Weight: ");
    Serial.print(filteredWeight, 2);
    Serial.println(" g");
    sendData();
  }

  delay(5);
}
