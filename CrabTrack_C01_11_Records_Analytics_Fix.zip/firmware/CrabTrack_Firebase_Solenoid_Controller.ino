/*
  CrabTrack ESP32 Solenoid Test Controller

  S1 = Drain valve 1 (GPIO 16)
  S2 = Drain valve 2 (GPIO 17)
  S3 = Freshwater   (GPIO 18)
  S4 = Saltwater    (GPIO 19)

  Features:
  - Manual ON/OFF controls for all four valves
  - ALL VALVES OFF button
  - Firebase sensor reading
  - Daily drain schedule using Philippine time (UTC+8)
  - Editable scheduled drain duration
  - Manual valve timeout: 120 seconds
  - S3/S4 mutual-exclusion interlock
  - Automatic salinity control disabled

  Required library:
  ArduinoJson by Benoit Blanchon

  IMPORTANT:
  - Test with water supply isolated first.
  - No pump interlock is implemented.
  - Schedule settings reset after reboot.
*/

#include <WiFi.h>
#include <WebServer.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <ArduinoJson.h>
#include <time.h>
#include <math.h>

// =====================================================
// 1. WIFI SETTINGS
// =====================================================

const char* WIFI_SSID = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";

// =====================================================
// 2. RELAY SETTINGS
// =====================================================

const uint8_t SOLENOID_PIN[5] = {
  255, 16, 17, 18, 19
};

const bool RELAY_ACTIVE_LOW = true;

// =====================================================
// 3. FIREBASE SETTINGS
// =====================================================

const char* FIREBASE_BASE =
  "https://crabtrack-1e256-default-rtdb.asia-southeast1.firebasedatabase.app";

const char* FIREBASE_PATH = "/crab_monitor.json";
const char* FIREBASE_API_KEY = "AIzaSyBBwmx81dJMxA8EBFDAGCiAwRbKjpebp5w";
// Create this dedicated Email/Password account in Firebase Authentication.
const char* DEVICE_EMAIL = "YOUR_ESP32_DEVICE_EMAIL";
const char* DEVICE_PASSWORD = "YOUR_ESP32_DEVICE_PASSWORD";
const char* SOLENOID_ROOT = "/solenoid_control";
const unsigned long FIREBASE_POLL_MS = 10000UL;
const unsigned long COMMAND_POLL_MS = 2500UL;

// =====================================================
// 4. SAFETY SETTINGS
// =====================================================

// Manual valve maximum ON time: 120 seconds.
const unsigned long MAX_VALVE_ON_MS = 120000UL;

// Automatic salinity control remains disabled.
const bool SALINITY_AUTOMATION_ENABLED = false;
const float TARGET_PPT = 15.0f;

// =====================================================
// 5. SERVER AND STATES
// =====================================================

WebServer server(80);

bool valveOn[5] = {
  false, false, false, false, false
};

unsigned long valveStarted[5] = {
  0, 0, 0, 0, 0
};

// Maximum ON duration for each valve.
unsigned long valveMaxOnMs[5] = {
  0,
  MAX_VALVE_ON_MS,
  MAX_VALVE_ON_MS,
  MAX_VALVE_ON_MS,
  MAX_VALVE_ON_MS
};

// Firebase status.
float firebaseReading = NAN;
bool firebaseOK = false;

String firebaseField = "Not read";
String firebaseError = "Waiting for first reading";

unsigned long lastFirebasePoll = 0;
unsigned long lastCommandPoll = 0;
unsigned long lastStatusWrite = 0;
String firebaseIdToken = "";
String firebaseRefreshToken = "";
unsigned long tokenIssuedAt = 0;
String lastCommandId = "";
String lastCommandResult = "Waiting for command";
bool lastCommandOk = true;

// Daily drain schedule.
int drainHour = 6;
int drainMinute = 0;

// Editable scheduled drain duration.
// Default: 120 seconds = 2 minutes.
unsigned long drainDurationSeconds = 120UL;

int lastDrainDay = -1;
bool scheduleEnabled = false;

// =====================================================
// 6. RELAY CONTROL
// =====================================================

void writeRelay(int ch, bool on) {
  digitalWrite(
    SOLENOID_PIN[ch],
    on
      ? (RELAY_ACTIVE_LOW ? LOW : HIGH)
      : (RELAY_ACTIVE_LOW ? HIGH : LOW)
  );
}

void setValve(int ch, bool on) {
  if (ch < 1 || ch > 4) {
    return;
  }

  // If already in the requested state, do nothing.
  if (valveOn[ch] == on) {
    return;
  }

  // Never allow freshwater and saltwater simultaneously.
  if (on && ch == 3 && valveOn[4]) {
    Serial.println(
      "BLOCKED: S3 cannot open while S4 is ON."
    );
    return;
  }

  if (on && ch == 4 && valveOn[3]) {
    Serial.println(
      "BLOCKED: S4 cannot open while S3 is ON."
    );
    return;
  }

  writeRelay(ch, on);

  if (on) {
    valveStarted[ch] = millis();

    // Manual activations default to 120 seconds.
    // The scheduled drain overrides this when triggered.
    valveMaxOnMs[ch] = MAX_VALVE_ON_MS;
  } else {
    valveMaxOnMs[ch] = MAX_VALVE_ON_MS;
  }

  valveOn[ch] = on;

  Serial.printf(
    "S%d %s\n",
    ch,
    on ? "ON" : "OFF"
  );
}

void allOff() {
  for (int ch = 1; ch <= 4; ch++) {
    writeRelay(ch, false);
    valveOn[ch] = false;
    valveMaxOnMs[ch] = MAX_VALVE_ON_MS;
  }

  Serial.println("ALL VALVES OFF");
}

// =====================================================
// 7. FIREBASE READING
// =====================================================

// Firebase Authentication REST API: device signs in as a dedicated account.
bool firebaseSignIn() {
  if (WiFi.status() != WL_CONNECTED) return false;
  WiFiClientSecure client; client.setInsecure(); // Prototype: replace with CA certificate for production.
  HTTPClient http;
  String url = String("https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=") + FIREBASE_API_KEY;
  if (!http.begin(client, url)) return false;
  http.addHeader("Content-Type", "application/json");
  DynamicJsonDocument req(512);
  req["email"] = DEVICE_EMAIL; req["password"] = DEVICE_PASSWORD; req["returnSecureToken"] = true;
  String body; serializeJson(req, body);
  int code = http.POST(body); String response = http.getString(); http.end();
  if (code != 200) { Serial.printf("Firebase device sign-in failed: HTTP %d\n", code); return false; }
  DynamicJsonDocument doc(2048);
  if (deserializeJson(doc, response)) return false;
  firebaseIdToken = doc["idToken"].as<String>();
  firebaseRefreshToken = doc["refreshToken"].as<String>();
  tokenIssuedAt = millis();
  Serial.println("Firebase device authenticated.");
  return firebaseIdToken.length() > 0;
}

bool ensureFirebaseAuth() {
  if (firebaseIdToken.length() && millis() - tokenIssuedAt < 3000000UL) return true;
  // Re-sign in periodically; this refreshes the short-lived ID token.
  firebaseIdToken = "";
  return firebaseSignIn();
}

bool firebaseGetJson(const String& path, DynamicJsonDocument& doc) {
  if (!ensureFirebaseAuth()) return false;
  WiFiClientSecure client; client.setInsecure();
  HTTPClient http;
  String url = String(FIREBASE_BASE) + path + ".json?auth=" + firebaseIdToken;
  if (!http.begin(client, url)) return false;
  http.setTimeout(6000);
  int code = http.GET(); String payload = http.getString(); http.end();
  if (code != HTTP_CODE_OK) {
    if (code == 401 || code == 403) firebaseIdToken = "";
    return false;
  }
  return !deserializeJson(doc, payload);
}

bool firebasePutJson(const String& path, JsonDocument& doc) {
  if (!ensureFirebaseAuth()) return false;
  WiFiClientSecure client; client.setInsecure();
  HTTPClient http;
  String url = String(FIREBASE_BASE) + path + ".json?auth=" + firebaseIdToken;
  if (!http.begin(client, url)) return false;
  http.addHeader("Content-Type", "application/json");
  http.setTimeout(6000);
  String payload; serializeJson(doc, payload);
  int code = http.PUT(payload); http.end();
  if (code == 401 || code == 403) firebaseIdToken = "";
  return code >= 200 && code < 300;
}

void publishSolenoidStatus() {
  if (millis() - lastStatusWrite < 10000UL) return;
  lastStatusWrite = millis();
  DynamicJsonDocument status(1024);
  status["lastSeen"] = (uint64_t)time(nullptr) * 1000ULL;
  status["online"] = true;
  JsonObject valves = status.createNestedObject("valves");
  for (int ch=1; ch<=4; ch++) valves[String("s")+ch] = valveOn[ch];
  status["lastCommandResult"] = lastCommandResult;
  status["lastCommandOk"] = lastCommandOk;
  if (firebaseOK && isfinite(firebaseReading)) {
    JsonObject sensor = status.createNestedObject("sensor");
    sensor["ec"] = firebaseReading; sensor["field"] = firebaseField;
  }
  if (!firebasePutJson(String(SOLENOID_ROOT)+"/status", status)) Serial.println("Failed to publish solenoid status.");
}

void pollSolenoidCommand() {
  if (millis() - lastCommandPoll < COMMAND_POLL_MS) return;
  lastCommandPoll = millis();
  DynamicJsonDocument doc(1024);
  if (!firebaseGetJson(String(SOLENOID_ROOT)+"/command", doc)) return;
  if (doc.isNull()) return;
  String id = doc["id"] | "";
  if (!id.length() || id == lastCommandId) return;
  lastCommandId = id;
  String action = doc["action"] | "";
  lastCommandOk = true;
  if (action == "all_off") {
    allOff(); lastCommandResult = "ALL VALVES OFF executed";
  } else if (action == "valve") {
    int ch = doc["channel"] | 0;
    bool state = doc["state"] | false;
    if (ch < 1 || ch > 4) { lastCommandOk=false; lastCommandResult="Rejected invalid valve channel"; }
    else if (state && ch == 3 && valveOn[4]) { lastCommandOk=false; lastCommandResult="Blocked: S4 is ON; S3 not opened"; }
    else if (state && ch == 4 && valveOn[3]) { lastCommandOk=false; lastCommandResult="Blocked: S3 is ON; S4 not opened"; }
    else { setValve(ch, state); lastCommandResult = String("S")+ch+(state?" ON executed":" OFF executed"); }
  } else { lastCommandOk=false; lastCommandResult="Rejected unknown command"; }
  Serial.println(lastCommandResult);
  lastStatusWrite = 0;
  publishSolenoidStatus();
}

void pollSolenoidSchedule() {
  static unsigned long lastSchedulePoll = 0;
  if (millis() - lastSchedulePoll < 15000UL) return;
  lastSchedulePoll = millis();
  DynamicJsonDocument doc(512);
  if (!firebaseGetJson(String(SOLENOID_ROOT)+"/schedule", doc) || doc.isNull()) return;
  int h = doc["hour"] | drainHour;
  int m = doc["minute"] | drainMinute;
  unsigned long dur = doc["durationSeconds"] | drainDurationSeconds;
  if (h >= 0 && h <= 23 && m >= 0 && m <= 59 && dur >= 1 && dur <= 86400) {
    drainHour = h; drainMinute = m; drainDurationSeconds = dur;
    scheduleEnabled = doc["enabled"] | false;
  }
}

void readFirebase() {
  if (WiFi.status() != WL_CONNECTED) {
    firebaseOK = false;
    firebaseError = "Wi-Fi disconnected";
    return;
  }

  WiFiClientSecure client;

  // Prototype only. Production systems should validate
  // the server certificate.
  client.setInsecure();

  HTTPClient http;

  String url = String(FIREBASE_BASE) + FIREBASE_PATH;

  http.setTimeout(6000);

  if (!http.begin(client, url)) {
    firebaseOK = false;
    firebaseError = "Could not start HTTPS connection";
    return;
  }

  int httpCode = http.GET();

  if (httpCode != HTTP_CODE_OK) {
    firebaseOK = false;
    firebaseError =
      "Firebase HTTP error: " + String(httpCode);

    http.end();
    return;
  }

  String payload = http.getString();

  http.end();

  DynamicJsonDocument doc(8192);

  DeserializationError err = deserializeJson(doc, payload);

  if (err) {
    firebaseOK = false;
    firebaseError = "Firebase JSON parsing failed";
    return;
  }

  JsonVariant node2 = doc["node2"];
  JsonVariant value = node2["ec"];

  if (value.is<float>() ||
      value.is<int>() ||
      value.is<double>()) {

    firebaseReading = value.as<float>();
    firebaseField = "node2.ec";

  } else {
    value = node2["EC"];

    if (value.is<float>() ||
        value.is<int>() ||
        value.is<double>()) {

      firebaseReading = value.as<float>();
      firebaseField = "node2.EC";

    } else {
      firebaseOK = false;
      firebaseError =
        "No numeric node2.ec or node2.EC field";
      return;
    }
  }

  if (!isfinite(firebaseReading) ||
      firebaseReading < 0 ||
      firebaseReading > 1000) {

    firebaseOK = false;
    firebaseError = "Reading outside sanity limits";
    return;
  }

  firebaseOK = true;
  firebaseError = "Connected; sensor units not verified";

  Serial.printf(
    "Firebase %s = %.3f (units unverified)\n",
    firebaseField.c_str(),
    firebaseReading
  );
}

// =====================================================
// 8. WEBPAGE
// =====================================================

String page() {
  String reading;

  if (firebaseOK) {
    reading = String(firebaseReading, 3);
  } else {
    reading = "Unavailable";
  }

  String html = R"HTML(
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="UTF-8">
<title>CrabTrack Solenoid Controller</title>

<style>
body {
  font-family: Arial, sans-serif;
  max-width: 760px;
  margin: 20px auto;
  padding: 0 14px;
  background: #f4f7fa;
  color: #172033;
}

section {
  background: white;
  padding: 16px;
  margin: 14px 0;
  border-radius: 12px;
  box-shadow: 0 2px 6px #0001;
}

h2, h3 {
  margin-top: 5px;
}

button {
  padding: 12px 16px;
  margin: 4px 2px;
  border: 0;
  border-radius: 8px;
  color: white;
  font-weight: bold;
  cursor: pointer;
}

.on-button {
  background: #16803c;
  min-width: 95px;
}

.off-button {
  background: #c62828;
  min-width: 95px;
}

.neutral-button {
  background: #555;
}

.danger-button {
  background: #b71c1c;
  width: 100%;
  margin-top: 12px;
}

.valve-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  flex-wrap: wrap;
  border-bottom: 1px solid #e1e5eb;
  padding: 12px 0;
}

.valve-name {
  min-width: 135px;
}

.valve-buttons {
  display: flex;
  gap: 4px;
}

.status-on {
  color: #16803c;
  font-weight: bold;
}

.status-off {
  color: #c62828;
  font-weight: bold;
}

input[type=time],
input[type=number] {
  padding: 10px;
  font-size: 16px;
  max-width: 100%;
}

input[type=number] {
  width: 150px;
}

small {
  color: #555;
  line-height: 1.5;
}

.notice {
  background: #fff4d6;
  padding: 10px;
  border-radius: 8px;
}
</style>
</head>

<body>

<h2>CrabTrack Solenoid Controller</h2>

<section>
<h3>Firebase Sensor Reading</h3>

<p><b>Value:</b> VALUE_PLACEHOLDER</p>
<p><b>Field:</b> FIELD_PLACEHOLDER</p>
<p><b>Status:</b> ERROR_PLACEHOLDER</p>

<small>
Reading from /crab_monitor/node2/ec,
with node2/EC as fallback.
Sensor units have not been verified as ppt.
</small>
</section>

<section>
<h3>Manual Valve Controls</h3>

<p>Press ON or OFF for each individual valve.</p>

VALVE_STATUS_PLACEHOLDER

<button class="danger-button"
        onclick="location.href='/off'">
ALL VALVES OFF
</button>

<p><small>
Manual valve activation automatically turns OFF after
120 seconds. S3 and S4 cannot be ON at the same time.
Manual opening has no cooldown.
</small></p>
</section>

<section>
<h3>Daily Drain Schedule</h3>

<form action="/schedule" method="get">

<label for="time">Daily drain time:</label>
<br>

<input type="time"
       id="time"
       name="time"
       value="TIME_PLACEHOLDER"
       required>

<p>
<label for="duration">
Drain opening duration (seconds):
</label>
<br>

<input type="number"
       id="duration"
       name="duration"
       min="1"
       max="86400"
       value="DURATION_PLACEHOLDER"
       required>

<br>
<small>
60 = 1 minute; 300 = 5 minutes.
Maximum = 86400 seconds (24 hours).
</small>
</p>

<p>
<label>
<input type="checkbox"
       name="enabled"
       value="1"
       CHECKED_PLACEHOLDER>
Enable daily drain
</label>
</p>

<button class="neutral-button" type="submit">
SAVE SCHEDULE
</button>

</form>

<p><small>
Uses Philippine time (UTC+8). At the scheduled time,
S1 and S2 open for the selected duration.
Manual opening still has a 120-second timeout.
This firmware does not implement a pump OFF interlock.
</small></p>
</section>

<section>
<h3>Automatic Salinity Control</h3>

<p><b>STATUS: DISABLED</b></p>
<p>Target: 15 ppt</p>
<p>S3 = freshwater; S4 = saltwater.</p>

<p class="notice">
Do not enable automatic dosing until the Firebase
reading is confirmed to be calibrated salinity in ppt.
The EC field may represent electrical conductivity.
</p>
</section>

</body>
</html>
)HTML";

  html.replace("VALUE_PLACEHOLDER", reading);
  html.replace("FIELD_PLACEHOLDER", firebaseField);
  html.replace("ERROR_PLACEHOLDER", firebaseError);

  // Individual valve statuses and ON/OFF buttons.
  String controls = "";

  for (int ch = 1; ch <= 4; ch++) {
    String valveName;

    if (ch == 1) {
      valveName = "Drain valve 1";
    } else if (ch == 2) {
      valveName = "Drain valve 2";
    } else if (ch == 3) {
      valveName = "Freshwater";
    } else {
      valveName = "Saltwater";
    }

    controls += "<div class='valve-row'>";

    controls += "<div class='valve-name'><b>S";
    controls += String(ch);
    controls += " - ";
    controls += valveName;
    controls += "</b><br><span class='";

    controls += valveOn[ch] ? "status-on'>" : "status-off'>";

    controls += valveOn[ch] ? "ON" : "OFF";
    controls += "</span></div>";

    controls += "<div class='valve-buttons'>";

    controls += "<form action='/valve' method='get'>";
    controls += "<input type='hidden' name='ch' value='";
    controls += String(ch);
    controls += "'>";
    controls += "<button class='on-button' type='submit' ";
    controls += "name='state' value='open'>ON</button>";
    controls += "</form>";

    controls += "<form action='/valve' method='get'>";
    controls += "<input type='hidden' name='ch' value='";
    controls += String(ch);
    controls += "'>";
    controls += "<button class='off-button' type='submit' ";
    controls += "name='state' value='close'>OFF</button>";
    controls += "</form>";

    controls += "</div></div>";
  }

  html.replace("VALVE_STATUS_PLACEHOLDER", controls);

  String timeValue =
    (drainHour < 10 ? "0" : "") +
    String(drainHour) + ":" +
    (drainMinute < 10 ? "0" : "") +
    String(drainMinute);

  html.replace("TIME_PLACEHOLDER", timeValue);
  html.replace(
    "DURATION_PLACEHOLDER",
    String(drainDurationSeconds)
  );

  html.replace(
    "CHECKED_PLACEHOLDER",
    scheduleEnabled ? "checked" : ""
  );

  return html;
}

// =====================================================
// 9. WEB HANDLERS
// =====================================================

void handleRoot() {
  server.send(200, "text/html", page());
}

void handleValve() {
  if (!server.hasArg("ch") ||
      !server.hasArg("state")) {

    server.send(
      400,
      "text/plain",
      "Missing valve number or state"
    );
    return;
  }

  int ch = server.arg("ch").toInt();
  String state = server.arg("state");

  if (ch < 1 || ch > 4) {
    server.send(400, "text/plain", "Invalid valve number");
    return;
  }

  if (state == "open") {
    if (ch == 3 && valveOn[4]) {
      server.send(
        409,
        "text/html",
        "<h3>S3 not opened</h3>"
        "<p>S4 saltwater is ON. Turn S4 OFF first.</p>"
        "<p><a href='/'>Back to controller</a></p>"
      );
      return;
    }

    if (ch == 4 && valveOn[3]) {
      server.send(
        409,
        "text/html",
        "<h3>S4 not opened</h3>"
        "<p>S3 freshwater is ON. Turn S3 OFF first.</p>"
        "<p><a href='/'>Back to controller</a></p>"
      );
      return;
    }

    setValve(ch, true);

  } else if (state == "close") {
    setValve(ch, false);

  } else {
    server.send(400, "text/plain", "Invalid valve state");
    return;
  }

  server.sendHeader("Location", "/");
  server.send(303, "text/plain", "");
}

void handleOff() {
  allOff();

  server.sendHeader("Location", "/");
  server.send(303, "text/plain", "");
}

void handleSchedule() {
  // Read scheduled time.
  if (server.hasArg("time")) {
    String t = server.arg("time");
    int colon = t.indexOf(':');

    if (colon > 0) {
      int h = t.substring(0, colon).toInt();
      int m = t.substring(colon + 1).toInt();

      if (h >= 0 && h < 24 &&
          m >= 0 && m < 60) {
        drainHour = h;
        drainMinute = m;
      }
    }
  }

  // Read editable duration in seconds.
  if (server.hasArg("duration")) {
    String durationText = server.arg("duration");
    bool digitsOnly = durationText.length() > 0;

    for (unsigned int i = 0; i < durationText.length(); i++) {
      if (!isDigit(durationText[i])) {
        digitsOnly = false;
        break;
      }
    }

    if (digitsOnly) {
      unsigned long seconds =
        strtoul(durationText.c_str(), nullptr, 10);

      if (seconds >= 1UL && seconds <= 86400UL) {
        drainDurationSeconds = seconds;
      }
    }
  }

  // Checkbox is present only when enabled.
  scheduleEnabled = server.hasArg("enabled");

  // Allow the newly saved schedule to be tested again today.
  lastDrainDay = -1;

  server.sendHeader("Location", "/");
  server.send(303, "text/plain", "");
}

// =====================================================
// 10. TIME SYNC
// =====================================================

bool timeSynced = false;
unsigned long lastNtpAttempt = 0;
const unsigned long NTP_RETRY_MS = 60000UL;

bool syncPhilippineTime() {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("Cannot sync time: Wi-Fi disconnected.");
    timeSynced = false;
    return false;
  }

  Serial.println("Attempting Philippine time sync...");

  configTime(
    8 * 3600,
    0,
    "time.google.com",
    "pool.ntp.org",
    "time.nist.gov"
  );

  struct tm timeInfo;
  unsigned long start = millis();

  while (millis() - start < 15000UL) {
    if (getLocalTime(&timeInfo, 1000) &&
        timeInfo.tm_year >= (2024 - 1900)) {

      timeSynced = true;

      Serial.printf(
        "Time synced: %04d-%02d-%02d %02d:%02d:%02d\n",
        timeInfo.tm_year + 1900,
        timeInfo.tm_mon + 1,
        timeInfo.tm_mday,
        timeInfo.tm_hour,
        timeInfo.tm_min,
        timeInfo.tm_sec
      );

      return true;
    }

    delay(250);
  }

  timeSynced = false;
  Serial.println("NTP sync failed; will retry.");
  return false;
}

void handleSync() {
  bool success = syncPhilippineTime();

  if (success) {
    server.send(
      200,
      "text/html",
      "<h3>Time synchronized!</h3>"
      "<p><a href='/'>Back to controller</a></p>"
    );
  } else {
    server.send(
      503,
      "text/html",
      "<h3>Time sync failed</h3>"
      "<p>Check Wi-Fi and internet access, then retry.</p>"
      "<p><a href='/'>Back to controller</a></p>"
    );
  }
}

// =====================================================
// 11. SETUP
// =====================================================

void setup() {
  Serial.begin(115200);

  // Configure relays and set them OFF immediately.
  for (int ch = 1; ch <= 4; ch++) {
    digitalWrite(
      SOLENOID_PIN[ch],
      RELAY_ACTIVE_LOW ? HIGH : LOW
    );

    pinMode(SOLENOID_PIN[ch], OUTPUT);

    writeRelay(ch, false);

    valveOn[ch] = false;
  }

  Serial.println();
  Serial.println("CrabTrack Solenoid Test Starting...");

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  Serial.print("Connecting to Wi-Fi");

  unsigned long wifiStart = millis();

  while (WiFi.status() != WL_CONNECTED &&
         millis() - wifiStart < 20000UL) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("Wi-Fi connected.");
    Serial.print("Open this address: http://");
    Serial.println(WiFi.localIP());

    syncPhilippineTime();
  } else {
    Serial.println("Wi-Fi connection failed.");
    Serial.println("All valves remain OFF.");
  }

  server.on("/", HTTP_GET, handleRoot);
  server.on("/valve", HTTP_GET, handleValve);
  server.on("/off", HTTP_GET, handleOff);
  server.on("/schedule", HTTP_GET, handleSchedule);
  server.on("/sync", HTTP_GET, handleSync);

  server.begin();

  if (WiFi.status() == WL_CONNECTED) {
    firebaseSignIn();
    readFirebase();
  }

  lastFirebasePoll = millis();
  lastNtpAttempt = millis();

  Serial.println("Web server started.");
  Serial.println("Manual valve timeout: 120 seconds.");
  Serial.println("S3/S4 mutual-exclusion interlock is active.");
}

// =====================================================
// 12. MAIN LOOP
// =====================================================

void loop() {
  server.handleClient();

  // Retry time sync every 60 seconds until successful.
  if (WiFi.status() == WL_CONNECTED &&
      !timeSynced &&
      millis() - lastNtpAttempt >= NTP_RETRY_MS) {

    lastNtpAttempt = millis();
    syncPhilippineTime();
  }

  // Process authenticated commands and schedule from Firebase.
  if (WiFi.status() == WL_CONNECTED) {
    pollSolenoidCommand();
    pollSolenoidSchedule();
    publishSolenoidStatus();
  }

  // Poll Firebase periodically.
  if (millis() - lastFirebasePoll >= FIREBASE_POLL_MS) {
    lastFirebasePoll = millis();

    if (WiFi.status() == WL_CONNECTED) {
      readFirebase();
    } else {
      firebaseOK = false;
      firebaseError = "Wi-Fi disconnected";
    }
  }

  // Automatic valve shutoff.
  // Manual activations: 120 seconds.
  // Scheduled S1/S2 activations: selected dashboard duration.
  for (int ch = 1; ch <= 4; ch++) {
    if (valveOn[ch] &&
        millis() - valveStarted[ch] >= valveMaxOnMs[ch]) {

      Serial.printf(
        "Safety timeout: S%d turning OFF.\n",
        ch
      );

      setValve(ch, false);
    }
  }

  // Daily drain schedule; only run when time is synchronized.
  if (scheduleEnabled && timeSynced) {
    struct tm timeInfo;

    if (getLocalTime(&timeInfo, 10)) {
      if (timeInfo.tm_hour == drainHour &&
          timeInfo.tm_min == drainMinute &&
          timeInfo.tm_yday != lastDrainDay) {

        // Record the day to prevent repeated triggering
        // during the same scheduled minute.
        lastDrainDay = timeInfo.tm_yday;

        Serial.println("Daily drain schedule triggered.");

        setValve(1, true);
        setValve(2, true);

        // Apply selected duration to valves that actually opened.
        unsigned long scheduledDurationMs =
          drainDurationSeconds * 1000UL;

        if (valveOn[1]) {
          valveMaxOnMs[1] = scheduledDurationMs;
        }

        if (valveOn[2]) {
          valveMaxOnMs[2] = scheduledDurationMs;
        }

        Serial.printf(
          "Scheduled drain duration: %lu seconds\n",
          drainDurationSeconds
        );
      }
    }
  }

  // If Wi-Fi disconnects, turn all valves OFF.
  static bool wasConnected = false;

  bool connected = (WiFi.status() == WL_CONNECTED);

  if (wasConnected && !connected) {
    Serial.println("Wi-Fi lost: forcing all valves OFF.");
    allOff();
    timeSynced = false;
  }

  wasConnected = connected;
}