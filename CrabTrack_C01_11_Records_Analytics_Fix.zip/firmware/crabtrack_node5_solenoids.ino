/* ══════════════════════════════════════════════════════════
   crabtrack_node5_solenoids.ino — CrabTrack solenoid controller
   ══════════════════════════════════════════════════════════
   This replaces your old sketch's own WiFi hotspot + button web page.
   Instead, this node joins your real WiFi and repeatedly asks the Pi
   "what should be open right now?" — the Pi decides based on:

     • TIME SCHEDULES you set on admin.html, e.g.
         "channels 1,2 open at 06:00 for 5 minutes"
     • SALINITY RULES you set on admin.html, e.g.
         "channel 3 opens when salinity drops below 25 (adds saltwater)"
         "channel 4 opens when salinity rises above 35 (adds freshwater)"

   You never edit this file to change timing or thresholds — that's
   all done from the website.

   NOTE — pump + drain auto-weigh cycle: whichever channel you pick as
   the "drain channel" on admin.html → PUMP + AUTO DRAIN/WEIGH CYCLE
   gets forced open by the Pi during that step of the sequence, the
   exact same way a time schedule or sensor rule would — this sketch
   needs NO changes for that to work, since it already just mirrors
   whatever GET /api/actuators/state says for channels 1-4. The pump
   itself lives on a separate board; see crabtrack_node6_pump.ino.

   This sketch just:
     1. Joins WiFi.
     2. Polls GET /api/actuators/state every POLL_MS.
     3. Drives the 4 relay pins to match what the Pi says.
     4. Posts a heartbeat to /api/ingest so it shows up on nodes.html.
     5. SAFETY: if it can't reach the Pi for FAILSAFE_MS, it turns
        every solenoid OFF and keeps retrying — a lost WiFi connection
        should never mean a solenoid stays stuck open.

   Libraries needed (Arduino IDE → Library Manager):
     • ArduinoJson    by Benoit Blanchon
   ══════════════════════════════════════════════════════════ */

// ─────────── 1. IDENTITY ───────────
#define NODE_ID       "node5"
#define NODE_LABEL    "Solenoid Node"
#define NODE_LOCATION "Water Control"

// ─────────── 2. NETWORK — your real WiFi, not the old CrabTrack hotspot ───────────
#define WIFI_SSID     "YourWiFiName"
#define WIFI_PASS     "YourWiFiPassword"

#define PI_HOST       "crabtrackpi.local" // Resolve the Pi hostname; avoids editing firmware after DHCP IP changes
#define PI_PORT       3000

#define POLL_MS       5000     // how often to ask the Pi what should be open
#define HEARTBEAT_MS  15000    // how often to tell the Pi this node is alive
#define FAILSAFE_MS   30000    // if the Pi is unreachable this long, force everything OFF

#include <WiFi.h>
#include <ESPmDNS.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

// ─────────── Solenoid pins (same wiring as your old sketch) ───────────
#define SOLENOID_1 16
#define SOLENOID_2 17
#define SOLENOID_3 18
#define SOLENOID_4 19

// Relay is usually ACTIVE LOW
#define RELAY_ON  LOW
#define RELAY_OFF HIGH

const int SOLENOID_PIN[5] = { -1, SOLENOID_1, SOLENOID_2, SOLENOID_3, SOLENOID_4 }; // 1-based
bool channelState[5] = { false, false, false, false, false };                       // current relay state

// ─────────── turn everything off (used at boot and on failsafe) ───────────
void allOff() {
  for (int ch = 1; ch <= 4; ch++) {
    digitalWrite(SOLENOID_PIN[ch], RELAY_OFF);
    channelState[ch] = false;
  }
}

// Apply a single channel's desired state, only touching pins that changed.
void applyChannel(int ch, bool wantOn) {
  if (channelState[ch] == wantOn) return;
  digitalWrite(SOLENOID_PIN[ch], wantOn ? RELAY_ON : RELAY_OFF);
  channelState[ch] = wantOn;
  Serial.printf("[relay] channel %d -> %s\n", ch, wantOn ? "ON" : "off");
}

// ─────────── WiFi + Raspberry Pi hostname resolution ───────────
bool mdnsStarted = false;

void connectWiFi() {
  if (WiFi.status() == WL_CONNECTED) return;
  Serial.printf("[wifi] connecting to %s", WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 20000) {
    delay(400);
    Serial.print(".");
  }
  Serial.println(WiFi.status() == WL_CONNECTED
    ? "\n[wifi] connected, IP " + WiFi.localIP().toString()
    : "\n[wifi] FAILED - will retry next cycle");
  if (WiFi.status() == WL_CONNECTED && !mdnsStarted) {
    mdnsStarted = MDNS.begin(NODE_ID);
    Serial.printf("[mdns] responder %s\n", mdnsStarted ? "started" : "could not start");
  }
}

bool makePiUrl(const char* path, String &url) {
  if (WiFi.status() != WL_CONNECTED) return false;
  IPAddress piIP;
  if (String(PI_HOST).endsWith(".local")) {
    piIP = MDNS.queryHost("crabtrackpi", 2000);
    if (piIP == IPAddress(0, 0, 0, 0)) {
      Serial.println("[dns] could not resolve crabtrackpi.local; check same Wi-Fi and Avahi on the Pi");
      return false;
    }
  } else if (WiFi.hostByName(PI_HOST, piIP) != 1) {
    Serial.printf("[dns] could not resolve %s\n", PI_HOST);
    return false;
  }
  url = String("http://") + piIP.toString() + ":" + PI_PORT + path;
  return true;
}

// ─────────── ask the Pi what should be open right now ───────────
// GET /api/actuators/state -> { channels: {"1":bool,"2":bool,"3":bool,"4":bool}, salinity: n, ts: "..." }
bool pollDesiredState() {
  if (WiFi.status() != WL_CONNECTED) return false;

  String url;
  if (!makePiUrl("/api/actuators/state", url)) return false;
  HTTPClient http;
  http.begin(url);
  http.setTimeout(6000);
  int code = http.GET();

  if (code != 200) {
    Serial.printf("[state] GET %s -> %d\n", url.c_str(), code);
    http.end();
    return false;
  }

  String body = http.getString();
  http.end();

  JsonDocument doc;
  DeserializationError err = deserializeJson(doc, body);
  if (err) {
    Serial.printf("[state] JSON parse failed: %s\n", err.c_str());
    return false;
  }

  JsonObject channels = doc["channels"];
  for (int ch = 1; ch <= 4; ch++) {
    bool wantOn = channels[String(ch)] | false;
    applyChannel(ch, wantOn);
  }

  float sal = doc["salinity"] | NAN;
  if (!isnan(sal)) Serial.printf("[state] salinity=%.2f  CH1=%d CH2=%d CH3=%d CH4=%d\n",
      sal, channelState[1], channelState[2], channelState[3], channelState[4]);

  return true;
}

// ─────────── heartbeat, so this node shows ONLINE on nodes.html ───────────
void sendHeartbeat() {
  if (WiFi.status() != WL_CONNECTED) return;

  JsonDocument doc;
  doc["node_id"]  = NODE_ID;
  doc["label"]    = NODE_LABEL;
  doc["location"] = NODE_LOCATION;
  doc["online"]   = true;
  JsonObject channels = doc["channels"].to<JsonObject>();
  for (int ch = 1; ch <= 4; ch++) channels[String(ch)] = channelState[ch];

  String json;
  serializeJson(doc, json);

  String url;
  if (!makePiUrl("/api/ingest", url)) return;
  HTTPClient http;
  http.begin(url);
  http.setTimeout(6000);
  http.addHeader("Content-Type", "application/json");
  int code = http.POST(json);
  Serial.printf("[heartbeat] -> %d\n", code);
  http.end();
}

// ─────────── timers ───────────
unsigned long lastPoll = 0;
unsigned long lastHeartbeat = 0;
unsigned long lastSuccessfulPoll = 0;

void setup() {
  Serial.begin(115200);
  delay(400);
  Serial.printf("\n=== CrabTrack node \"%s\" (%s) ===\n", NODE_ID, NODE_LABEL);

  pinMode(SOLENOID_1, OUTPUT);
  pinMode(SOLENOID_2, OUTPUT);
  pinMode(SOLENOID_3, OUTPUT);
  pinMode(SOLENOID_4, OUTPUT);

  // Safety: everything OFF at startup, before WiFi is even up.
  allOff();
  Serial.println("[relay] all solenoids OFF at boot");

  connectWiFi();
  lastSuccessfulPoll = millis();   // don't trip the failsafe immediately on boot
}

void loop() {
  connectWiFi();

  if (millis() - lastPoll >= POLL_MS) {
    lastPoll = millis();
    if (pollDesiredState()) {
      lastSuccessfulPoll = millis();
    }
  }

  if (millis() - lastHeartbeat >= HEARTBEAT_MS) {
    lastHeartbeat = millis();
    sendHeartbeat();
  }

  // ── SAFETY NET ──
  // Can't reach the Pi (WiFi down, Pi rebooting, etc.) for too long?
  // Force every solenoid off rather than risk one stuck open unattended.
  if (millis() - lastSuccessfulPoll > FAILSAFE_MS) {
    if (channelState[1] || channelState[2] || channelState[3] || channelState[4]) {
      Serial.println("[failsafe] Pi unreachable too long — forcing all solenoids OFF");
      allOff();
    }
  }
}
