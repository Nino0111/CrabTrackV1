// ══════════════════════════════════════════════════════════
// server.js — CrabTrack Raspberry Pi backend (v2)
// ESP32 Nodes → Wi-Fi/MQTT/HTTP → THIS SERVER → SQLite → API → Website/App
// ══════════════════════════════════════════════════════════
// Run on the Pi:  npm install && npm start
// Config lives in pi-server/.env (copy .env.example). Everything is
// optional — with no .env at all the server runs fully offline on the LAN.

try { require('dotenv').config({ path: require('path').join(__dirname, '.env') }); } catch (_) {}

const path = require('path');
const express = require('express');
const cors = require('cors');
const cron = require('node-cron');
const store = require('./db');
const notify = require('./notify');
const cloud = require('./cloud-sync');
const auth = require('./auth');
const { requireAdmin } = auth;

const PORT = process.env.PORT || 3000;
const COMP_COUNT = parseInt(process.env.COMP_COUNT, 10) || 10;
const COMP_IDS = Array.from({ length: COMP_COUNT }, (_, i) => `C${String(i + 1).padStart(2, '0')}`);
const FEED_WARN_HOURS  = parseFloat(process.env.FEED_WARN_HOURS  || '24');
const FEED_ALERT_HOURS = parseFloat(process.env.FEED_ALERT_HOURS || '48');
const NOTIFY_FEEDING   = process.env.NOTIFY_FEEDING !== 'off';

const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));

// Serve the dashboard straight from the Pi: http://<pi-ip>:3000/
const webDir = process.env.CRABTRACK_WEB_DIR || path.join(__dirname, '..', 'crabtrack');
app.use(express.static(webDir, {
  setHeaders(res, filePath) {
    // The service worker must never be cached, or app updates won't land.
    if (filePath.endsWith('sw.js')) res.setHeader('Cache-Control', 'no-cache');
  },
}));

const ok   = (res, data) => res.json(data);
const fail = (res, e, code = 400) => res.status(code).json({ ok: false, error: e.message || String(e) });

// ══════════════ Status & data ══════════════
app.get('/api/status', (req, res) => ok(res, { ...store.getStatus(), cloud: cloud.status(), notify_channels: notify.availableChannels() }));
app.get('/api/data',   (req, res) => ok(res, store.getLatestData()));
app.get('/api/history',(req, res) => ok(res, store.getHistory(parseFloat(req.query.hours) || 24)));

// ══════════════ NODES — add/list/edit/remove ══════════════
// This is the "adding a node is easy now" part. See docs/ADD_A_NODE.md.
app.get('/api/nodes', (req, res) => ok(res, store.listNodes()));

app.get('/api/nodes/:id', (req, res) => {
  const n = store.getNode(req.params.id);
  if (!n) return res.status(404).json({ ok: false, error: 'node not found' });
  ok(res, n);
});

// POST /api/nodes  { nodeId, label, location, capabilities:["ph"], offlineAfter }
app.post('/api/nodes', (req, res) => {
  try {
    const b = req.body || {};
    const nodeId = b.nodeId || b.node_id;
    if (!nodeId) throw new Error('nodeId required');
    if (!/^[A-Za-z0-9_-]{1,32}$/.test(nodeId)) throw new Error('nodeId must be 1-32 chars: letters, numbers, - or _');
    const node = store.upsertNode({
      node_id: nodeId,
      label: b.label,
      location: b.location,
      capabilities: b.capabilities,
      enabled: b.enabled,
      offline_after: b.offlineAfter,
    });
    ok(res, { ok: true, node });
  } catch (e) { fail(res, e); }
});

app.patch('/api/nodes/:id', (req, res) => {
  try {
    const b = req.body || {};
    if (!store.getNode(req.params.id)) throw new Error('node not found');
    ok(res, { ok: true, node: store.upsertNode({
      node_id: req.params.id,
      label: b.label, location: b.location, capabilities: b.capabilities,
      enabled: b.enabled, offline_after: b.offlineAfter,
    }) });
  } catch (e) { fail(res, e); }
});

app.delete('/api/nodes/:id', (req, res) => {
  try { store.deleteNode(req.params.id); ok(res, { ok: true }); } catch (e) { fail(res, e); }
});

app.get('/api/nodes/:id/history', (req, res) => {
  ok(res, store.getNodeHistory(req.params.id, parseFloat(req.query.hours) || 24, parseInt(req.query.limit, 10) || 500));
});

// ══════════════ Ingest (ESP32 → Pi) ══════════════
// Preferred body: { "node_id": "node4", "ph": 7.8 }
// An unknown node_id auto-registers itself — no server edit needed.
app.post('/api/ingest', (req, res) => {
  try { ok(res, { ok: true, ts: store.ingestReading(req.body || {}) }); } catch (e) { fail(res, e); }
});

// ══════════════ Offline-sync log endpoints ══════════════
app.post('/api/feed', (req, res) => {
  try {
    const { compId, type, amount, note, date, source } = req.body || {};
    if (!compId) throw new Error('compId required');
    store.logFeed({ compId, type, amount, note, date, source });
    ok(res, { ok: true });
  } catch (e) { fail(res, e); }
});

app.post('/api/weight', (req, res) => {
  try {
    const { compId, weight, note, date, source } = req.body || {};
    if (!compId || typeof weight !== 'number') throw new Error('compId and numeric weight required');
    store.logWeight({ compId, weight, note, date, source });
    ok(res, { ok: true });
  } catch (e) { fail(res, e); }
});

app.post('/api/obs', (req, res) => {
  try {
    const { compId, type, note, date } = req.body || {};
    if (!compId) throw new Error('compId required');
    store.logObs({ compId, type, note, date });
    ok(res, { ok: true });
  } catch (e) { fail(res, e); }
});

app.get('/api/feed-history', (req, res) =>
  ok(res, store.getFeedHistory(req.query.compId, parseInt(req.query.limit, 10) || 50)));

// ══════════════ FEEDING SCHEDULE ══════════════
app.get('/api/schedule', (req, res) => ok(res, store.listSchedules()));

// POST /api/schedule { time:"07:00", label:"Morning feed", compIds:"all", days:"daily", graceMinutes:60 }
app.post('/api/schedule', (req, res) => {
  try { ok(res, { ok: true, id: store.addSchedule(req.body || {}) }); } catch (e) { fail(res, e); }
});

app.patch('/api/schedule/:id', (req, res) => {
  try { store.updateSchedule(parseInt(req.params.id, 10), req.body || {}); ok(res, { ok: true }); } catch (e) { fail(res, e); }
});

app.delete('/api/schedule/:id', (req, res) => {
  try { store.deleteSchedule(parseInt(req.params.id, 10)); ok(res, { ok: true }); } catch (e) { fail(res, e); }
});

// Everything due right now — combines schedule rules AND the interval rule.
app.get('/api/feeding-alerts', (req, res) => {
  const warnHours  = parseFloat(req.query.warnHours)  || FEED_WARN_HOURS;
  const alertHours = parseFloat(req.query.alertHours) || FEED_ALERT_HOURS;
  ok(res, {
    now: new Date().toISOString(),
    scheduled: store.checkScheduledFeedings({ allCompIds: COMP_IDS }),
    interval: store.checkFeedingAlerts({ compIds: COMP_IDS, warnHours, alertHours }),
  });
});

app.get('/api/alerts', (req, res) => ok(res, store.getAlerts(parseInt(req.query.limit, 10) || 50)));

// ══════════════ ACTUATORS (solenoids) ══════════════
// Time schedules — "channels 1,2 open at 06:00 for 5 min"
app.get('/api/actuators/schedule', (req, res) => ok(res, store.listActuatorSchedules()));

// POST { label, time:"06:00", days:"daily", channels:[1,2], durationMinutes:5, pumpOffMinutes:5 }
// (pumpOffMinutes > 0 also holds the pump OFF for that long from the start time)
app.post('/api/actuators/schedule', requireAdmin, (req, res) => {
  try { ok(res, { ok: true, id: store.addActuatorSchedule(req.body || {}) }); } catch (e) { fail(res, e); }
});
app.patch('/api/actuators/schedule/:id', requireAdmin, (req, res) => {
  try { store.updateActuatorSchedule(parseInt(req.params.id, 10), req.body || {}); ok(res, { ok: true }); } catch (e) { fail(res, e); }
});
app.delete('/api/actuators/schedule/:id', requireAdmin, (req, res) => {
  try { store.deleteActuatorSchedule(parseInt(req.params.id, 10)); ok(res, { ok: true }); } catch (e) { fail(res, e); }
});

// Sensor rules — "channel 3 opens when salinity drops below 25"
app.get('/api/actuators/rules', (req, res) => ok(res, store.listActuatorRules()));

// POST { label, channel:3, source:"salinity", condition:"below", threshold:25, stopThreshold:30, durationMinutes:10, cooldownMinutes:10 }
// Opens when the reading crosses `threshold`, closes when it reaches `stopThreshold` (the optimal level).
app.post('/api/actuators/rules', requireAdmin, (req, res) => {
  try { ok(res, { ok: true, id: store.addActuatorRule(req.body || {}) }); } catch (e) { fail(res, e); }
});
app.patch('/api/actuators/rules/:id', requireAdmin, (req, res) => {
  try { store.updateActuatorRule(parseInt(req.params.id, 10), req.body || {}); ok(res, { ok: true }); } catch (e) { fail(res, e); }
});
app.delete('/api/actuators/rules/:id', requireAdmin, (req, res) => {
  try { store.deleteActuatorRule(parseInt(req.params.id, 10)); ok(res, { ok: true }); } catch (e) { fail(res, e); }
});

// What should be open RIGHT NOW — polled by the solenoid ESP32, and by
// the dashboard for a live view. Combines schedules + sensor rules, AND
// any pump/drain auto-weigh cycle currently in progress (which can force
// a channel open regardless of the rules above) plus the pump's own
// desired state ({ pump: true|false }), polled by the separate pump board.
app.get('/api/actuators/state', (req, res) => {   // open: the solenoid + pump ESP32s poll this
  const state = store.computeActuatorState();
  const cycle = store.computePumpAndDrainState();
  Object.entries(cycle.drainChannels).forEach(([ch, on]) => {
    if (on) { state.channels[ch] = true; state.reasons[ch] = 'drain-cycle'; }
  });
  state.pump = cycle.pumpOn;
  // Do not tie solenoids 1/2 to pump state: during a drain cycle they must
  // open while the pump is OFF. The Pi independently decides both states.
  state.pumpMode = cycle.pumpMode;
  state.activeCycles = cycle.activeCycles;
  ok(res, state);
});
app.get('/api/actuators/history', (req, res) =>
  ok(res, store.getActuatorHistory(
    req.query.channel ? parseInt(req.query.channel, 10) : null,
    parseInt(req.query.limit, 10) || 50
  )));

// ══════════════ ADMIN LOGIN ══════════════
// Unlocks the control routes above (schedules, rules, pump, drain cycle, tare/calibrate).
app.post('/api/admin/setup',    auth.setup);                    // first run only
app.post('/api/admin/login',    auth.login);
app.post('/api/admin/password', requireAdmin, auth.changePassword);
app.post('/api/admin/logout', auth.logout);
app.get('/api/admin/session', auth.session);

// ══════════════ SCALE TARE / CALIBRATE (from the website) ══════════════
// Admin side (login required):
//   POST /api/scale/command  { compId:"C04", action:"tare" }
//   POST /api/scale/command  { compId:"C04", action:"calibrate", knownWeight:200 }   // grams
app.post('/api/scale/command', requireAdmin, (req, res) => {
  try {
    const b = req.body || {};
    const compId = String(b.compId || '').toUpperCase();
    if (!COMP_IDS.includes(compId)) throw new Error(`Unknown compartment "${b.compId}" (valid: ${COMP_IDS[0]}-${COMP_IDS[COMP_IDS.length - 1]})`);
    ok(res, { ok: true, id: store.queueScaleCommand({ compId, action: b.action, knownWeight: b.knownWeight }) });
  } catch (e) { fail(res, e); }
});
app.get('/api/scale/commands', (req, res) => ok(res, store.listScaleCommands(parseInt(req.query.limit, 10) || 20)));
app.get('/api/scale/state',    (req, res) => ok(res, store.listScaleState()));

// Node side (open on the LAN, like /api/ingest - the ESP32 has no login):
//   GET  /api/scale/pending?node_id=node4&offset=3&count=1  → what to do now
//   POST /api/scale/result   { id, ok, message, calFactor }
app.get('/api/scale/pending', (req, res) => {
  const offset = Math.max(0, parseInt(req.query.offset, 10) || 0);
  const count  = Math.max(1, parseInt(req.query.count, 10) || 1);
  ok(res, { commands: store.pendingScaleCommands(offset, count) });
});
app.post('/api/scale/result', (req, res) => {
  try {
    const b = req.body || {};
    store.completeScaleCommand(parseInt(b.id, 10), !!b.ok, String(b.message || '').slice(0, 300), b.calFactor);
    ok(res, { ok: true });
  } catch (e) { fail(res, e); }
});

// ══════════════ PUMP + DRAIN-SOLENOID AUTO WEIGH-CYCLE ══════════════
// See docs/PUMP_DRAIN_CYCLE.md for the full sequence this drives:
//   SCHEDULE → PUMP OFF → DRAIN SOLENOID ON → DRAIN SOLENOID OFF →
//   WEIGHT TAKEN → PUMP ON
app.get('/api/drain-cycle/schedule', (req, res) => ok(res, store.listDrainSchedules()));

// POST { label, time:"06:00", days:"daily", drainChannels:[1,2], pumpLeadSeconds:0, drainMinutes:2, settleSeconds:20, compId:"ALL" }
app.post('/api/drain-cycle/schedule', requireAdmin, (req, res) => {
  try { ok(res, { ok: true, id: store.addDrainSchedule(req.body || {}) }); } catch (e) { fail(res, e); }
});
app.patch('/api/drain-cycle/schedule/:id', requireAdmin, (req, res) => {
  try { store.updateDrainSchedule(parseInt(req.params.id, 10), req.body || {}); ok(res, { ok: true }); } catch (e) { fail(res, e); }
});
app.delete('/api/drain-cycle/schedule/:id', requireAdmin, (req, res) => {
  try { store.deleteDrainSchedule(parseInt(req.params.id, 10)); ok(res, { ok: true }); } catch (e) { fail(res, e); }
});

// Trigger one cycle immediately — e.g. a "Run cycle now" button.
// POST { drainChannels:[1,2], pumpLeadSeconds:0, drainMinutes:2, settleSeconds:20, compId:"ALL" }
app.post('/api/drain-cycle/run-now', requireAdmin, (req, res) => {
  try { ok(res, { ok: true, id: store.queueManualDrainCycle(req.body || {}) }); } catch (e) { fail(res, e); }
});

app.get('/api/drain-cycle/log', (req, res) => ok(res, store.getDrainCycleHistory(parseInt(req.query.limit, 10) || 50)));

// ══════════════ PUMP (manual override) ══════════════
// GET current pump state + whether it's auto, forced on, or forced off.
app.get('/api/pump', (req, res) => {
  const state = store.computePumpAndDrainState();
  ok(res, { pumpOn: state.pumpOn, mode: state.pumpMode, activeCycles: state.activeCycles });
});
// POST { mode: "auto" | "forced_on" | "forced_off" } — e.g. a dashboard toggle.
// A forced mode wins over any in-progress cycle, so use it for maintenance only.
app.post('/api/pump', requireAdmin, (req, res) => {
  try { ok(res, { ok: true, override: store.setPumpOverride((req.body || {}).mode) }); } catch (e) { fail(res, e); }
});
app.get('/api/pump/history', (req, res) => ok(res, store.getPumpHistory(parseInt(req.query.limit, 10) || 50)));

// ══════════════ MESSAGE BUTTON ══════════════
// The dashboard's "Send Message" button posts here.
app.post('/api/message', (req, res) => {
  try {
    const { body, text, channel, target } = req.body || {};
    const msg = (body || text || '').trim();
    if (!msg) throw new Error('message body required');
    if (msg.length > 2000) throw new Error('message too long (max 2000 chars)');
    ok(res, notify.send(msg, { channel, target }));
  } catch (e) { fail(res, e); }
});

app.get('/api/messages', (req, res) =>
  ok(res, { channels: notify.availableChannels(), default: notify.defaultChannel(), outbox: store.getOutbox(parseInt(req.query.limit, 10) || 50) }));

app.post('/api/messages/flush', async (req, res) => { await notify.flush(); ok(res, { ok: true }); });

// ══════════════ Background jobs ══════════════

// Feeding check every 5 minutes: schedule-based first, interval as backstop.
cron.schedule('*/5 * * * *', () => {
  try {
    const scheduled = store.checkScheduledFeedings({ allCompIds: COMP_IDS });
    const interval  = store.checkFeedingAlerts({ compIds: COMP_IDS, warnHours: FEED_WARN_HOURS, alertHours: FEED_ALERT_HOURS });

    [...scheduled, ...interval].forEach(a => {
      if (store.alertSentRecently(a.msg, 55)) return;   // one reminder per hour, per message
      store.recordAlert({
        sensor: `${a.compId} Feeding`,
        val: a.minutesLate != null ? `${a.minutesLate}m late` : (a.hoursSinceFed != null ? `${a.hoursSinceFed}h` : 'never fed'),
        threshold: a.dueAt ? `due ${a.dueAt}` : `${FEED_WARN_HOURS}h`,
        level: a.level,
        msg: a.msg,
      });
      console.log('[feeding]', a.msg);
      if (NOTIFY_FEEDING) notify.send(a.msg);           // → phone, or queued if offline
    });
  } catch (e) {
    console.error('[feeding] check failed:', e.message);
  }
});

// Node offline watch — tells you when an ESP32 stops reporting.
cron.schedule('*/5 * * * *', () => {
  try {
    store.listNodes().filter(n => n.enabled && n.lastSeen && !n.online).forEach(n => {
      const msg = `📡 Node offline — ${n.label} (${n.nodeId}) last reported ${Math.round(n.secondsSinceSeen / 60)} min ago.`;
      if (store.alertSentRecently(msg, 55)) return;
      store.recordAlert({ sensor: n.nodeId, val: 'offline', threshold: `${n.offlineAfter}s`, level: 'alert', msg });
      console.log('[nodes]', msg);
      notify.send(msg);
    });
  } catch (e) { console.error('[nodes] watch failed:', e.message); }
});

// ══════════════ Optional integrations ══════════════
if (process.env.MQTT_BROKER) require('./mqtt-bridge')(store);
else console.log('[mqtt] MQTT_BROKER not set — skipping MQTT bridge (HTTP /api/ingest still works).');

notify.startFlusher();
cloud.start();

app.listen(PORT, () => {
  console.log(`\nCrabTrack Pi server listening on http://0.0.0.0:${PORT}`);
  console.log(`  Dashboard : http://<pi-ip>:${PORT}/`);
  console.log(`  Nodes page: http://<pi-ip>:${PORT}/nodes.html`);
  console.log(`  DB file   : ${store.DB_PATH}`);
  console.log(`  Compartments: ${COMP_IDS[0]}–${COMP_IDS[COMP_IDS.length - 1]}\n`);
});
