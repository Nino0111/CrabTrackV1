// ══════════════════════════════════════════════════════════
// auth.js - admin account + login for the CrabTrack Pi server
// ══════════════════════════════════════════════════════════
// The admin account is created FROM THE ADMIN PAGE (first-run screen) - there is
// nothing to edit on the Pi. The password is stored only as a salted scrypt hash.
//
//   POST /api/admin/setup    {username,password}   first run only (409 afterwards)
//   POST /api/admin/login    {username,password}   -> { token }
//   POST /api/admin/password {oldPassword,newPassword}   (logged in)
//   GET  /api/admin/session  -> { configured, loggedIn }
//
// Protected routes need   Authorization: Bearer <token>
// The ESP32 boards do NOT log in; they only use the open "device" routes.

const crypto = require('crypto');
const store = require('./db');

const SESSION_HOURS = 12;
const MAX_FAILS = 5;
const LOCK_MS = 5 * 60 * 1000;

const sessions = new Map();          // token -> expiry (ms)
const fails = new Map();             // ip -> { n, until }

const sha = s => crypto.createHash('sha256').update(String(s)).digest();
const safeEq = (a, b) => crypto.timingSafeEqual(sha(a), sha(b));
const hashPw = (pw, salt) => crypto.scryptSync(String(pw), salt, 64);

const configured = () => !!store.getAdminAccount();
const NOT_SET_UP = 'No admin account yet. Open admin.html and create it on the first-run screen.';

function validNew(username, password) {
  if (!/^[a-z0-9._-]{3,32}$/.test(username || '')) return 'Username: 3-32 characters, letters/numbers . _ - only';
  if (typeof password !== 'string' || password.length < 8) return 'Password must be at least 8 characters';
  if (password.length > 200) return 'Password is too long';
  return null;
}

function verify(username, password) {
  const acc = store.getAdminAccount();
  if (!acc) return false;
  const userOk = safeEq(String(username || '').toLowerCase(), acc.username);
  const passOk = crypto.timingSafeEqual(hashPw(password || '', acc.salt), Buffer.from(acc.hash, 'hex'));
  return userOk && passOk;               // both are always evaluated
}

function saveAccount(username, password) {
  const salt = crypto.randomBytes(16).toString('hex');
  store.setAdminAccount(username, salt, hashPw(password, salt).toString('hex'));
}

function sweep() {
  const now = Date.now();
  for (const [t, exp] of sessions) if (exp < now) sessions.delete(t);
}
function tokenFrom(req) {
  const h = req.headers.authorization || '';
  return h.startsWith('Bearer ') ? h.slice(7).trim() : '';
}
function isValid(token) {
  if (!token) return false;
  sweep();
  const exp = sessions.get(token);
  return !!exp && exp > Date.now();
}
function newSession() {
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, Date.now() + SESSION_HOURS * 3600 * 1000);
  return token;
}

function requireAdmin(req, res, next) {
  if (!configured()) return res.status(503).json({ ok: false, error: NOT_SET_UP });
  if (!isValid(tokenFrom(req))) return res.status(401).json({ ok: false, error: 'Admin login required' });
  next();
}

// First run: create the account. Refused forever once one exists.
function setup(req, res) {
  if (configured()) return res.status(409).json({ ok: false, error: 'An admin account already exists' });
  const username = String((req.body || {}).username || '').toLowerCase();
  const password = (req.body || {}).password;
  const bad = validNew(username, password);
  if (bad) return res.status(400).json({ ok: false, error: bad });
  saveAccount(username, password);
  res.json({ ok: true, token: newSession() });
}

function login(req, res) {
  if (!configured()) return res.status(503).json({ ok: false, error: NOT_SET_UP });
  const ip = req.ip || 'unknown';
  const f = fails.get(ip);
  if (f && f.until > Date.now()) {
    const mins = Math.ceil((f.until - Date.now()) / 60000);
    return res.status(429).json({ ok: false, error: `Too many wrong attempts. Try again in ${mins} min.` });
  }
  const { username, password } = req.body || {};
  if (!verify(username, password)) {
    const lockExpired = f && f.until > 0 && f.until <= Date.now();
    const n = (f && !lockExpired ? f.n : 0) + 1;
    fails.set(ip, n >= MAX_FAILS ? { n: 0, until: Date.now() + LOCK_MS } : { n, until: 0 });
    return res.status(401).json({ ok: false, error: 'Wrong username or password' });
  }
  fails.delete(ip);
  res.json({ ok: true, token: newSession(), expiresInHours: SESSION_HOURS });
}

function changePassword(req, res) {
  const { oldPassword, newPassword } = req.body || {};
  const acc = store.getAdminAccount();
  if (!verify(acc.username, oldPassword)) return res.status(403).json({ ok: false, error: 'Current password is wrong' });
  const bad = validNew(acc.username, newPassword);
  if (bad) return res.status(400).json({ ok: false, error: bad });
  saveAccount(acc.username, newPassword);
  const keep = tokenFrom(req);
  for (const t of sessions.keys()) if (t !== keep) sessions.delete(t);   // sign out every other session
  res.json({ ok: true });
}

function logout(req, res) { sessions.delete(tokenFrom(req)); res.json({ ok: true }); }
function session(req, res) { res.json({ ok: true, configured: configured(), loggedIn: isValid(tokenFrom(req)) }); }

module.exports = { requireAdmin, setup, login, logout, session, changePassword, configured };
