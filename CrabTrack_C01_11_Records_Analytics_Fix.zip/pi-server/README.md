> **v2 note:** nodes are now dynamic, feeding schedules and phone messages
> were added, and all configuration moved to `.env`. Start with
> [`../SETUP.md`](../SETUP.md) and [`../docs/ADD_A_NODE.md`](../docs/ADD_A_NODE.md).

# CrabTrack Pi Server

The database + API layer that was missing from the original package. This is
what the dashboard's `GET /api/data` calls actually talk to. It runs on the
Raspberry Pi itself, stores everything in a local SQLite file, and needs no
internet connection — the dashboard, the Pi, and the ESP32 nodes only need to
share the same local Wi-Fi network.

```
ESP32 Nodes → Wi-Fi/MQTT (or HTTP) → THIS SERVER → SQLite (crabtrack.db) → HTTP API → Website
```

## 1. Install (on the Raspberry Pi)

```bash
cd pi-server
npm install
```

`better-sqlite3` compiles a small native module, so make sure `build-essential`
and `python3` are installed first if `npm install` fails:

```bash
sudo apt update && sudo apt install -y build-essential python3
```

## 2. Run it

```bash
npm start
# CrabTrack Pi server listening on http://0.0.0.0:3000
```

Find the Pi's local IP with `hostname -I`, then in the dashboard open
**⚙ Config** and set **Raspberry Pi API URL** to `http://<that-ip>:3000`.

To keep it running after reboot, use a systemd service:

```ini
# /etc/systemd/system/crabtrack.service
[Unit]
Description=CrabTrack Pi server
After=network.target

[Service]
WorkingDirectory=/home/pi/CrabTrack_Website/pi-server
ExecStart=/usr/bin/node server.js
Restart=on-failure
User=pi

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable --now crabtrack
```

## 3. Feeding ESP32 data in

Two options, pick whichever matches your node firmware — both write to the
same SQLite database:

- **HTTP (simplest):** `POST /api/ingest` with JSON body
  `{ "ph": 7.8, "salinity": 18.2, "temperature": 27.1, "node1_ok": true, "node2_ok": true, "node3_ok": true, "weights": [120.5, 118.0, ...] }`
- **MQTT:** set `MQTT_BROKER=mqtt://localhost` (and run a broker like
  Mosquitto on the Pi) before starting the server; it will subscribe to
  `crabtrack/node1|2|3` and merge the three node payloads automatically. See
  `mqtt-bridge.js` for topic/env var names.

## 4. Endpoints

| Method | Path                  | Purpose                                             |
|--------|-----------------------|------------------------------------------------------|
| GET    | `/api/status`         | Health check + DB stats                              |
| GET    | `/api/data`           | Latest sensor + weight snapshot (dashboard polls this)|
| GET    | `/api/history?hours=` | Sensor history for charts                             |
| POST   | `/api/ingest`         | ESP32 nodes push a raw reading                        |
| POST   | `/api/feed`           | Log a feeding (used by the dashboard's offline sync)  |
| POST   | `/api/weight`         | Log a manual weight entry                             |
| POST   | `/api/obs`            | Log an observation note                               |
| GET    | `/api/feed-history`   | Feed log, optional `?compId=C01&limit=50`             |
| GET    | `/api/feeding-alerts` | Compartments overdue for feeding right now            |
| GET    | `/api/alerts`         | Alert history recorded by the background check        |

A background job runs every 30 minutes and writes feeding-overdue alerts
into the `alerts` table even if no browser is open — see the `console.log`
in `server.js` for the exact example text it produces, e.g.:

```
⏰ Feeding Reminder — C04 hasn't been fed in 26h. Next feeding is due soon.
🚨 Feeding Alert — C07 hasn't been fed in 51h. Feed now to prevent weight loss or stress.
```

## 5. Serving the dashboard from the Pi (optional)

The server also serves static files, so if you keep the folder layout as
shipped (`pi-server/` next to `crabtrack/`), visiting `http://<pi-ip>:3000/`
in a browser opens the dashboard directly from the Pi — no separate web host
needed. Override the folder with `CRABTRACK_WEB_DIR=/path/to/crabtrack`.

## Notes

- This server is designed for a trusted local network (home/farm Wi-Fi). If
  you expose it beyond that, put it behind a reverse proxy with auth/TLS —
  it does not implement authentication itself.
- `FEED_WARN_HOURS` (default 24) and `FEED_ALERT_HOURS` (default 48) env
  vars control when a compartment is considered overdue for feeding.
