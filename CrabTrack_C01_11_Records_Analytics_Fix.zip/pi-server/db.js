// ══════════════════════════════════════════════════════════
// db.js — SQLite database for CrabTrack (Raspberry Pi side)
// ══════════════════════════════════════════════════════════
// One local file: crabtrack.db. No internet required.
//
// v2 changes:
//  • Nodes are now DYNAMIC (a `nodes` table + `node_readings`).
//    You are no longer limited to node1/node2/node3 — a new ESP32
//    auto-registers itself the first time it posts data.
//  • Feeding SCHEDULES (feed at 07:00 and 17:00) alongside the old
//    "hours since last fed" rule.
//  • Outbox for messages/notifications + cloud sync cursor.
//  • Old node1_ok/node2_ok/node3_ok fields are still emitted by
//    /api/data so the existing dashboard keeps working unchanged.

const path = require('path');
const Database = require('better-sqlite3');

const DB_PATH = process.env.CRABTRACK_DB || path.join(__dirname, 'crabtrack.db');
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');

db.exec(`
CREATE TABLE IF NOT EXISTS readings (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  ts            TEXT NOT NULL,
  ph            REAL,
  salinity      REAL,
  temperature   REAL,
  node1_ok      INTEGER DEFAULT 0,
  node2_ok      INTEGER DEFAULT 0,
  node3_ok      INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS weights (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  ts            TEXT NOT NULL,
  comp_index    INTEGER NOT NULL,
  weight        REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS feed_log (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  ts            TEXT NOT NULL,
  comp_id       TEXT NOT NULL,
  type          TEXT,
  amount        REAL,
  note          TEXT,
  source        TEXT DEFAULT 'dashboard'
);

CREATE TABLE IF NOT EXISTS weight_log (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  ts            TEXT NOT NULL,
  comp_id       TEXT NOT NULL,
  weight        REAL NOT NULL,
  note          TEXT,
  source        TEXT DEFAULT 'dashboard'
);

CREATE TABLE IF NOT EXISTS obs_log (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  ts            TEXT NOT NULL,
  comp_id       TEXT NOT NULL,
  type          TEXT,
  note          TEXT
);

CREATE TABLE IF NOT EXISTS alerts (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  ts            TEXT NOT NULL,
  sensor        TEXT,
  val           TEXT,
  threshold     TEXT,
  level         TEXT,
  msg           TEXT,
  sent          INTEGER DEFAULT 0
);

-- ── NEW: the node registry. Add a node by inserting one row. ──
CREATE TABLE IF NOT EXISTS nodes (
  node_id       TEXT PRIMARY KEY,         -- e.g. "node1", "node4", "ph-tank-b"
  label         TEXT,                     -- human name shown in the UI
  location      TEXT,                     -- "Tank B", "Nursery pond"
  capabilities  TEXT DEFAULT '[]',        -- JSON array: ["ph"] / ["temperature","salinity"] / ["weights"]
  enabled       INTEGER DEFAULT 1,
  offline_after INTEGER DEFAULT 120,      -- seconds of silence before we call it OFFLINE
  created_ts    TEXT,
  last_seen     TEXT,
  last_payload  TEXT                      -- JSON of the most recent raw message
);

-- Every message from every node, kept per-node so nothing is merged away
CREATE TABLE IF NOT EXISTS node_readings (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  ts            TEXT NOT NULL,
  node_id       TEXT NOT NULL,
  payload       TEXT NOT NULL
);

-- ── NEW: feeding schedule. "Feed C01-C10 at 07:00 and 17:00 daily." ──
CREATE TABLE IF NOT EXISTS feed_schedule (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  label         TEXT,
  time_of_day   TEXT NOT NULL,            -- "07:00" local Pi time
  days          TEXT DEFAULT 'daily',     -- 'daily' or CSV of 0-6 (0=Sun)
  comp_ids      TEXT DEFAULT 'all',       -- 'all' or CSV "C01,C02"
  grace_minutes INTEGER DEFAULT 60,       -- how long before it escalates to urgent
  enabled       INTEGER DEFAULT 1,
  created_ts    TEXT
);

-- ── NEW: solenoid time schedules. "Open channels 1,2 at 06:00 for 5 min." ──
CREATE TABLE IF NOT EXISTS actuator_schedule (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  label             TEXT,
  time_of_day       TEXT NOT NULL,        -- "06:00" local Pi time
  days              TEXT DEFAULT 'daily', -- 'daily' or CSV of 0-6 (0=Sun)
  channels          TEXT NOT NULL,        -- CSV of solenoid numbers, e.g. "1,2"
  duration_minutes  REAL DEFAULT 5,       -- how long to stay open once the time hits
  enabled           INTEGER DEFAULT 1,
  created_ts        TEXT
);

-- ── NEW: sensor-triggered solenoid rules. "If salinity < 25, open channel 3." ──
CREATE TABLE IF NOT EXISTS actuator_rule (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  label             TEXT,
  channel           INTEGER NOT NULL,     -- which solenoid, 1-4
  source            TEXT DEFAULT 'salinity', -- 'salinity' | 'ph' | 'temperature'
  condition         TEXT NOT NULL,        -- 'below' | 'above'
  threshold         REAL NOT NULL,
  duration_minutes  REAL DEFAULT 2,       -- safety cap: max time open per trigger
  cooldown_minutes  REAL DEFAULT 10,      -- min gap before it can re-trigger
  enabled           INTEGER DEFAULT 1,
  created_ts        TEXT
);

-- Every on/off transition, for the dashboard and for the rule engine's
-- own cooldown/duration bookkeeping.
CREATE TABLE IF NOT EXISTS actuator_log (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  ts            TEXT NOT NULL,
  channel       INTEGER NOT NULL,
  action        TEXT NOT NULL,            -- 'on' | 'off'
  reason        TEXT                      -- 'schedule:3' | 'rule:5' | 'manual'
);

-- ── NEW: pump + drain-solenoid auto weigh-cycle schedule ──
-- "At 06:00, turn the pump off, open the drain valve (channel 4) for
--  3 minutes, close it, wait 20s, take the weight, turn the pump back on."
CREATE TABLE IF NOT EXISTS drain_cycle_schedule (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  label               TEXT,
  time_of_day         TEXT NOT NULL,            -- "06:00" local Pi time, cycle start
  days                TEXT DEFAULT 'daily',     -- 'daily' or CSV of 0-6 (0=Sun)
  drain_channel       INTEGER NOT NULL DEFAULT 4,  -- which solenoid (1-4) is the drain valve
  pump_lead_seconds   REAL DEFAULT 5,           -- gap between "pump off" and "drain valve opens"
  drain_minutes       REAL DEFAULT 3,           -- how long the drain valve stays open
  settle_seconds      REAL DEFAULT 20,          -- wait after closing the valve before reading the scale
  comp_id             TEXT DEFAULT 'C04',       -- which compartment's weight this cycle logs
  enabled             INTEGER DEFAULT 1,
  created_ts          TEXT
);

-- One-off "run this cycle right now" triggers, e.g. from an admin.html button.
CREATE TABLE IF NOT EXISTS drain_manual_run (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  requested_ts        TEXT NOT NULL,
  drain_channel       INTEGER NOT NULL,
  pump_lead_seconds   REAL DEFAULT 5,
  drain_minutes       REAL DEFAULT 3,
  settle_seconds      REAL DEFAULT 20,
  comp_id             TEXT DEFAULT 'C04',
  status              TEXT DEFAULT 'pending'    -- 'pending' | 'done'
);

-- Step-by-step log of each cycle run: pump_off -> drain_on -> drain_off
-- -> weight_taken -> pump_on. One row per step, per run, per day.
CREATE TABLE IF NOT EXISTS drain_cycle_log (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  ts            TEXT NOT NULL,
  run_type      TEXT NOT NULL,       -- 'schedule' | 'manual'
  run_id        INTEGER NOT NULL,
  cycle_date    TEXT NOT NULL,       -- "YYYY-MM-DD" Pi-local, so a daily schedule runs once/day
  step          TEXT NOT NULL,       -- 'pump_off' | 'drain_on' | 'drain_off' | 'weight_taken' | 'pump_on'
  detail        TEXT
);

-- Pump on/off transitions, same idea as actuator_log but for the pump relay.
CREATE TABLE IF NOT EXISTS pump_log (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  ts            TEXT NOT NULL,
  action        TEXT NOT NULL,       -- 'on' | 'off'
  reason        TEXT                 -- 'drain-cycle' | 'manual-on' | 'manual-off' | 'auto'
);

-- Single-row table: manual pump override from the dashboard/admin page.
CREATE TABLE IF NOT EXISTS pump_override (
  id            INTEGER PRIMARY KEY CHECK (id = 1),
  mode          TEXT NOT NULL DEFAULT 'auto',   -- 'auto' | 'forced_on' | 'forced_off'
  set_ts        TEXT
);

-- ── NEW: outbox for the Message button / phone notifications ──
CREATE TABLE IF NOT EXISTS outbox (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  ts            TEXT NOT NULL,
  channel       TEXT,                     -- 'telegram' | 'log' | 'webhook'
  target        TEXT,
  body          TEXT NOT NULL,
  status        TEXT DEFAULT 'pending',   -- pending | sent | failed
  attempts      INTEGER DEFAULT 0,
  error         TEXT,
  sent_ts       TEXT
);

CREATE INDEX IF NOT EXISTS idx_readings_ts   ON readings(ts);
CREATE INDEX IF NOT EXISTS idx_weights_ts    ON weights(ts);
CREATE INDEX IF NOT EXISTS idx_feed_comp     ON feed_log(comp_id, ts);
CREATE INDEX IF NOT EXISTS idx_noderead      ON node_readings(node_id, ts);
CREATE INDEX IF NOT EXISTS idx_outbox_status ON outbox(status);
CREATE INDEX IF NOT EXISTS idx_actlog_channel ON actuator_log(channel, ts);
CREATE INDEX IF NOT EXISTS idx_draincyclelog  ON drain_cycle_log(run_type, run_id, cycle_date);
CREATE INDEX IF NOT EXISTS idx_pumplog_ts     ON pump_log(ts);

INSERT OR IGNORE INTO pump_override (id, mode, set_ts) VALUES (1, 'auto', NULL);
`);

// Older databases won't have the `sent` column on alerts — add it if missing.
try { db.exec(`ALTER TABLE alerts ADD COLUMN sent INTEGER DEFAULT 0`); } catch (_) { /* already there */ }

// ── v3 additions (safe on old databases: each ALTER is skipped if the column exists) ──
// Time schedule can also hold the pump OFF for N minutes ("6am: valves 1+2 open, pump off 5 min").
try { db.exec(`ALTER TABLE actuator_schedule ADD COLUMN pump_off_minutes REAL DEFAULT 0`); } catch (_) {}
// Sensor rule can have a separate STOP level ("open below 25, close once it reaches 30").
try { db.exec(`ALTER TABLE actuator_rule ADD COLUMN stop_threshold REAL`); } catch (_) {}
// Drain/weigh cycles can open more than one drain valve at once (e.g. channels 1+2).
try { db.exec(`ALTER TABLE drain_cycle_schedule ADD COLUMN drain_channels TEXT`); } catch (_) {}
try { db.exec(`ALTER TABLE drain_manual_run ADD COLUMN drain_channels TEXT`); } catch (_) {}

db.exec(`
-- The ONE admin account, created from the admin page (password stored only as a salted scrypt hash).
CREATE TABLE IF NOT EXISTS admin_account (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  username TEXT NOT NULL,
  salt TEXT NOT NULL,
  hash TEXT NOT NULL,
  updated_ts TEXT
);
`);

db.exec(`
-- Tare / calibrate requests made from the website. The weight node polls for these.
CREATE TABLE IF NOT EXISTS scale_command (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  ts            TEXT NOT NULL,
  comp_id       TEXT NOT NULL,           -- "C04"
  action        TEXT NOT NULL,           -- 'tare' | 'calibrate'
  known_weight  REAL,                    -- grams, calibrate only
  status        TEXT DEFAULT 'pending',  -- pending | done | failed | expired
  message       TEXT,
  cal_factor    REAL,
  done_ts       TEXT
);
-- Last known tare/calibration per compartment (for display on the admin page).
CREATE TABLE IF NOT EXISTS scale_state (
  comp_id       TEXT PRIMARY KEY,
  cal_factor    REAL,
  last_tare_ts  TEXT,
  last_cal_ts   TEXT
);
CREATE INDEX IF NOT EXISTS idx_scalecmd_status ON scale_command(status, comp_id);
`);

const nowISO = () => new Date().toISOString();
const jparse = (s, fallback) => { try { return JSON.parse(s); } catch (_) { return fallback; } };

// ══════════════════════════════════════════════════════════
// NODES
// ══════════════════════════════════════════════════════════

// Seed the three original nodes so nothing looks empty on first run.
function seedDefaultNodes() {
  const count = db.prepare(`SELECT COUNT(*) AS n FROM nodes`).get().n;
  if (count > 0) return;
  [
    { node_id: 'node1', label: 'pH Node',      capabilities: ['ph'] },
    { node_id: 'node2', label: 'EC/Temp Node', capabilities: ['salinity', 'temperature'] },
    { node_id: 'node3', label: 'Weight Node',  capabilities: ['weights'] },
  ].forEach(n => upsertNode(n));
}

// This is the whole "adding a node" operation. Call it from the API,
// or let ingestReading() call it automatically when an unknown node_id
// shows up. Either way: one row = one node.
function upsertNode({ node_id, label, location, capabilities, enabled, offline_after }) {
  if (!node_id) throw new Error('node_id required');
  const existing = db.prepare(`SELECT * FROM nodes WHERE node_id = ?`).get(node_id);
  if (existing) {
    db.prepare(`UPDATE nodes SET
        label = COALESCE(?, label),
        location = COALESCE(?, location),
        capabilities = COALESCE(?, capabilities),
        enabled = COALESCE(?, enabled),
        offline_after = COALESCE(?, offline_after)
      WHERE node_id = ?`)
      .run(
        label ?? null,
        location ?? null,
        capabilities ? JSON.stringify(capabilities) : null,
        enabled === undefined ? null : (enabled ? 1 : 0),
        offline_after ?? null,
        node_id
      );
  } else {
    db.prepare(`INSERT INTO nodes (node_id, label, location, capabilities, enabled, offline_after, created_ts)
                VALUES (?,?,?,?,?,?,?)`)
      .run(
        node_id,
        label || node_id,
        location || '',
        JSON.stringify(capabilities || []),
        enabled === false ? 0 : 1,
        offline_after || 120,
        nowISO()
      );
  }
  return getNode(node_id);
}

function getNode(node_id) {
  const r = db.prepare(`SELECT * FROM nodes WHERE node_id = ?`).get(node_id);
  return r ? shapeNode(r) : null;
}

function shapeNode(r) {
  const offlineAfter = r.offline_after || 120;
  const ageSec = r.last_seen ? (Date.now() - new Date(r.last_seen).getTime()) / 1000 : null;
  return {
    nodeId: r.node_id,
    label: r.label || r.node_id,
    location: r.location || '',
    capabilities: jparse(r.capabilities, []),
    enabled: !!r.enabled,
    offlineAfter,
    lastSeen: r.last_seen,
    secondsSinceSeen: ageSec === null ? null : Math.round(ageSec),
    online: ageSec !== null && ageSec <= offlineAfter,
    lastPayload: jparse(r.last_payload, null),
  };
}

function listNodes() {
  return db.prepare(`SELECT * FROM nodes ORDER BY node_id ASC`).all().map(shapeNode);
}

function deleteNode(node_id) {
  db.prepare(`DELETE FROM nodes WHERE node_id = ?`).run(node_id);
  db.prepare(`DELETE FROM node_readings WHERE node_id = ?`).run(node_id);
}

function touchNode(node_id, payload) {
  db.prepare(`UPDATE nodes SET last_seen = ?, last_payload = ? WHERE node_id = ?`)
    .run(nowISO(), JSON.stringify(payload || {}), node_id);
}

// ══════════════════════════════════════════════════════════
// INGEST
// ══════════════════════════════════════════════════════════
// Accepts either shape:
//   A) { node_id: "node4", ph: 7.8 }                  ← per-node (preferred, new)
//   B) { ph, salinity, temperature, weights: [...] }  ← merged (old, still fine)
function ingestReading(data) {
  const ts = nowISO();
  const nodeId = data.node_id || data.nodeId || data.node || null;

  // Auto-register unknown nodes. This is why adding a 4th node needs
  // no code change: it just starts posting and it appears in the UI.
  if (nodeId) {
    if (!getNode(nodeId)) {
      const caps = [];
      if (data.ph != null || data.pH != null) caps.push('ph');
      if (data.salinity != null || data.ec != null || data.EC != null) caps.push('salinity');
      if (data.temperature != null || data.Temp != null) caps.push('temperature');
      if (Array.isArray(data.weights)) caps.push('weights');
      if (data.channels != null) caps.push('actuator');
      if (data.pump != null) caps.push('pump');
      upsertNode({ node_id: nodeId, label: data.label || nodeId, location: data.location || '', capabilities: caps });
      console.log(`[nodes] auto-registered new node "${nodeId}" (${caps.join(', ') || 'no sensors detected'})`);
    }
    db.prepare(`INSERT INTO node_readings (ts, node_id, payload) VALUES (?,?,?)`)
      .run(ts, nodeId, JSON.stringify(data));
    touchNode(nodeId, data);
  }

  const num = (...vals) => { for (const v of vals) if (typeof v === 'number' && !Number.isNaN(v)) return v; return null; };
  const ph          = num(data.ph, data.pH);
  const salinity    = num(data.salinity, data.ec, data.EC);
  const temperature = num(data.temperature, data.Temp, data.temp);

  // Only write a row into the merged `readings` table if there's something to write.
  if (ph !== null || salinity !== null || temperature !== null || !nodeId) {
    const prev = db.prepare(`SELECT * FROM readings ORDER BY id DESC LIMIT 1`).get() || {};
    db.prepare(`INSERT INTO readings (ts, ph, salinity, temperature, node1_ok, node2_ok, node3_ok)
                VALUES (?,?,?,?,?,?,?)`)
      .run(
        ts,
        ph ?? prev.ph ?? null,
        salinity ?? prev.salinity ?? null,
        temperature ?? prev.temperature ?? null,
        data.node1_ok ? 1 : 0, data.node2_ok ? 1 : 0, data.node3_ok ? 1 : 0
      );
  }

  // Weight nodes also report their current calibration factor(s), so the admin page can show them.
  if (Array.isArray(data.cal_factors)) {
    const off = Number.isInteger(data.weight_offset) ? data.weight_offset : 0;
    data.cal_factors.forEach((f, i) => {
      if (typeof f === 'number' && Number.isFinite(f)) {
        const cid = 'C' + String(off + i + 1).padStart(2, '0');
        db.prepare(`INSERT INTO scale_state (comp_id, cal_factor) VALUES (?,?)
                    ON CONFLICT(comp_id) DO UPDATE SET cal_factor=excluded.cal_factor`).run(cid, f);
      }
    });
  }

  if (Array.isArray(data.weights)) {
    const stmt = db.prepare(`INSERT INTO weights (ts, comp_index, weight) VALUES (?,?,?)`);
    const offset = Number.isInteger(data.weight_offset) ? data.weight_offset : 0;
    data.weights.forEach((w, i) => {
      if (typeof w === 'number' && !Number.isNaN(w)) stmt.run(ts, offset + i, w);
    });
  }

  // Existing CrabTrack load-cell firmware publishes one MQTT topic per
  // compartment (crabtrack/weight1 ... weight10) with a scalar `weight`.
  const weightMatch = String(nodeId || '').match(/^weight(10|[1-9])$/);
  const scalarWeight = num(data.weight, data.weight_g, data.grams);
  if (weightMatch && scalarWeight !== null) {
    const compId = 'C' + String(parseInt(weightMatch[1], 10)).padStart(2, '0');
    logWeight({ compId, weight: scalarWeight, note: data.note || 'MQTT weight node', source: 'mqtt' });
  }
  return ts;
}

// ══════════════════════════════════════════════════════════
// READ
// ══════════════════════════════════════════════════════════
function getLatestData() {
  const reading = db.prepare(`SELECT * FROM readings ORDER BY id DESC LIMIT 1`).get();
  const nodes = listNodes();

  // Back-compat: the current dashboard reads node1_ok/node2_ok/node3_ok.
  // Derive them from live node status so nothing breaks.
  const okFor = id => { const n = nodes.find(x => x.nodeId === id); return n ? n.online : false; };

  const rows = db.prepare(`
    SELECT comp_index, weight FROM weights w
    WHERE id IN (SELECT MAX(id) FROM weights GROUP BY comp_index)
    ORDER BY comp_index ASC
  `).all();
  const weights = [];
  rows.forEach(r => { weights[r.comp_index] = r.weight; });

  return {
    ph: reading?.ph ?? 0,
    salinity: reading?.salinity ?? 0,
    temperature: reading?.temperature ?? 0,
    node1_ok: okFor('node1') || !!reading?.node1_ok,
    node2_ok: okFor('node2') || !!reading?.node2_ok,
    node3_ok: okFor('node3') || !!reading?.node3_ok,
    weights,
    nodes,                       // ← new: full dynamic list, any number of nodes
    timestamp: reading?.ts ?? null,
  };
}

function getHistory(hours = 24) {
  const cutoff = new Date(Date.now() - hours * 3600 * 1000).toISOString();
  return db.prepare(`SELECT ts, ph, salinity, temperature FROM readings WHERE ts >= ? ORDER BY ts ASC`).all(cutoff);
}

function getNodeHistory(nodeId, hours = 24, limit = 500) {
  const cutoff = new Date(Date.now() - hours * 3600 * 1000).toISOString();
  return db.prepare(`SELECT ts, payload FROM node_readings WHERE node_id = ? AND ts >= ? ORDER BY ts DESC LIMIT ?`)
    .all(nodeId, cutoff, limit)
    .map(r => ({ ts: r.ts, ...jparse(r.payload, {}) }));
}

function getStatus() {
  const last = db.prepare(`SELECT ts FROM readings ORDER BY id DESC LIMIT 1`).get();
  const count = db.prepare(`SELECT COUNT(*) AS n FROM readings`).get().n;
  const nodes = listNodes();
  return {
    status: 'ok',
    db: 'connected',
    db_path: DB_PATH,
    readings_stored: count,
    last_reading_ts: last ? last.ts : null,
    nodes_registered: nodes.length,
    nodes_online: nodes.filter(n => n.online).length,
    pending_outbox: db.prepare(`SELECT COUNT(*) AS n FROM outbox WHERE status='pending'`).get().n,
    server_time: nowISO(),
  };
}

// ══════════════════════════════════════════════════════════
// LOGGING (offline sync targets)
// ══════════════════════════════════════════════════════════
function logFeed({ compId, type, amount, note, date, source }) {
  const ts = date || nowISO();
  db.prepare(`INSERT INTO feed_log (ts, comp_id, type, amount, note, source) VALUES (?,?,?,?,?,?)`)
    .run(ts, compId, type || '', amount || 0, note || '', source || 'dashboard');
}

function logWeight({ compId, weight, note, date, source }) {
  const ts = date || nowISO();
  db.prepare(`INSERT INTO weight_log (ts, comp_id, weight, note, source) VALUES (?,?,?,?,?)`)
    .run(ts, compId, weight, note || '', source || 'dashboard');
}

function logObs({ compId, type, note, date }) {
  const ts = date || nowISO();
  db.prepare(`INSERT INTO obs_log (ts, comp_id, type, note) VALUES (?,?,?,?)`).run(ts, compId, type || '', note || '');
}

function getFeedHistory(compId, limit = 50) {
  if (compId) return db.prepare(`SELECT * FROM feed_log WHERE comp_id = ? ORDER BY ts DESC LIMIT ?`).all(compId, limit);
  return db.prepare(`SELECT * FROM feed_log ORDER BY ts DESC LIMIT ?`).all(limit);
}

// ══════════════════════════════════════════════════════════
// FEEDING SCHEDULE
// ══════════════════════════════════════════════════════════
function listSchedules() {
  return db.prepare(`SELECT * FROM feed_schedule ORDER BY time_of_day ASC`).all().map(r => ({
    id: r.id,
    label: r.label || '',
    time: r.time_of_day,
    days: r.days,
    compIds: r.comp_ids,
    graceMinutes: r.grace_minutes,
    enabled: !!r.enabled,
  }));
}

function addSchedule({ label, time, days, compIds, graceMinutes }) {
  if (!/^\d{2}:\d{2}$/.test(time || '')) throw new Error('time must be "HH:MM"');
  const info = db.prepare(`INSERT INTO feed_schedule (label, time_of_day, days, comp_ids, grace_minutes, enabled, created_ts)
                           VALUES (?,?,?,?,?,1,?)`)
    .run(label || '', time, days || 'daily', compIds || 'all', graceMinutes ?? 60, nowISO());
  return info.lastInsertRowid;
}

function updateSchedule(id, fields) {
  const cur = db.prepare(`SELECT * FROM feed_schedule WHERE id = ?`).get(id);
  if (!cur) throw new Error('schedule not found');
  db.prepare(`UPDATE feed_schedule SET label=?, time_of_day=?, days=?, comp_ids=?, grace_minutes=?, enabled=? WHERE id=?`)
    .run(
      fields.label ?? cur.label,
      fields.time ?? cur.time_of_day,
      fields.days ?? cur.days,
      fields.compIds ?? cur.comp_ids,
      fields.graceMinutes ?? cur.grace_minutes,
      fields.enabled === undefined ? cur.enabled : (fields.enabled ? 1 : 0),
      id
    );
}

function deleteSchedule(id) {
  db.prepare(`DELETE FROM feed_schedule WHERE id = ?`).run(id);
}

function lastFedAt(compId) {
  const r = db.prepare(`SELECT ts FROM feed_log WHERE comp_id = ? ORDER BY ts DESC LIMIT 1`).get(compId);
  return r ? new Date(r.ts) : null;
}

// Schedule-based: "it is now past 07:00 and C03 still hasn't been fed today."
function checkScheduledFeedings({ allCompIds = [], now = new Date() } = {}) {
  const out = [];
  const schedules = listSchedules().filter(s => s.enabled);
  const dow = now.getDay();

  schedules.forEach(s => {
    if (s.days !== 'daily') {
      const allowed = s.days.split(',').map(x => parseInt(x.trim(), 10));
      if (!allowed.includes(dow)) return;
    }
    const [hh, mm] = s.time.split(':').map(Number);
    const due = new Date(now); due.setHours(hh, mm, 0, 0);
    if (now < due) return;                                  // not time yet

    const minutesLate = (now - due) / 60000;
    const comps = s.compIds === 'all' ? allCompIds : s.compIds.split(',').map(x => x.trim()).filter(Boolean);

    comps.forEach(compId => {
      const fed = lastFedAt(compId);
      if (fed && fed >= due) return;                        // already fed for this slot ✓
      const level = minutesLate >= s.graceMinutes ? 'alert' : 'warn';
      const label = s.label ? ` (${s.label})` : '';
      out.push({
        compId,
        scheduleId: s.id,
        dueAt: due.toISOString(),
        minutesLate: Math.round(minutesLate),
        level,
        msg: level === 'alert'
          ? `🚨 Feeding overdue — ${compId} was due at ${s.time}${label}, ${Math.round(minutesLate)} min ago. Feed now.`
          : `🍤 Time to feed — ${compId} is due at ${s.time}${label}. Tap FED when done.`,
      });
    });
  });
  return out;
}

// Interval-based: the original "hasn't been fed in N hours" rule. Still useful
// as a safety net if no schedule is configured.
function checkFeedingAlerts({ compIds = [], warnHours = 24, alertHours = 48 } = {}) {
  const now = Date.now();
  const results = [];
  compIds.forEach(compId => {
    const last = db.prepare(`SELECT ts FROM feed_log WHERE comp_id = ? ORDER BY ts DESC LIMIT 1`).get(compId);
    if (!last) {
      results.push({ compId, hoursSinceFed: null, level: 'warn',
        msg: `🍤 Feeding Reminder — ${compId} has no feeding record yet. Log a feeding to start tracking.` });
      return;
    }
    const hours = (now - new Date(last.ts).getTime()) / 3600000;
    if (hours >= alertHours) {
      results.push({ compId, hoursSinceFed: Math.round(hours), level: 'alert',
        msg: `🚨 Feeding Alert — ${compId} hasn't been fed in ${Math.round(hours)}h. Feed now to prevent weight loss or stress.` });
    } else if (hours >= warnHours) {
      results.push({ compId, hoursSinceFed: Math.round(hours), level: 'warn',
        msg: `⏰ Feeding Reminder — ${compId} hasn't been fed in ${Math.round(hours)}h. Next feeding is due soon.` });
    }
  });
  return results;
}

// ══════════════════════════════════════════════════════════
// ALERTS + OUTBOX
// ══════════════════════════════════════════════════════════
function recordAlert({ sensor, val, threshold, level, msg }) {
  const info = db.prepare(`INSERT INTO alerts (ts, sensor, val, threshold, level, msg) VALUES (?,?,?,?,?,?)`)
    .run(nowISO(), sensor, String(val ?? ''), String(threshold ?? ''), level, msg || '');
  return info.lastInsertRowid;
}

function getAlerts(limit = 50) {
  return db.prepare(`SELECT * FROM alerts ORDER BY id DESC LIMIT ?`).all(limit);
}

// Don't spam: returns true if the same alert text was already recorded recently.
function alertSentRecently(msg, withinMinutes = 55) {
  const cutoff = new Date(Date.now() - withinMinutes * 60000).toISOString();
  const r = db.prepare(`SELECT id FROM alerts WHERE msg = ? AND ts >= ? LIMIT 1`).get(msg, cutoff);
  return !!r;
}

function queueMessage({ channel, target, body }) {
  const info = db.prepare(`INSERT INTO outbox (ts, channel, target, body) VALUES (?,?,?,?)`)
    .run(nowISO(), channel || 'telegram', target || '', body);
  return info.lastInsertRowid;
}

function pendingMessages(limit = 25) {
  return db.prepare(`SELECT * FROM outbox WHERE status = 'pending' AND attempts < 8 ORDER BY id ASC LIMIT ?`).all(limit);
}

function markMessage(id, status, error) {
  db.prepare(`UPDATE outbox SET status=?, attempts=attempts+1, error=?, sent_ts=? WHERE id=?`)
    .run(status, error || null, status === 'sent' ? nowISO() : null, id);
}

function getOutbox(limit = 50) {
  return db.prepare(`SELECT * FROM outbox ORDER BY id DESC LIMIT ?`).all(limit);
}

// ══════════════════════════════════════════════════════════
// ACTUATORS — solenoid time schedules + sensor-triggered rules
// ══════════════════════════════════════════════════════════
// Two ways a channel (1-4) can be told to open:
//   • a time schedule  (e.g. "channels 1,2 open at 06:00 for 5 min")
//   • a sensor rule    (e.g. "if salinity < 25, open channel 3 for up
//                             to 2 min, then wait 10 min before again")
// computeActuatorState() below combines both into one on/off map that
// the solenoid ESP32 polls, and that the dashboard can show live.

function listActuatorSchedules() {
  return db.prepare(`SELECT * FROM actuator_schedule ORDER BY time_of_day ASC`).all().map(r => ({
    id: r.id,
    label: r.label || '',
    time: r.time_of_day,
    days: r.days,
    channels: r.channels.split(',').map(Number),
    durationMinutes: r.duration_minutes,
    pumpOffMinutes: r.pump_off_minutes || 0,
    enabled: !!r.enabled,
  }));
}

function addActuatorSchedule({ label, time, days, channels, durationMinutes, pumpOffMinutes }) {
  if (!/^\d{2}:\d{2}$/.test(time || '')) throw new Error('time must be "HH:MM"');
  const chans = (Array.isArray(channels) ? channels : String(channels || '').split(','))
    .map(c => parseInt(c, 10)).filter(c => c >= 1 && c <= 4);
  if (!chans.length) throw new Error('channels required (1-4)');
  const info = db.prepare(`INSERT INTO actuator_schedule
      (label, time_of_day, days, channels, duration_minutes, pump_off_minutes, enabled, created_ts)
      VALUES (?,?,?,?,?,?,1,?)`)
    .run(label || '', time, days || 'daily', chans.join(','), durationMinutes ?? 5, pumpOffMinutes ?? 0, nowISO());
  return info.lastInsertRowid;
}

function updateActuatorSchedule(id, fields) {
  const cur = db.prepare(`SELECT * FROM actuator_schedule WHERE id = ?`).get(id);
  if (!cur) throw new Error('schedule not found');
  const chans = fields.channels
    ? (Array.isArray(fields.channels) ? fields.channels : String(fields.channels).split(','))
        .map(c => parseInt(c, 10)).filter(c => c >= 1 && c <= 4).join(',')
    : cur.channels;
  if (fields.time !== undefined && !/^\d{2}:\d{2}$/.test(fields.time)) throw new Error('time must be "HH:MM"');
  db.prepare(`UPDATE actuator_schedule SET label=?, time_of_day=?, days=?, channels=?, duration_minutes=?, pump_off_minutes=?, enabled=? WHERE id=?`)
    .run(
      fields.label ?? cur.label,
      fields.time ?? cur.time_of_day,
      fields.days ?? cur.days,
      chans,
      fields.durationMinutes ?? cur.duration_minutes,
      fields.pumpOffMinutes ?? cur.pump_off_minutes ?? 0,
      fields.enabled === undefined ? cur.enabled : (fields.enabled ? 1 : 0),
      id
    );
}

function deleteActuatorSchedule(id) {
  db.prepare(`DELETE FROM actuator_schedule WHERE id = ?`).run(id);
}

function listActuatorRules() {
  return db.prepare(`SELECT * FROM actuator_rule ORDER BY channel ASC`).all().map(r => ({
    id: r.id,
    label: r.label || '',
    channel: r.channel,
    source: r.source,
    condition: r.condition,
    threshold: r.threshold,
    durationMinutes: r.duration_minutes,
    cooldownMinutes: r.cooldown_minutes,
    stopThreshold: r.stop_threshold,
    enabled: !!r.enabled,
  }));
}

// Validates a stop level against the start level: for "below" the stop level
// must be at or above the start level (and the reverse for "above"), otherwise
// the valve would close the instant it opens.
function checkStop(condition, threshold, stop) {
  if (stop === null || stop === undefined || stop === '') return null;
  if (typeof stop !== 'number' || Number.isNaN(stop)) throw new Error('stopThreshold must be a number');
  if (condition === 'below' && stop < threshold) throw new Error('For a "below" rule the stop level must be >= the start level');
  if (condition === 'above' && stop > threshold) throw new Error('For an "above" rule the stop level must be <= the start level');
  return stop;
}

function addActuatorRule({ label, channel, source, condition, threshold, durationMinutes, cooldownMinutes, stopThreshold }) {
  const ch = parseInt(channel, 10);
  if (!(ch >= 1 && ch <= 4)) throw new Error('channel must be 1-4');
  if (!['below', 'above'].includes(condition)) throw new Error('condition must be "below" or "above"');
  if (typeof threshold !== 'number') throw new Error('threshold must be a number');
  const stop = checkStop(condition, threshold, stopThreshold);
  const info = db.prepare(`INSERT INTO actuator_rule
      (label, channel, source, condition, threshold, duration_minutes, cooldown_minutes, stop_threshold, enabled, created_ts)
      VALUES (?,?,?,?,?,?,?,?,1,?)`)
    .run(label || '', ch, source || 'salinity', condition, threshold, durationMinutes ?? 10, cooldownMinutes ?? 10, stop, nowISO());
  return info.lastInsertRowid;
}

function updateActuatorRule(id, fields) {
  const cur = db.prepare(`SELECT * FROM actuator_rule WHERE id = ?`).get(id);
  if (!cur) throw new Error('rule not found');
  const newCond = fields.condition ?? cur.condition;
  const newThr  = fields.threshold ?? cur.threshold;
  // `stopThreshold: null` clears it; leaving it out keeps the current value.
  const newStop = fields.stopThreshold === undefined ? cur.stop_threshold : checkStop(newCond, newThr, fields.stopThreshold);
  db.prepare(`UPDATE actuator_rule SET label=?, channel=?, source=?, condition=?, threshold=?, duration_minutes=?, cooldown_minutes=?, stop_threshold=?, enabled=? WHERE id=?`)
    .run(
      fields.label ?? cur.label,
      fields.channel ?? cur.channel,
      fields.source ?? cur.source,
      newCond,
      newThr,
      fields.durationMinutes ?? cur.duration_minutes,
      fields.cooldownMinutes ?? cur.cooldown_minutes,
      newStop,
      fields.enabled === undefined ? cur.enabled : (fields.enabled ? 1 : 0),
      id
    );
}

function deleteActuatorRule(id) {
  db.prepare(`DELETE FROM actuator_rule WHERE id = ?`).run(id);
}

function lastActuatorEvent(channel) {
  return db.prepare(`SELECT * FROM actuator_log WHERE channel = ? ORDER BY id DESC LIMIT 1`).get(channel);
}

function logActuatorEvent(channel, action, reason) {
  db.prepare(`INSERT INTO actuator_log (ts, channel, action, reason) VALUES (?,?,?,?)`)
    .run(nowISO(), channel, action, reason || '');
}

function getActuatorHistory(channel, limit = 50) {
  if (channel) return db.prepare(`SELECT * FROM actuator_log WHERE channel = ? ORDER BY id DESC LIMIT ?`).all(channel, limit);
  return db.prepare(`SELECT * FROM actuator_log ORDER BY id DESC LIMIT ?`).all(limit);
}

// True unless every node that can supply `source` is offline. If no node
// declares that capability (e.g. data only arrives via the old merged payload)
// we can't judge, so we don't block the rule.
function sensorAvailable(source) {
  const cap = source === 'ph' ? 'ph' : source === 'temperature' ? 'temperature' : 'salinity';
  const suppliers = listNodes().filter(n => n.enabled && (n.capabilities || []).includes(cap));
  if (!suppliers.length) return true;
  return suppliers.some(n => n.online);
}

// Which time-schedules are currently holding the pump OFF
// ("6:00 valves 1+2 open, pump off for 5 min").
function schedulePumpOff(now = new Date()) {
  const dow = now.getDay();
  return listActuatorSchedules().filter(s => s.enabled && s.pumpOffMinutes > 0).filter(s => {
    if (s.days !== 'daily') {
      const allowed = s.days.split(',').map(x => parseInt(x.trim(), 10));
      if (!allowed.includes(dow)) return false;
    }
    const [hh, mm] = s.time.split(':').map(Number);
    const start = new Date(now); start.setHours(hh, mm, 0, 0);
    const end = new Date(start.getTime() + s.pumpOffMinutes * 60000);
    return now >= start && now < end;
  });
}

// The single source of truth for "what should be open right now".
// Called by the solenoid ESP32 every poll (see the firmware) AND by the
// dashboard for a live view — safe to call from both, since a rule only
// logs a NEW on/off transition when the state actually changes.
function computeActuatorState(now = new Date()) {
  const state = { 1: false, 2: false, 3: false, 4: false };
  const reasons = {};

  // ── time schedules (e.g. channels 1,2 open at 06:00 for 5 min) ──
  const dow = now.getDay();
  listActuatorSchedules().filter(s => s.enabled).forEach(s => {
    if (s.days !== 'daily') {
      const allowed = s.days.split(',').map(x => parseInt(x.trim(), 10));
      if (!allowed.includes(dow)) return;
    }
    const [hh, mm] = s.time.split(':').map(Number);
    const start = new Date(now); start.setHours(hh, mm, 0, 0);
    const end = new Date(start.getTime() + s.durationMinutes * 60000);
    if (now >= start && now <= end) {
      s.channels.forEach(ch => {
        if (ch >= 1 && ch <= 4) { state[ch] = true; reasons[ch] = `schedule:${s.id}`; }
      });
    }
  });

  // ── sensor-triggered rules (e.g. channel 3 opens when salinity drops) ──
  // A rule OPENS its valve when the reading crosses `threshold`, and keeps it
  // open until the reading reaches `stopThreshold` (the "optimal" level). With
  // no stopThreshold it closes as soon as the reading is back across `threshold`.
  // `durationMinutes` is a hard safety cap either way.
  const latest = getLatestData();
  const valueFor = src => (src === 'ph' ? latest.ph : src === 'temperature' ? latest.temperature : latest.salinity);

  listActuatorRules().filter(r => r.enabled).forEach(r => {
    const val = valueFor(r.source);
    const last = lastActuatorEvent(r.channel);
    const isOn = last && last.action === 'on';

    // Fail closed: if the sensor node that provides this reading has gone
    // quiet, a stale number would keep dosing water until the safety cap.
    if (val === null || val === undefined || !sensorAvailable(r.source)) {
      if (isOn) logActuatorEvent(r.channel, 'off', `rule:${r.id}:sensor-offline`);
      return;
    }

    const startMet = r.condition === 'below' ? val < r.threshold : val > r.threshold;
    const stopLevel = (r.stopThreshold === null || r.stopThreshold === undefined) ? r.threshold : r.stopThreshold;
    const keepOpen = r.condition === 'below' ? val < stopLevel : val > stopLevel;

    if (isOn) {
      const onForMin = (now - new Date(last.ts).getTime()) / 60000;
      if (keepOpen && onForMin < r.durationMinutes) {
        state[r.channel] = true;
        reasons[r.channel] = `rule:${r.id}`;
      } else {
        logActuatorEvent(r.channel, 'off', onForMin >= r.durationMinutes ? `rule:${r.id}:safety-cap` : `rule:${r.id}:target-reached`);
      }
    } else if (startMet) {
      const offSinceMin = last ? (now - new Date(last.ts).getTime()) / 60000 : Infinity;
      if (offSinceMin >= r.cooldownMinutes) {
        logActuatorEvent(r.channel, 'on', `rule:${r.id}`);
        state[r.channel] = true;
        reasons[r.channel] = `rule:${r.id}`;
      }
    }
  });

  return {
    channels: state,
    reasons,
    ts: now.toISOString(),
    salinity: latest.salinity,
    ph: latest.ph,
    temperature: latest.temperature,
  };
}

// ══════════════════════════════════════════════════════════
// PUMP + DRAIN-SOLENOID AUTO WEIGH-CYCLE
// ══════════════════════════════════════════════════════════
// Sequence (see docs/PUMP_DRAIN_CYCLE.md):
//   schedule time reached → PUMP OFF → (short lead) → DRAIN SOLENOID ON
//   → DRAIN SOLENOID OFF → (settle) → WEIGHT TAKEN → PUMP ON
//
// The pump and the drain solenoid normally live on two SEPARATE ESP32
// boards (firmware/crabtrack_node6_pump.ino vs.
// firmware/crabtrack_node5_solenoids.ino) — exactly like the existing
// solenoid automation, NEITHER board decides anything itself. Both just
// poll GET /api/actuators/state every few seconds; that response now
// also carries { pump: true|false }. The Pi is the one place that knows
// the whole sequence, which is what keeps two independent boards in
// sync without MQTT: every board is just mirroring what the Pi says,
// and the pump board will never see "on" until the weight step below
// has actually run.

function normaliseDrainChannels(value, fallback) {
  const raw = value !== undefined && value !== null && value !== '' ? value : fallback;
  const list = (Array.isArray(raw) ? raw : String(raw ?? '').split(','))
    .map(v => parseInt(v, 10)).filter(v => v >= 1 && v <= 4);
  const unique = [...new Set(list)];
  if (!unique.length) throw new Error('drainChannels must contain one or more channels from 1 to 4');
  return unique;
}

function listDrainSchedules() {
  return db.prepare(`SELECT * FROM drain_cycle_schedule ORDER BY time_of_day ASC`).all().map(r => {
    const channels = normaliseDrainChannels(r.drain_channels, [r.drain_channel]);
    return {
      id: r.id, label: r.label || '', time: r.time_of_day, days: r.days,
      drainChannel: channels[0], drainChannels: channels,
      pumpLeadSeconds: r.pump_lead_seconds, drainMinutes: r.drain_minutes,
      settleSeconds: r.settle_seconds, compId: r.comp_id, enabled: !!r.enabled,
    };
  });
}

function addDrainSchedule({ label, time, days, drainChannel, drainChannels, pumpLeadSeconds, drainMinutes, settleSeconds, compId }) {
  if (!/^\d{2}:\d{2}$/.test(time || '')) throw new Error('time must be "HH:MM"');
  const channels = normaliseDrainChannels(drainChannels, drainChannel);
  const info = db.prepare(`INSERT INTO drain_cycle_schedule
      (label, time_of_day, days, drain_channel, drain_channels, pump_lead_seconds, drain_minutes, settle_seconds, comp_id, enabled, created_ts)
      VALUES (?,?,?,?,?,?,?,?,?,1,?)`)
    .run(label || '', time, days || 'daily', channels[0], channels.join(','), pumpLeadSeconds ?? 5, drainMinutes ?? 3, settleSeconds ?? 20, compId || 'C04', nowISO());
  return info.lastInsertRowid;
}

function updateDrainSchedule(id, fields) {
  const cur = db.prepare(`SELECT * FROM drain_cycle_schedule WHERE id = ?`).get(id);
  if (!cur) throw new Error('drain schedule not found');
  const currentChannels = cur.drain_channels || String(cur.drain_channel);
  const channels = normaliseDrainChannels(fields.drainChannels, fields.drainChannel !== undefined ? fields.drainChannel : currentChannels);
  if (fields.time !== undefined && !/^\d{2}:\d{2}$/.test(fields.time)) throw new Error('time must be "HH:MM"');
  db.prepare(`UPDATE drain_cycle_schedule SET label=?, time_of_day=?, days=?, drain_channel=?, drain_channels=?, pump_lead_seconds=?, drain_minutes=?, settle_seconds=?, comp_id=?, enabled=? WHERE id=?`)
    .run(
      fields.label ?? cur.label, fields.time ?? cur.time_of_day, fields.days ?? cur.days,
      channels[0], channels.join(','), fields.pumpLeadSeconds ?? cur.pump_lead_seconds,
      fields.drainMinutes ?? cur.drain_minutes, fields.settleSeconds ?? cur.settle_seconds,
      fields.compId ?? cur.comp_id,
      fields.enabled === undefined ? cur.enabled : (fields.enabled ? 1 : 0), id
    );
}

function deleteDrainSchedule(id) {
  db.prepare(`DELETE FROM drain_cycle_schedule WHERE id = ?`).run(id);
}

function listPendingManualRuns() {
  return db.prepare(`SELECT * FROM drain_manual_run WHERE status != 'done' ORDER BY id ASC`).all();
}

// Queue an immediate one-off cycle — e.g. a "Run cycle now" button.
function queueManualDrainCycle({ drainChannel, drainChannels, pumpLeadSeconds, drainMinutes, settleSeconds, compId }) {
  const channels = normaliseDrainChannels(drainChannels, drainChannel);
  const info = db.prepare(`INSERT INTO drain_manual_run
      (requested_ts, drain_channel, drain_channels, pump_lead_seconds, drain_minutes, settle_seconds, comp_id, status)
      VALUES (?,?,?,?,?,?,?,'pending')`)
    .run(nowISO(), channels[0], channels.join(','), pumpLeadSeconds ?? 5, drainMinutes ?? 3, settleSeconds ?? 20, compId || 'C04');
  return info.lastInsertRowid;
}

function dateKeyOf(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function hasCycleStep(runType, runId, cycleDate, step) {
  return !!db.prepare(`SELECT 1 FROM drain_cycle_log WHERE run_type=? AND run_id=? AND cycle_date=? AND step=? LIMIT 1`)
    .get(runType, runId, cycleDate, step);
}

function logCycleStep(runType, runId, cycleDate, step, detail) {
  if (hasCycleStep(runType, runId, cycleDate, step)) return;   // one row per step, per run, per day
  db.prepare(`INSERT INTO drain_cycle_log (ts, run_type, run_id, cycle_date, step, detail) VALUES (?,?,?,?,?,?)`)
    .run(nowISO(), runType, runId, cycleDate, step, detail != null ? String(detail) : '');
}

function getDrainCycleHistory(limit = 50) {
  return db.prepare(`SELECT * FROM drain_cycle_log ORDER BY id DESC LIMIT ?`).all(limit);
}

// "C04" -> 3 (0-based), matching WEIGHT_OFFSET in the weight-node firmware.
function compIndexFromId(compId) {
  const n = parseInt(String(compId || '').replace(/\D/g, ''), 10);
  return Number.isInteger(n) && n >= 1 ? n - 1 : 0;
}

function lastPumpEvent() {
  return db.prepare(`SELECT * FROM pump_log ORDER BY id DESC LIMIT 1`).get();
}

function logPumpEvent(action, reason) {
  const last = lastPumpEvent();
  if (last && last.action === action) return;   // only log actual on/off transitions
  db.prepare(`INSERT INTO pump_log (ts, action, reason) VALUES (?,?,?)`).run(nowISO(), action, reason || '');
}

function getPumpHistory(limit = 50) {
  return db.prepare(`SELECT * FROM pump_log ORDER BY id DESC LIMIT ?`).all(limit);
}

function getPumpOverride() {
  const r = db.prepare(`SELECT * FROM pump_override WHERE id = 1`).get();
  return { mode: r ? r.mode : 'auto', setTs: r ? r.set_ts : null };
}

function setPumpOverride(mode) {
  if (!['auto', 'forced_on', 'forced_off'].includes(mode)) throw new Error('mode must be auto, forced_on or forced_off');
  db.prepare(`INSERT INTO pump_override (id, mode, set_ts) VALUES (1,?,?)
              ON CONFLICT(id) DO UPDATE SET mode=excluded.mode, set_ts=excluded.set_ts`)
    .run(mode, nowISO());
  return getPumpOverride();
}

// Which window of the sequence "now" falls in, given when the cycle started:
//   pump_off  [cycleStart, drainStart)  pump already off, valve still closed (the lead gap)
//   draining  [drainStart, drainEnd]    pump off, drain valve OPEN
//   settling  (drainEnd, settleEnd]     pump off, valve closed, scale settling
//   done      after settleEnd           weight captured, pump back ON
function cyclePhase(cycleStartMs, pumpLeadSeconds, drainMinutes, settleSeconds, nowMs) {
  const drainStart = cycleStartMs + pumpLeadSeconds * 1000;
  const drainEnd = drainStart + drainMinutes * 60000;
  const settleEnd = drainEnd + settleSeconds * 1000;
  if (nowMs < cycleStartMs) return 'idle';
  if (nowMs < drainStart) return 'pump_off';
  if (nowMs <= drainEnd) return 'draining';
  if (nowMs <= settleEnd) return 'settling';
  return 'done';
}

// Drives one cycle run's step log and reports whether, right now, the
// pump should be held off and the drain channel should be open.
function advanceCycle(runType, runId, cycleDate, phase, cfg) {
  let pumpOff = false;
  let channelOn = false;

  if (phase === 'pump_off') {
    pumpOff = true;
    logCycleStep(runType, runId, cycleDate, 'pump_off', 'drain/weigh cycle starting');
  } else if (phase === 'draining') {
    pumpOff = true;
    channelOn = true;
    logCycleStep(runType, runId, cycleDate, 'pump_off', 'drain/weigh cycle starting');
    logCycleStep(runType, runId, cycleDate, 'drain_on', `channel(s) ${(cfg.drainChannels || [cfg.drainChannel]).join('+')} opened`);
  } else if (phase === 'settling') {
    pumpOff = true;
    logCycleStep(runType, runId, cycleDate, 'drain_off', `channel(s) ${(cfg.drainChannels || [cfg.drainChannel]).join('+')} closed`);
  } else if (phase === 'done') {
    if (!hasCycleStep(runType, runId, cycleDate, 'weight_taken')) {
      const latest = getLatestData();
      if (String(cfg.compId || '').toUpperCase() === 'ALL') {
        let captured = 0;
        for (let idx = 0; idx < 10; idx++) {
          const weight = latest.weights[idx];
          if (typeof weight === 'number' && !Number.isNaN(weight)) {
            const compId = `C${String(idx + 1).padStart(2, '0')}`;
            logWeight({ compId, weight, note: 'Auto drain-cycle weight', source: 'auto-cycle' });
            logCycleStep(runType, runId, cycleDate, `weight_taken_${compId}`, weight);
            captured++;
          }
        }
        logCycleStep(runType, runId, cycleDate, 'weight_taken', captured ? `${captured}/10 compartment weights captured` : 'no recent weight readings available');
      } else {
        const idx = compIndexFromId(cfg.compId);
        const weight = latest.weights[idx];
        if (typeof weight === 'number' && !Number.isNaN(weight)) {
          logWeight({ compId: cfg.compId, weight, note: 'Auto drain-cycle weight', source: 'auto-cycle' });
          logCycleStep(runType, runId, cycleDate, 'weight_taken', weight);
        } else {
          logCycleStep(runType, runId, cycleDate, 'weight_taken', 'no recent weight reading available');
        }
      }
      logCycleStep(runType, runId, cycleDate, 'pump_on', 'drain/weigh cycle complete');
      if (runType === 'manual') db.prepare(`UPDATE drain_manual_run SET status='done' WHERE id=?`).run(runId);
    }
    pumpOff = false;   // cycle complete — pump resumes
  }

  return { pumpOff, channelOn };
}

// The single source of truth for "should the pump be running, and
// which drain channel(s) should be open, RIGHT NOW because of a
// cycle". Folded into GET /api/actuators/state, which is what both
// the (separate) pump board and the solenoid board actually poll.
function computePumpAndDrainState(now = new Date()) {
  const nowMs = now.getTime();
  let pumpOffByCycle = false;
  const drainChannels = {};
  const activeCycles = [];

  listDrainSchedules().filter(s => s.enabled).forEach(s => {
    if (s.days !== 'daily') {
      const allowed = s.days.split(',').map(x => parseInt(x.trim(), 10));
      if (!allowed.includes(now.getDay())) return;
    }
    const [hh, mm] = s.time.split(':').map(Number);
    const cycleStart = new Date(now); cycleStart.setHours(hh, mm, 0, 0);
    const phase = cyclePhase(cycleStart.getTime(), s.pumpLeadSeconds, s.drainMinutes, s.settleSeconds, nowMs);
    if (phase === 'idle') return;
    const cycleDate = dateKeyOf(cycleStart);
    const { pumpOff, channelOn } = advanceCycle('schedule', s.id, cycleDate, phase, s);
    if (pumpOff) pumpOffByCycle = true;
    if (channelOn) (s.drainChannels || [s.drainChannel]).forEach(ch => { drainChannels[ch] = true; });
    if (phase !== 'done') activeCycles.push({ type: 'schedule', id: s.id, label: s.label, phase, channel: (s.drainChannels || [s.drainChannel]).join('+') });
  });

  listPendingManualRuns().forEach(m => {
    const cycleStart = new Date(m.requested_ts);
    const phase = cyclePhase(cycleStart.getTime(), m.pump_lead_seconds, m.drain_minutes, m.settle_seconds, nowMs);
    const cycleDate = dateKeyOf(cycleStart);
    const manualChannels = normaliseDrainChannels(m.drain_channels, [m.drain_channel]);
    const cfg = { drainChannel: manualChannels[0], drainChannels: manualChannels, compId: m.comp_id };
    const { pumpOff, channelOn } = advanceCycle('manual', m.id, cycleDate, phase, cfg);
    if (pumpOff) pumpOffByCycle = true;
    if (channelOn) manualChannels.forEach(ch => { drainChannels[ch] = true; });
    if (phase !== 'done') activeCycles.push({ type: 'manual', id: m.id, label: 'Manual run', phase, channel: manualChannels.join('+') });
  });

  // Time-schedules that also hold the pump off (e.g. valves 1+2 at 06:00, pump off 5 min).
  const schedPumpOff = schedulePumpOff(now);
  schedPumpOff.forEach(sc => activeCycles.push({
    type: 'schedule-pump-off', id: sc.id, label: sc.label, phase: 'pump off', channel: sc.channels.join('+'),
  }));

  const override = getPumpOverride();
  let pumpOn, reason;
  // A manual forced-OFF always wins. Scheduled drain cycles must also stop
  // the pump even if a stale manual forced-ON override was left enabled.
  if (override.mode === 'forced_off')      { pumpOn = false; reason = 'manual-off'; }
  else if (pumpOffByCycle)                 { pumpOn = false; reason = 'drain-cycle'; }
  else if (schedPumpOff.length)            { pumpOn = false; reason = 'schedule'; }
  else if (override.mode === 'forced_on')  { pumpOn = true;  reason = 'manual-on'; }
  else                                     { pumpOn = true;  reason = 'auto'; }

  logPumpEvent(pumpOn ? 'on' : 'off', reason);

  return { pumpOn, pumpMode: override.mode, drainChannels, activeCycles };
}


function getAdminAccount() { return db.prepare(`SELECT * FROM admin_account WHERE id=1`).get() || null; }
function setAdminAccount(username, salt, hash) {
  db.prepare(`INSERT INTO admin_account (id, username, salt, hash, updated_ts) VALUES (1,?,?,?,?)
              ON CONFLICT(id) DO UPDATE SET username=excluded.username, salt=excluded.salt, hash=excluded.hash, updated_ts=excluded.updated_ts`)
    .run(username, salt, hash, nowISO());
}

// ══════════════════════════════════════════════════════════
// SCALE TARE / CALIBRATE FROM THE WEBSITE
// ══════════════════════════════════════════════════════════
// Admin page → POST /api/scale/command → row here (status 'pending').
// The weight node polls GET /api/scale/pending, does the tare/calibration on
// its HX711, and reports back with POST /api/scale/result.
// A command the node doesn't pick up within SCALE_CMD_TTL_SEC is expired: a
// tare that lands minutes later, with crabs now sitting on the scale, would
// silently zero the wrong thing.
const SCALE_CMD_TTL_SEC = 120;

function expireScaleCommands() {
  const cutoff = new Date(Date.now() - SCALE_CMD_TTL_SEC * 1000).toISOString();
  db.prepare(`UPDATE scale_command SET status='expired', message='Weight node did not pick this up in time - nothing was changed', done_ts=?
              WHERE status='pending' AND ts < ?`).run(nowISO(), cutoff);
}

function queueScaleCommand({ compId, action, knownWeight }) {
  const cid = String(compId || '').toUpperCase();
  if (!/^C\d{2}$/.test(cid)) throw new Error('compId must look like C04');
  if (!['tare', 'calibrate'].includes(action)) throw new Error('action must be "tare" or "calibrate"');
  let kw = null;
  if (action === 'calibrate') {
    kw = Number(knownWeight);
    if (!Number.isFinite(kw) || kw <= 0 || kw > 100000) throw new Error('knownWeight must be a number of grams greater than 0');
  }
  expireScaleCommands();
  if (db.prepare(`SELECT 1 FROM scale_command WHERE comp_id=? AND status='pending'`).get(cid)) {
    throw new Error(`A command for ${cid} is already waiting for the weight node`);
  }
  return db.prepare(`INSERT INTO scale_command (ts, comp_id, action, known_weight, status) VALUES (?,?,?,?, 'pending')`)
    .run(nowISO(), cid, action, kw).lastInsertRowid;
}

// What a weight node serving compartments [offset, offset+count) should do now.
function pendingScaleCommands(offset, count) {
  expireScaleCommands();
  return db.prepare(`SELECT * FROM scale_command WHERE status='pending' ORDER BY id ASC`).all()
    .map(r => ({ r, idx: compIndexFromId(r.comp_id) }))
    .filter(x => x.idx >= offset && x.idx < offset + count)
    .map(x => ({ id: x.r.id, compId: x.r.comp_id, slot: x.idx - offset, action: x.r.action, knownWeight: x.r.known_weight }));
}

function completeScaleCommand(id, ok, message, calFactor) {
  const cmd = db.prepare(`SELECT * FROM scale_command WHERE id=?`).get(id);
  if (!cmd) throw new Error('command not found');
  if (cmd.status !== 'pending') return;          // already settled - ignore duplicate reports
  const cf = (typeof calFactor === 'number' && Number.isFinite(calFactor)) ? calFactor : null;
  db.prepare(`UPDATE scale_command SET status=?, message=?, cal_factor=?, done_ts=? WHERE id=?`)
    .run(ok ? 'done' : 'failed', message || '', cf, nowISO(), id);
  if (ok) {
    db.prepare(`INSERT OR IGNORE INTO scale_state (comp_id) VALUES (?)`).run(cmd.comp_id);
    if (cmd.action === 'tare') db.prepare(`UPDATE scale_state SET last_tare_ts=? WHERE comp_id=?`).run(nowISO(), cmd.comp_id);
    if (cmd.action === 'calibrate') db.prepare(`UPDATE scale_state SET last_cal_ts=?, cal_factor=COALESCE(?, cal_factor) WHERE comp_id=?`).run(nowISO(), cf, cmd.comp_id);
  }
}

function listScaleCommands(limit = 20) {
  expireScaleCommands();
  return db.prepare(`SELECT * FROM scale_command ORDER BY id DESC LIMIT ?`).all(limit).map(r => ({
    id: r.id, ts: r.ts, compId: r.comp_id, action: r.action, knownWeight: r.known_weight,
    status: r.status, message: r.message || '', calFactor: r.cal_factor, doneTs: r.done_ts,
  }));
}

function listScaleState() {
  return db.prepare(`SELECT * FROM scale_state ORDER BY comp_id ASC`).all().map(r => ({
    compId: r.comp_id, calFactor: r.cal_factor, lastTareTs: r.last_tare_ts, lastCalTs: r.last_cal_ts,
  }));
}

function seedDefaultWaterAutomation() {
  const scheduleLabel = 'Daily 06:00 drain — solenoids 1+2';
  const existingSchedule = db.prepare(`SELECT id FROM drain_cycle_schedule WHERE label = ? LIMIT 1`).get(scheduleLabel);
  if (!existingSchedule) {
    db.prepare(`INSERT INTO drain_cycle_schedule
      (label, time_of_day, days, drain_channel, drain_channels, pump_lead_seconds, drain_minutes, settle_seconds, comp_id, enabled, created_ts)
      VALUES (?,?,?,?,?,?,?,?,?,1,?)`)
      .run(scheduleLabel, '06:00', 'daily', 1, '1,2', 0, 2, 20, 'ALL', nowISO());
  }

  // These are intentionally DISABLED until the operator verifies whether the
  // incoming "salinity" value is true ppt or EC in mS/cm. Never auto-dose on
  // an unverified unit conversion.
  const drafts = [
    { label: 'DRAFT: low salinity adds saltwater (solenoid 3)', channel: 3, condition: 'below', threshold: 15, stop: 18 },
    { label: 'DRAFT: high salinity adds freshwater (solenoid 4)', channel: 4, condition: 'above', threshold: 25, stop: 22 },
  ];
  for (const r of drafts) {
    const exists = db.prepare(`SELECT id FROM actuator_rule WHERE label = ? LIMIT 1`).get(r.label);
    if (!exists) {
      db.prepare(`INSERT INTO actuator_rule
        (label, channel, source, condition, threshold, duration_minutes, cooldown_minutes, stop_threshold, enabled, created_ts)
        VALUES (?,?,?,?,?,?,?,?,0,?)`)
        .run(r.label, r.channel, 'salinity', r.condition, r.threshold, 5, 2, r.stop, nowISO());
    }
  }
}

seedDefaultNodes();
seedDefaultWaterAutomation();

module.exports = {
  db, DB_PATH,
  ingestReading, getLatestData, getHistory, getStatus,
  upsertNode, getNode, listNodes, deleteNode, getNodeHistory,
  logFeed, logWeight, logObs, getFeedHistory,
  listSchedules, addSchedule, updateSchedule, deleteSchedule,
  checkScheduledFeedings, checkFeedingAlerts,
  recordAlert, getAlerts, alertSentRecently,
  queueMessage, pendingMessages, markMessage, getOutbox,
  listActuatorSchedules, addActuatorSchedule, updateActuatorSchedule, deleteActuatorSchedule,
  listActuatorRules, addActuatorRule, updateActuatorRule, deleteActuatorRule,
  computeActuatorState, getActuatorHistory,
  listDrainSchedules, addDrainSchedule, updateDrainSchedule, deleteDrainSchedule,
  queueManualDrainCycle, getDrainCycleHistory,
  getPumpOverride, setPumpOverride, getPumpHistory, computePumpAndDrainState,
  getAdminAccount, setAdminAccount,
  queueScaleCommand, pendingScaleCommands, completeScaleCommand, listScaleCommands, listScaleState,
};
