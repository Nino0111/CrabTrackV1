// ══════════════════════════════════════════════════════════
// cloud-sync.js — optional one-way mirror to Firebase RTDB
// ══════════════════════════════════════════════════════════
// The Pi + SQLite stay the source of truth. This just PUSHES a copy
// of the latest state to Firebase every N seconds so you can open the
// dashboard from outside the farm's Wi-Fi (or from the phone app).
//
// Why one-way: if the internet dies, the farm keeps running exactly as
// before. Nothing on the Pi waits for the cloud. When the link returns,
// the next push overwrites the cloud copy with current truth — there is
// no merge conflict to resolve, because writes only ever flow one way.
//
// Enable with .env:
//   FIREBASE_DB_URL=https://crabtrack-1e256-default-rtdb.asia-southeast1.firebasedatabase.app
//   FIREBASE_SECRET=<database secret or ID token>   # optional if rules are open
//   CLOUD_SYNC_SECONDS=30
//
// SECURITY: lock your Realtime Database rules down to read-only for the
// public path, or require auth. Default "test mode" rules expire and, worse,
// let anyone on the internet overwrite your data. See docs/ONLINE_ACCESS.md.

const store = require('./db');

const DB_URL   = (process.env.FIREBASE_DB_URL || '').replace(/\/$/, '');
const SECRET   = process.env.FIREBASE_SECRET || '';
const PERIOD   = (parseInt(process.env.CLOUD_SYNC_SECONDS, 10) || 30) * 1000;
const ROOT     = process.env.FIREBASE_ROOT || 'crab_track';

let lastOk = null;
let lastError = null;

function url(pathStr) {
  const auth = SECRET ? `?auth=${encodeURIComponent(SECRET)}` : '';
  return `${DB_URL}/${ROOT}/${pathStr}.json${auth}`;
}

async function putJSON(pathStr, value) {
  const res = await fetch(url(pathStr), {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(value),
    signal: AbortSignal.timeout(15000),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status} ${(await res.text()).slice(0, 160)}`);
}

async function pushOnce() {
  const snapshot = store.getLatestData();
  const nodes = {};
  snapshot.nodes.forEach(n => { nodes[n.nodeId] = n; });

  await putJSON('live', {
    ph: snapshot.ph,
    salinity: snapshot.salinity,
    temperature: snapshot.temperature,
    weights: snapshot.weights,
    timestamp: snapshot.timestamp,
    pushed_at: new Date().toISOString(),
  });
  await putJSON('nodes', nodes);
  await putJSON('alerts', store.getAlerts(25));
  await putJSON('feed_history', store.getFeedHistory(null, 50));
  await putJSON('status', store.getStatus());

  lastOk = new Date().toISOString();
  lastError = null;
}

function start() {
  if (!DB_URL) {
    console.log('[cloud] FIREBASE_DB_URL not set — running LAN-only (fully offline). This is fine.');
    return;
  }
  console.log(`[cloud] mirroring to ${DB_URL}/${ROOT} every ${PERIOD / 1000}s`);
  const tick = async () => {
    try { await pushOnce(); }
    catch (e) {
      lastError = e.message;
      console.warn('[cloud] push failed (will retry, Pi unaffected):', e.message);
    }
  };
  tick();
  setInterval(tick, PERIOD).unref?.();
}

function status() {
  return { enabled: !!DB_URL, dbUrl: DB_URL || null, root: ROOT, lastSuccess: lastOk, lastError, periodSeconds: PERIOD / 1000 };
}

module.exports = { start, pushOnce, status };
