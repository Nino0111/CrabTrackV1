// ══════════════════════════════════════════════════════════
// mqtt-bridge.js — ESP32 Nodes → Wi-Fi/MQTT → Raspberry Pi → SQLite
// ══════════════════════════════════════════════════════════
// v2: subscribes to a WILDCARD topic (crabtrack/+) instead of three
// hardcoded ones. A new node publishing to crabtrack/node7 is picked
// up with zero changes here — the node id is taken from the topic and
// the node auto-registers itself in the database.
//
// Only loaded when MQTT_BROKER is set (see server.js).

const mqtt = require('mqtt');

module.exports = function startBridge(store) {
  const brokerUrl = process.env.MQTT_BROKER;                    // e.g. mqtt://localhost:1883
  const base = (process.env.MQTT_BASE_TOPIC || 'crabtrack').replace(/\/$/, '');
  const wildcard = `${base}/#`;

  const client = mqtt.connect(brokerUrl, {
    reconnectPeriod: 3000,
    username: process.env.MQTT_USERNAME || undefined,
    password: process.env.MQTT_PASSWORD || undefined,
  });

  client.on('connect', () => {
    console.log(`[mqtt] connected to ${brokerUrl}, subscribing to ${wildcard}`);
    client.subscribe(wildcard, err => {
      if (err) console.error('[mqtt] subscribe failed:', err.message);
    });
  });

  client.on('message', (topic, payload) => {
    let data;
    try { data = JSON.parse(payload.toString()); }
    catch { return console.warn(`[mqtt] ignoring non-JSON payload on ${topic}`); }

    // crabtrack/node4  →  node_id "node4"
    const topicNodeId = topic.slice(base.length + 1).split('/')[0];
    // Prefer the topic's first segment (e.g. crabtrack/node2/data -> node2),
    // because older firmware may put a numeric node value in its JSON payload.
    const nodeId = /^(?:node|weight)\d{1,2}$/.test(topicNodeId)
      ? topicNodeId : (data.node_id || data.nodeId || data.node || topicNodeId);
    if (!nodeId) return;

    // Normalise the common field aliases so firmware can use either spelling.
    const reading = { ...data, node_id: nodeId };
    if (reading.pH   != null && reading.ph == null)  reading.ph = reading.pH;
    if (reading.EC   != null && reading.salinity == null) reading.salinity = reading.EC;
    if (reading.ec   != null && reading.salinity == null) reading.salinity = reading.ec;
    if (reading.Temp != null && reading.temperature == null) reading.temperature = reading.Temp;

    // Legacy flags, kept so the old dashboard fields stay populated.
    if (nodeId === 'node1') reading.node1_ok = true;
    if (nodeId === 'node2') reading.node2_ok = true;
    if (nodeId === 'node3') reading.node3_ok = true;

    try { store.ingestReading(reading); }
    catch (e) { console.error(`[mqtt] ingest failed for ${nodeId}:`, e.message); }
  });

  client.on('error', err => console.error('[mqtt] error:', err.message));
  client.on('offline', () => console.warn('[mqtt] broker offline — will reconnect'));

  return client;
};
