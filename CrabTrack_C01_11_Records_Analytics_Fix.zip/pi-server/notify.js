// ══════════════════════════════════════════════════════════
// notify.js — sends CrabTrack messages to your phone
// ══════════════════════════════════════════════════════════
// Design: messages are written to the `outbox` table FIRST, then a
// flusher tries to deliver them. That means if the Pi has no internet
// at the moment (power cut, mobile data down), nothing is lost — the
// message sits in the outbox and goes out when the link comes back.
//
// Channels, in order of how easy they are to set up:
//
//  1. telegram  — free, no SIM, works worldwide, delivers to phone as a
//                 push notification. Needs internet on the Pi.
//                 Setup: message @BotFather on Telegram → /newbot →
//                 copy the token. Then message your new bot once, and
//                 open https://api.telegram.org/bot<TOKEN>/getUpdates
//                 to find your chat id. Put both in .env:
//                    TELEGRAM_TOKEN=123456:AA...
//                    TELEGRAM_CHAT_ID=987654321
//
//  2. webhook   — POST the message anywhere (IFTTT, Discord, your own
//                 SMS gateway). Set NOTIFY_WEBHOOK=https://...
//
//  3. log       — always available, always offline. Writes to the
//                 console + the alerts table, which the dashboard and
//                 the app read. This is the fallback when there is no
//                 internet at all.

const store = require('./db');

const TELEGRAM_TOKEN   = process.env.TELEGRAM_TOKEN || '';
const TELEGRAM_CHAT_ID = process.env.TELEGRAM_CHAT_ID || '';
const NOTIFY_WEBHOOK   = process.env.NOTIFY_WEBHOOK || '';

function availableChannels() {
  const list = ['log'];
  if (TELEGRAM_TOKEN && TELEGRAM_CHAT_ID) list.push('telegram');
  if (NOTIFY_WEBHOOK) list.push('webhook');
  return list;
}

function defaultChannel() {
  if (TELEGRAM_TOKEN && TELEGRAM_CHAT_ID) return 'telegram';
  if (NOTIFY_WEBHOOK) return 'webhook';
  return 'log';
}

// Queue a message. Returns immediately — delivery happens in the background.
function send(body, { channel, target } = {}) {
  const ch = channel || defaultChannel();
  const id = store.queueMessage({ channel: ch, target: target || '', body });
  setImmediate(flush);            // try right away, but don't block the caller
  return { id, channel: ch, queued: true };
}

async function deliverTelegram(body, target) {
  const chatId = target || TELEGRAM_CHAT_ID;
  if (!TELEGRAM_TOKEN || !chatId) throw new Error('TELEGRAM_TOKEN / TELEGRAM_CHAT_ID not configured');
  const res = await fetch(`https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendMessage`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ chat_id: chatId, text: body, disable_web_page_preview: true }),
    signal: AbortSignal.timeout(12000),
  });
  if (!res.ok) throw new Error(`Telegram HTTP ${res.status}: ${(await res.text()).slice(0, 200)}`);
}

async function deliverWebhook(body, target) {
  const url = target || NOTIFY_WEBHOOK;
  if (!url) throw new Error('NOTIFY_WEBHOOK not configured');
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text: body, content: body, source: 'crabtrack', ts: new Date().toISOString() }),
    signal: AbortSignal.timeout(12000),
  });
  if (!res.ok) throw new Error(`Webhook HTTP ${res.status}`);
}

let flushing = false;
async function flush() {
  if (flushing) return;
  flushing = true;
  try {
    const pending = store.pendingMessages(25);
    for (const m of pending) {
      try {
        if (m.channel === 'telegram')      await deliverTelegram(m.body, m.target);
        else if (m.channel === 'webhook')  await deliverWebhook(m.body, m.target);
        else                               console.log('[notify]', m.body);
        store.markMessage(m.id, 'sent');
      } catch (e) {
        // Stays 'pending' so the next flush retries it — this is the
        // offline-tolerant part. After 8 failed attempts it's skipped.
        store.markMessage(m.id, 'pending', e.message);
        console.warn(`[notify] delivery failed (will retry): ${e.message}`);
      }
    }
  } finally {
    flushing = false;
  }
}

// Retry sweep every 2 minutes for anything stuck from an offline period.
function startFlusher(intervalMs = 120000) {
  setInterval(() => { flush().catch(() => {}); }, intervalMs).unref?.();
  console.log(`[notify] channels available: ${availableChannels().join(', ')} (default: ${defaultChannel()})`);
}

module.exports = { send, flush, startFlusher, availableChannels, defaultChannel };
